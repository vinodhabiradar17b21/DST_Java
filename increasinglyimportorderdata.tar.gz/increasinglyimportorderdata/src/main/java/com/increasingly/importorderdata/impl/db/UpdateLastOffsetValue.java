package com.increasingly.importorderdata.impl.db;

import static com.increasingly.importorderdata.util.Constants.LOG_ERROR;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasingly.db.BaseDB;
import com.increasingly.importorderdata.util.FormatLoggerMessage;

public class UpdateLastOffsetValue 
{	
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateLastOffsetValue.class.getClass());
	private static UpdateLastOffsetValue instance = null;
	
	//Integer total_Pages = 0;
	
	public static UpdateLastOffsetValue getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateLastOffsetValue();
		}
		return instance;
	}
	
	
	public void lastPageValueupdate(Integer totalPages,Integer clientId,Integer lastOffsetValue) 
	{		
		try
		{	//this.total_Pages=totalPages;
			Connection conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("call Update_Last_Offset_Value(?,?,?)");
			cStmt.setInt(1,clientId);
			cStmt.setInt(2,lastOffsetValue);
			cStmt.setInt(3,totalPages);
			cStmt.executeUpdate();
		}
		catch(Exception e)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateLastOffsetValue" , "Error Occured while Updating the totalpages value in DB." ,"","");
			logger.error(errorMessage,e);
		}
	}

}