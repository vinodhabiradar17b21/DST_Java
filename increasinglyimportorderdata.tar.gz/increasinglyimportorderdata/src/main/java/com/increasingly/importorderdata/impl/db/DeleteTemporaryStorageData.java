package com.increasingly.importorderdata.impl.db;

import static com.increasingly.importorderdata.util.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasingly.db.BaseDB;
import com.increasingly.importorderdata.util.FormatLoggerMessage;

public class DeleteTemporaryStorageData
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(DeleteTemporaryStorageData.class.getClass());
			
		
		
	public void deleteTemporaryOrderItemDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from bulk_order_item_details_temporary_storage where client_id=?");
					
			cStmt.setInt(1, clientId);		
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderItemDetails" , "Error Occured while deleting inconsitant order item data" ,"","");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	}
	
	public void deleteTemporaryOrderDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from bulk_order_details_temporary_storage where client_id=?");
					
			cStmt.setInt(1, clientId);		
					
			cStmt.executeUpdate();			
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderDetails" , "Error Occured while deleting inconsitant order data" ,"","");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	

	}
	
	
}