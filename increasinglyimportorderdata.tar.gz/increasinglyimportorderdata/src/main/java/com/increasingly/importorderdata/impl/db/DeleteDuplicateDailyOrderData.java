package com.increasingly.importorderdata.impl.db;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasingly.db.BaseDB;
import com.increasingly.importorderdata.interfaces.ServiceInterface;
import com.increasingly.importorderdata.util.*;

public class DeleteDuplicateDailyOrderData implements ServiceInterface<Integer>{

	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(DeleteDuplicateDailyOrderData.class.getClass());
	
	private static DeleteDuplicateDailyOrderData instance = null;
	
	private DeleteDuplicateDailyOrderData()
	{
		
	}

	public static DeleteDuplicateDailyOrderData getInstance()
	{
		if (instance == null)
		{
			instance = new DeleteDuplicateDailyOrderData();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) throws Exception {		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Delete_Duplicates_For_Daily_Order_Data_Update(?, ?)}");	
			
			//LocalDate today = LocalDate.now();
			//LocalDate yesterday = today.minusDays(1);

			java.sql.Date today = new java.sql.Date(Calendar.getInstance().getTime().getTime());
			java.sql.Date yesterday = new java.sql.Date(new java.util.Date().getTime() - 1000*60*60*24);;
			cStmt.setDate(1,yesterday);
			cStmt.setDate(2,today);

			cStmt.execute();
					
			return 1;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(Constants.LOG_ERROR , "DeleteDuplicateDailyOrderData" , "Error Occured while deleting duplicate order data." ,"","");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return 0;
	}

}