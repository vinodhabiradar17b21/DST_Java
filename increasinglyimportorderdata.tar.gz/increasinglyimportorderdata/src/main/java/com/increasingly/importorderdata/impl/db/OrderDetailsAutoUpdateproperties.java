package com.increasingly.importorderdata.impl.db;

import static com.increasingly.importorderdata.util.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.base.Strings;
import com.increasingly.db.BaseDB;
import com.increasingly.importorderdata.ImportClientData;
import com.increasingly.importorderdata.impl.ImportOrderDataImpl;
import com.increasingly.importorderdata.impl.db.DeleteTemporaryStorageData;
import com.increasingly.importorderdata.impl.db.GetOrderDataFieldMappingDetails;
import com.increasingly.importorderdata.interfaces.ServiceInterface;
import com.increasingly.importorderdata.util.FormatLoggerMessage;
import com.increasingly.importorderdata.util.UrlUtil;
import com.mysql.jdbc.PreparedStatement;




public class OrderDetailsAutoUpdateproperties 
{
	
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(OrderDetailsAutoUpdateproperties.class.getClass());
	
	private static OrderDetailsAutoUpdateproperties instance = null;	

	public static OrderDetailsAutoUpdateproperties getInstance()
	{
		if (instance == null)
		{
			instance = new OrderDetailsAutoUpdateproperties();
		}
		return instance;
	}	
	
	
	public ArrayList <Map<Object,Object>> getOrderDetailsAutoUpdateproperties()
	{				
		ArrayList <Map<Object,Object>> Orderpropertieslist= new ArrayList <Map<Object,Object>>();				
		
		try
		{
			 Connection conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();

			 CallableStatement cStmt = conn.prepareCall("call Get_Auto_Order_Update_Properties_Details()");
			 ResultSet rst=cStmt.executeQuery();              
			 
			 while (rst.next())
			 {				 
		        Map <Object,Object> OrderProperties=new HashMap<Object,Object>();
		 		
		 		OrderProperties.put(CLIENT_ID,rst.getInt("client_id"));
		 		OrderProperties.put(API_QUERY_LIMIT, rst.getInt("api_limit"));
		 		OrderProperties.put(IS_API, rst.getBoolean("is_api"));
		 		OrderProperties.put(IS_MAGENTO_PRODUCT_EXPORT, rst.getBoolean("is_magento_order_export"));
		 		OrderProperties.put(OFFSET_LIST, rst.getString("offset_list"));				 		
		 		OrderProperties.put(BASE_FILE_URL, rst.getString("base_file_url"));
		 		OrderProperties.put(OFFSET_START_VALUE, rst.getInt("offset_last_value"));
		 		
		 		Orderpropertieslist.add(OrderProperties);
				 
			 }	  
		}

		catch(Exception ex)
		{
		    String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderDetailsAutoUpdateproperties" , "Error Occured while retreving the data from DB." ,"","");
			logger.error(errorMessage,ex);	
		}
		
		return Orderpropertieslist;
		
	}


		
	
}
