package com.increasingly.importorderdata.util;

import static com.increasingly.importorderdata.util.Constants.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class ParseXMLFile
{

	private static final Logger logger = LoggerFactory.getLogger(ParseXMLFile.class.getClass());

	public Map<String,Object> getXMLParsedData(String fileLocation) throws ParserConfigurationException, SAXException, IOException
	{
		Map<String,Object> parsedOrderAndItemData = new HashMap<String,Object>();
		ArrayList<LinkedHashMap<String, Object>> orderDataList = new ArrayList<LinkedHashMap<String, Object>>();
		
		Document dom = null;

		if (!new File(fileLocation).exists())
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Xml parsing error" , "getXMLParsedData", "Invalid file path. Please correct to proceed.","");
			logger.error(errorMessage);
			
		}

		dom = FileUtil.xmlToDoc(fileLocation);

		
		Element rootElement = dom.getDocumentElement();
		NodeList nodeList = rootElement.getElementsByTagName("order");			

		for (int i = 0; i < nodeList.getLength(); i++)
		{
			LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			String orderNumber = "";
			
			Node element = (Node) nodeList.item(i);	
			
			if (element.getNodeType() == Node.ELEMENT_NODE) 
			{
				for(int j=0; j < element.getChildNodes().getLength(); j++)
				{
					Node childElement = element.getChildNodes().item(j);
					String childElementTagName = childElement.getNodeName();
					
					if (childElement.getNodeType() == Node.ELEMENT_NODE) 
					{
						if(childElement.getChildNodes().getLength() == 1)
						{
							String childElementValue = childElement.getTextContent();
							dataRowObject.put(childElementTagName,childElementValue);
							
							if(childElementTagName.equalsIgnoreCase("orderNumber"))
							{
								orderNumber = childElementValue;
							}
						}
						else
						{
							if(childElementTagName.equalsIgnoreCase("billingInfo") && childElement.getChildNodes().getLength() > 0)
							{
								for(int k=0; k < childElement.getChildNodes().getLength(); k++)
								{
									Node billingInfoChildElement = childElement.getChildNodes().item(k);
									String billingInfoChildElementTagName = billingInfoChildElement.getNodeName();
									
									if (billingInfoChildElement.getNodeType() == Node.ELEMENT_NODE) 
									{
									  String billingInfoChildElementTagValue = billingInfoChildElement.getTextContent();
									  dataRowObject.put(billingInfoChildElementTagName,billingInfoChildElementTagValue);
									}
								}
							}
							
							
							if(childElementTagName.equalsIgnoreCase("items") && childElement.getChildNodes().getLength() > 0)
							{	
								ArrayList<LinkedHashMap<String, Object>> itemDataList = new ArrayList<LinkedHashMap<String, Object>>();
								
								for(int k=0; k < childElement.getChildNodes().getLength(); k++)
								{
									LinkedHashMap<String, Object> itemRowObject = new LinkedHashMap<String, Object>();
									Node itemElement = childElement.getChildNodes().item(k);
									String itemElementTagName = itemElement.getNodeName();
																		
									if (itemElement.getNodeType() == Node.ELEMENT_NODE) 
									{									  
										if(itemElement.getChildNodes().getLength() > 0)
										{
											for(int l=0; l < itemElement.getChildNodes().getLength(); l++)
											{
												Node itemChildElement = itemElement.getChildNodes().item(l);
												String itemChildElementTagName = itemChildElement.getNodeName();
												
												if (itemChildElement.getNodeType() == Node.ELEMENT_NODE) 
												{
												  String itemChildElementTagValue = itemChildElement.getTextContent();
												  itemRowObject.put(itemChildElementTagName,itemChildElementTagValue);
												  
												  /*if(!itemRowObject.containsKey("orderNumber") && !orderNumber.isEmpty())
												  {
													  itemRowObject.put("orderNumber",orderNumber);
												  }*/
												}
											}
											
											if(itemRowObject.size() > 0)
											{
												itemDataList.add(itemRowObject);
												//itemDataList.add(itemRowObject);
											}
										}
									  
									}
									
									
								}
								
								dataRowObject.put("items", itemDataList);
								
							}
							
							
						}
					}
					
				}
				
				if(dataRowObject.size() > 0)
				{
					orderDataList.add(dataRowObject);
				}
			}
			
			
		}
		
		parsedOrderAndItemData.put("orderData", orderDataList);
		//parsedOrderAndItemData.put("orderItemData", itemDataList);

		return parsedOrderAndItemData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> getStaxXMLParsedData(String fileLocation) throws ParserConfigurationException, SAXException, IOException
	{
		ArrayList<LinkedHashMap<String, Object>> orderDataList = new ArrayList<LinkedHashMap<String, Object>>();
		ArrayList<LinkedHashMap<String, Object>> itemDataList = new ArrayList<LinkedHashMap<String, Object>>();
		
		try 
		{
		      URL u = new URL(fileLocation);
		      InputStream in = u.openStream();
		      XMLInputFactory factory = XMLInputFactory.newInstance();
		      XMLStreamReader parser = factory.createXMLStreamReader(in);
		        
		      int inHeader = 0;
		      String parentElementName = "";
		      String elementName = "";
		      String elementValue = "";
		      LinkedHashMap<String, Object> dataRowObject = null;
		      LinkedHashMap<String, Object> itemRowObject = null;
		      
		      for (int event = parser.next();event != XMLStreamConstants.END_DOCUMENT;event = parser.next())
		      {
		    	 
		        switch (event) 
		        {
		          case XMLStreamConstants.START_ELEMENT:
		            if (parser.getLocalName().equalsIgnoreCase("order"))
		            {
		            	if(parser.getLocalName().equalsIgnoreCase("items"))
		            	{
		            		itemRowObject = new LinkedHashMap<String, Object>();
		            	}
		            	else
		            	{
		            	  dataRowObject = new LinkedHashMap<String, Object>();
		            	}		              		              
		            }
		            elementName = parser.getLocalName();
		            break;
		          case XMLStreamConstants.END_ELEMENT:		            	              
		                          
		              if (parser.getLocalName().equalsIgnoreCase("order")) 
		              {
		            	  orderDataList.add(dataRowObject); 
		              }
		              else if (parser.getLocalName().equalsIgnoreCase("items")) 
		              {
		            	  itemDataList.add(itemRowObject);
		              }
		              else 
		              {	
		            	  if(!elementValue.isEmpty())
		            	  {
		            		  dataRowObject.put(elementName, elementValue);
		            	  }
		            	 
		            	  elementName = "";
		            	  elementValue = "";
		              }	
		            break;
		          case XMLStreamConstants.CHARACTERS: 
		            	elementValue =  parser.getText();
		            break;
		          case XMLStreamConstants.CDATA:
		            	elementValue = parser.getText();
		            break;		        
		        } // end switch
		      } // end while
		      parser.close();
		      
	    }
	    catch (XMLStreamException ex) {
	       System.out.println(ex);
	    }
	    catch (IOException ex) {
	      System.out.println("IOException while parsing " + fileLocation);
	    }
		
		return orderDataList;
	}
	
	private static boolean isHeader(String name) {
		if (name.equals("orders")) return true;
		 if (name.equals("source")) return true;
	      if (name.equals("siteId")) return true;
	      if (name.equals("orderNumber")) return true;
	      if (name.equals("subtotal")) return true;
	      if (name.equals("billingInfo")) return true;
	      if (name.equals("firstName")) return true;
	      if (name.equals("lastName")) return true;
	      if (name.equals("items")) return true;
	      if (name.equals("item")) return true;
	      if (name.equals("sku")) return true;
	      if (name.equals("name")) return true;
	      if (name.equals("subtotal")) return true;
	      return false;
	    }
	
}