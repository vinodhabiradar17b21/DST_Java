package com.increasingly.importorderdata;

import com.increasingly.importorderdata.impl.ImportOrderDataImpl;

public class ImportClientData
{	
	public void importClientData()
	{	
		ImportOrderDataImpl importOrderDataImpl = new ImportOrderDataImpl();
		importOrderDataImpl.runService();	
	}
}