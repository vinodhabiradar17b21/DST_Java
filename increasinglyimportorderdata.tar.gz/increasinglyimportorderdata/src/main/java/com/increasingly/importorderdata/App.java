package com.increasingly.importorderdata;


import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.increasingly.importorderdata.util.AESBouncyCastle;
import com.increasingly.importorderdata.util.FormatLoggerMessage;
import com.increasingly.importorderdata.util.GetProperties;

import static com.increasingly.importorderdata.util.Constants.*;



/**
 * Hello world!
 *
 */
public class App 
{
	private static final Logger logger = LoggerFactory.getLogger(App.class.getClass());
	private static Properties properties = null;
	private final static String SERVERAPPLICATIONCONTEXT = "webapp/WEB-INF/applicationContext.xml";
	private final static String SERVERPROPSFILE = "webapp/WEB-INF/service.properties";
	public static AESBouncyCastle aes;
	
    public static void main( String[] args )
    {    	
    	try
		{		
    		aes = AESBouncyCastle.getInstance("AirFrameBegining");    		
			logger.info(LOG_INFO + "Application started..");
			new FileSystemXmlApplicationContext(SERVERAPPLICATIONCONTEXT);			
			properties = GetProperties.readProperties(SERVERPROPSFILE);			
			ImportClientData importData = new ImportClientData();
			importData.importClientData();
			logger.info(LOG_INFO + "Import order data is scheduled to run at - "+ properties.getProperty("cron_timer"));
		}
		catch (Exception e)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "App" , "main", "Error reading prop file " ,"");
			logger.error(errorMessage,e);
			return;
		}
    }
}
