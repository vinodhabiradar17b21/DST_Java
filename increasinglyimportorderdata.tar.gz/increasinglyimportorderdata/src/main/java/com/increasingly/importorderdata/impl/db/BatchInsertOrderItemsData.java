package com.increasingly.importorderdata.impl.db;

import static com.increasingly.importorderdata.util.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasingly.db.BaseDB;
import com.increasingly.importorderdata.impl.OrderItemDetails;
import com.increasingly.importorderdata.interfaces.ServiceInterface;
import com.increasingly.importorderdata.util.FormatLoggerMessage;

public class BatchInsertOrderItemsData implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BatchInsertOrderItemsData.class.getClass());
				
	public Boolean runService(Map<String,Object> input) 
	{
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
		
		final ArrayList<OrderItemDetails> orderItemList = (ArrayList<OrderItemDetails>) input.get(ORDER_ITEM_LIST);
		
		String queryTmpl = "INSERT INTO bulk_order_item_details_temporary_storage"
				+ "(client_id,platform_id,client_order_id,product_id,product_name,product_price,product_url,product_sku"
				+",product_type,quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)";

		final int batchSize = 5000;        
        		
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for (OrderItemDetails orderItem : orderItemList)
					{
						
						int clientId = orderItem.getClientId();
						int platformId = orderItem.getPlatformId();	
						String orderId = orderItem.getClientOrderId();
						String productId = orderItem.getProductId();
						
					    ps.setInt(1, clientId);
						ps.setInt(2, platformId);
						ps.setNString(3, orderId);
						ps.setBytes(4, productId.getBytes());
						
						if(orderItem.getProductName() != null && !orderItem.getProductName().isEmpty())
						{
							ps.setNString(5, orderItem.getProductName());
						}
						else
						{
							ps.setNull(5, Types.NVARCHAR);
						}
																		
						if(orderItem.getProductPrice() != null && !orderItem.getProductPrice().isEmpty())
						{
							ps.setDouble(6, Double.parseDouble(orderItem.getProductPrice()));
						}
						else
						{
							ps.setNull(6, Types.DOUBLE);
						}						
			
						if(orderItem.getProductUrl() != null && !orderItem.getProductUrl().isEmpty())
						{
							ps.setNString(7, orderItem.getProductUrl());
						}
						else
						{
							ps.setNull(7, Types.NVARCHAR);
						}
												
						if(orderItem.getProductSku() != null && !orderItem.getProductSku().isEmpty())
						{
							ps.setNString(8, orderItem.getProductSku());
						}
						else
						{
							ps.setNull(8, Types.NVARCHAR);
						}
												
						if(orderItem.getProductType() != null && !orderItem.getProductType().isEmpty())
						{
							ps.setNString(9, orderItem.getProductType());
						}
						else
						{
							ps.setNull(9, Types.NVARCHAR);
						}
						
						ps.setInt(10, orderItem.getQuantity());	
						
																
						ps.addBatch();
						
					
						if (++count % batchSize == 0)
						{
							ps.executeBatch();
						}
					}
					
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}		
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BatchInsertOrderItemsData" , "Error Occured while importing order item data." ,"","");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryOrderItemDetails(input);
			return false;
		}
	}
}