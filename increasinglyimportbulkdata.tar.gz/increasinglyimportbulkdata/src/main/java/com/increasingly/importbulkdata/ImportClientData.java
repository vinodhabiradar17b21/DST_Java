package com.increasingly.importbulkdata;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasingly.importbulkdata.impl.ImportOrderDataImpl;
import com.increasingly.importbulkdata.impl.ImportProductDataImpl;
import com.increasingly.importbulkdata.util.GetProperties;

public class ImportClientData
{
	private static Properties increasinglyProperties = null;
	private static final Logger logger = LoggerFactory.getLogger(ImportClientData.class.getClass());
	
	public void importClientData()
	{				
		logger.info(LOG_INFO + "Import of client data started.");
				
		GetProperties getProperties = new GetProperties();
		increasinglyProperties = getProperties.readProperties("webapp/WEB-INF/increasingly.properties");	
		
		Integer importType = Integer.parseInt(increasinglyProperties.getProperty("importType"));
		
		if(importType == 1)
		{
		  ImportProductDataImpl importClientDataImpl = new ImportProductDataImpl();
		  importClientDataImpl.runService();
		}
		else if(importType == 2)
		{
			ImportOrderDataImpl importOrderDataImpl = new ImportOrderDataImpl();
			importOrderDataImpl.runService();
		}
		
		logger.info(LOG_INFO + "Importing of client data completed.");		

	}
}