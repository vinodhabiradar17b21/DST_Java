package com.increasingly.importbulkdata.impl;

import org.scribe.builder.api.DefaultApi10a;
import org.scribe.model.Token;

public class MagentoApi extends DefaultApi10a { 
	 static final String URL_PATTERN_AUTHORIZATION_CONSUMER = "oauth/authorize"; 
	 static final String URL_PATTERN_AUTHORIZATION_ADMIN = "admin/oauth_authorize"; 
	 
	 String baseURL = "http://www.gorgeousshop.com/"; 
	 boolean adminAPI = false; 
	 
	 
	 
	 public MagentoApi() { 
	  super(); 
	 } 
	 
	 public MagentoApi(String baseURL) { 
	  super(); 
	  this.baseURL = baseURL; 
	 } 
	 
	 public String getBaseURL() { 
	  return baseURL; 
	 } 
	 
	 public void setBaseURL(String baseURL) {   
	 
	  this.baseURL = baseURL; 
	 } 
	 
	 public boolean isAdminAPI() { 
	  return adminAPI; 
	 } 
	 
	 public void setAdminAPI(boolean adminAPI) { 
	  this.adminAPI = adminAPI;   
	 } 
	 
	 @Override 
	 public String getRequestTokenEndpoint() { 
	  return getBaseURL() + "oauth/initiate"; 
	 } 
	 
	 @Override 
	 public String getAccessTokenEndpoint() { 
	  return getBaseURL() + "oauth/token"; 
	 } 
	 
	 /**
	  * Depending on the isAdmin Flag the method returns the OAuth authorization 
	  * url for the Admin login or the consumer login. 
	  *  
	  * @param requestToken 
	  * @return OAuth Authorization URL 
	  */ 
	 @Override 
	 public String getAuthorizationUrl(Token requestToken) { 
	  if (isAdminAPI()) { 
	   return getBaseURL() + URL_PATTERN_AUTHORIZATION_ADMIN 
	     + "?oauth_token=" + requestToken.getToken(); 
	  } else 
	   return getBaseURL() + URL_PATTERN_AUTHORIZATION_CONSUMER 
	     + "?oauth_token=" + requestToken.getToken(); 
	 } 
	 
	}