package com.increasingly.importbulkdata.impl.db;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasingly.db.BaseDB;
import com.increasingly.importbulkdata.interfaces.ServiceInterface;

public class GetOrderDataFieldMappingDetails extends StoredProcedure implements ServiceInterface<ArrayList<Map<String, String>>>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Get_Order_Data_Field_Mapping_Details";	
	private static GetOrderDataFieldMappingDetails instance = null;
	
	private GetOrderDataFieldMappingDetails()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ClientId", Types.VARCHAR));
		compile();		
	}

	public static GetOrderDataFieldMappingDetails getInstance()
	{
		if (instance == null)
		{
			instance = new GetOrderDataFieldMappingDetails();
		}
		return instance;
	}

	public ArrayList<Map<String, String>> runService(Map<String, Object> input)
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);	
		ArrayList<Map<String, String>> fieldMappingDetails = (ArrayList<Map<String, String>>) execute(clientId).get("#result-set-1");
		return fieldMappingDetails;
	}
}