package com.increasingly.importbulkdata.impl.db;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasingly.db.BaseDB;
import com.increasingly.importbulkdata.impl.OrderDetails;
import com.increasingly.importbulkdata.util.FormatLoggerMessage;


public class BatchInsertOrderData
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BatchInsertOrderData.class.getClass());
	
	public Boolean runService(Map<String,Object> input) 
	{	
       
        
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
				
		String queryTmpl = "INSERT INTO order_details_temporary_storage"
				+ "(client_id,platform_id,client_order_id,order_status,order_amount,order_time,coupon_code,"
				+ "discount_amount,tax_amount,shipping_amount,shipping_method,currency_code,payment_method,"
				+ "user_ip,user_agent,email,name,first_name,last_name,increasingly_version,visitor_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?)";

		final int batchSize = 5000; 

		final ArrayList<OrderDetails> finalOrderList =  (ArrayList<OrderDetails>)input.get(ORDER_LIST);
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for(OrderDetails order : finalOrderList)
					{	
						ps.setInt(1, order.getClientId());
						ps.setInt(2, order.getPlatformId());
						ps.setNString(3, order.getClientOrderId());
						
						if(order.getOrderStatus() != null && !order.getOrderStatus().isEmpty())
						{   
							ps.setNString(4, order.getOrderStatus());
						}
						else
						{
							ps.setNull(4,Types.NVARCHAR);
						}
					
						if(order.getOrderAmount() != null && !order.getOrderAmount().isEmpty())
						{   
							ps.setDouble(5, Double.parseDouble(order.getOrderAmount()));
						}
						else
						{
							ps.setNull(5,Types.DOUBLE);
						}
						
						if(order.getOrderTime() != null && !order.getOrderTime().isEmpty())
						{	
							ps.setString(6, order.getOrderTime());
						}
						else
						{
							ps.setNull(6,Types.VARCHAR);
						}
					
						if(order.getCouponCode() != null && !order.getCouponCode().isEmpty())
						{   
							ps.setNString(7, order.getCouponCode());
						}
						else
						{
							ps.setNull(7,Types.NVARCHAR);
						}
					
						if(order.getDiscountAmount() != null && !order.getDiscountAmount().isEmpty())
						{   
							ps.setDouble(8, Double.parseDouble(order.getDiscountAmount()));
						}
						else
						{
							ps.setNull(8,Types.DOUBLE);
						}
						
						if(order.getTaxAmount() != null && !order.getTaxAmount().isEmpty())
						{   
							ps.setDouble(9, Double.parseDouble(order.getTaxAmount()));
						}
						else
						{
							ps.setNull(9,Types.DOUBLE);
						}
						
						if(order.getShippingAmount() != null && !order.getShippingAmount().isEmpty())
						{   
							ps.setDouble(10, Double.parseDouble(order.getShippingAmount()));
						}
						else
						{
							ps.setNull(10,Types.DOUBLE);
						}
						
						if(order.getShippingMethod() != null && !order.getShippingMethod().isEmpty())
						{   
							ps.setNString(11, order.getShippingMethod());
						}
						else
						{
							ps.setNull(11,Types.NVARCHAR);
						}
						
						if(order.getCurrencyCode() != null && !order.getCurrencyCode().isEmpty())
						{   
							ps.setNString(12, order.getCurrencyCode());
						}
						else
						{
							ps.setNull(12,Types.NVARCHAR);
						}
												
						if(order.getPaymentMethod() != null && !order.getPaymentMethod().isEmpty())
						{   
							ps.setNString(13, order.getPaymentMethod());
						}
						else
						{
							ps.setNull(13,Types.NVARCHAR);
						}						
						
						if(order.getUserIp() != null && !order.getUserIp().isEmpty())
						{   
							ps.setString(14, order.getUserIp());
						}
						else
						{
							ps.setNull(14,Types.VARCHAR);
						}						
						
						if(order.getUserAgent() != null && !order.getUserAgent().isEmpty())
						{   
							ps.setString(15, order.getUserAgent());
						}
						else
						{
							ps.setNull(15,Types.VARCHAR);
						}
						
						if(order.getCustomerEmailAddress() != null && !order.getCustomerEmailAddress().isEmpty())
						{   
							ps.setNString(16, order.getCustomerEmailAddress());
						}
						else
						{
							ps.setNull(16,Types.NVARCHAR);
						}
												
						if(order.getCustomerName() != null && !order.getCustomerName().isEmpty())
						{   
							ps.setNString(17, order.getCustomerName());
						}
						else
						{
							ps.setNull(17,Types.NVARCHAR);
						}
												
						if(order.getCustomerFirstName() != null && !order.getCustomerFirstName().isEmpty())
						{   
							ps.setNString(18, order.getCustomerFirstName());
						}
						else
						{
							ps.setNull(18,Types.NVARCHAR);
						}
												
						if(order.getCustomerLastName() != null && !order.getCustomerLastName().isEmpty())
						{   
							ps.setNString(19, order.getCustomerLastName());
						}
						else
						{
							ps.setNull(19,Types.NVARCHAR);
						}
					
						if(order.getVersion() != null && !order.getVersion().isEmpty())
						{   
							ps.setString(20, order.getVersion());
						}
						else
						{
							ps.setNull(20,Types.VARCHAR);
						}
						
												
						if(order.getVisitorId() != null && !order.getVisitorId().isEmpty())
						{   
							ps.setString(21, order.getVisitorId());
						}
						else
						{
							ps.setNull(21,Types.VARCHAR);
						}
						
						ps.addBatch();
							
						if (++count % batchSize == 0)
						{
						  ps.executeBatch();
						}							
					}
										
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BulkInsertOrderData" , "Error Occured while importing order data." ,"","");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryOrderDetails(input);
			
			return false;
		}
	}
}