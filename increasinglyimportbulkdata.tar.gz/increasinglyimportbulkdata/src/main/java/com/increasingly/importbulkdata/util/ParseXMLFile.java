package com.increasingly.importbulkdata.util;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.increasingly.importbulkdata.impl.db.ErrorLog;




public class ParseXMLFile
{
	private static final Logger logger = LoggerFactory.getLogger(ParseXMLFile.class.getClass());

	public ArrayList<LinkedHashMap<String, Object>> getXMLParsedData(String fileLocation,String customizationType) 
	{
		ArrayList<LinkedHashMap<String, Object>> catalogueList = new ArrayList<LinkedHashMap<String, Object>>();
		
		try
		{						
					
			  if (!new File(fileLocation).exists())
			  {
	    		 ErrorLog.saveErrorLogToDB("ParseXMLFile.java getXMLParsedData()","Invalid file path. Please correct to proceed.","");
				 throw new Exception("Invalid file path. Please correct to proceed.");
			  }
			
			  DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
		      DocumentBuilder builder = factory1.newDocumentBuilder();
		       
		      //Build Document
		      Document document = builder.parse(new File(fileLocation));
		       
		      //Normalize the XML Structure; It's just too important !!
		      document.getDocumentElement().normalize();
		       
		      //Here comes the root node
		      Element root = document.getDocumentElement();
		     			       
		      if(customizationType.equals("collins"))
		      {
			      NodeList nRecordList = document.getElementsByTagName("record");
			      
			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = null;
			    		 dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					         Node node = childFieldNodeList.item(temp);					        
					         
					         if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName() == "fields")
					         {
					        	 NodeList childNodeList = node.getChildNodes();
					        	 
					        	 String elementName = "";
								 String elementValue = "";								 
								 
					        	 for (int j = 0; j < childNodeList.getLength(); j++)
							     {			        		
							        Node childNode = childNodeList.item(j);
							        
							        if (childNode.hasAttributes())
							        {
						               // get attributes names and values
						               NamedNodeMap nodeMap = childNode.getAttributes();
						               for (int i = 0; i < nodeMap.getLength(); i++)
						               {
						                   Node tempNode = nodeMap.item(i);
						                   elementName = tempNode.getNodeValue();
						                   break;
						               }
							        }
							    
							        
							        if(childNode.hasChildNodes() && (elementName.equals("id") || elementName.equals("Author") || 
							        		elementName.equals("format") || elementName.equals("brand") || elementName.equals("publicationDate")
							        		|| elementName.equals("name") || elementName.equals("shortDescription") || elementName.equals("brand")
							        		|| elementName.equals("prices") || elementName.equals("wasPrice") || elementName.equals("featureDescription")
							        		|| elementName.equals("cost_price") || elementName.equals("imageUrl") || elementName.equals("categories")))
							        {						        
							        	  for (int k = 0; k < childNode.getChildNodes().getLength(); k++)
									      {							    	 							    	 
									         Node valuesNode = childNode.getChildNodes().item(k);
									         
									         if (valuesNode.getNodeType() == Node.ELEMENT_NODE)
									         {							        	
								        		elementValue = valuesNode.getTextContent().trim();
								        		
								        		 if(!elementName.isEmpty() && !elementValue.isEmpty())
									        	 {
									        		 dataRowObject.put(elementName, elementValue);
									        	 }	
									         }
									      }
							        }
							        
							     }			        	 
					        	 
					         }
					         else if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName() == "categories")
					         {
					        	 
					        	 if(node.hasChildNodes())
					        	 {
						        	 NodeList childNodeList = node.getChildNodes();
						        	 					        	
									 String categoryList = "";
									
						        	 for (int j = 0; j < childNodeList.getLength(); j++)
								     {			        		
								        Node childNode = childNodeList.item(j);
								        				    
								        
								        if(childNode.hasChildNodes())
								        {						        
								        	  for (int k = 0; k < childNode.getChildNodes().getLength(); k++)
										      {							    	 							    	 
										         Node valuesNode = childNode.getChildNodes().item(k);
										         
										         if (valuesNode.getNodeType() == Node.ELEMENT_NODE)
										         {							        	
									        		String elementValue = valuesNode.getTextContent().trim();
									        		
									        		 if(!elementValue.isEmpty())
										        	 {
									        			 if(categoryList.isEmpty())
									        			 {
									        				 categoryList = elementValue; 
									        			 }
									        			 else
									        			 {
									        			   categoryList = categoryList + "," + elementValue;
									        			 }
										        	 }	
										         }
										      }
								        }
								        
								     }	
						        	 
						        	 if(!categoryList.isEmpty())
						        	 {
						        		 dataRowObject.put("categories", categoryList);
						        	 }
					        	 }
					        	 
					         }				      
					        
					      }
					      
					      if(dataRowObject != null)
					      {	
					    	   if(dataRowObject.get("id") != null && !dataRowObject.get("id").toString().isEmpty())
					    	   {
					    		   
					    		 dataRowObject.put("ISBNNumber", dataRowObject.get("id").toString());
					    	     dataRowObject.put("link", "https://www.collins.co.uk/index.html");
					    	     dataRowObject.put("quantity", 1);
					        	 catalogueList.add(dataRowObject);		
					    	   }
					    	   else
					    	   {
					    		   System.out.println("Product Id doesn't exist.");
					    	   }
					      }
			    	 }
			      }
		      }
		      else if(customizationType.equals("travis-perkins"))
		      {
		    	 
		    	  NodeList nRecordList = document.getElementsByTagName("item");
			      
			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE)
						      {		
					    		  if(!dataRowObject.containsKey(node.getNodeName()))
					    		  {  
					    			  if(node.getNodeName().equals("g:price"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace(" GBP", "")); 
					    			  }
					    			  else if(node.getNodeName().equals("g:sale_price"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace(" GBP", "")); 
					    			  }
					    			  else if(node.getNodeName().equals("g:product_type"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace("0. ", ""));					    				  
					    			  }
					    			  else if(node.getNodeName().equals("g:availability"))
					    			  {
					    				  if(node.getTextContent().equals("in stock"))
					    				  {
					    					  dataRowObject.put(node.getNodeName(),100000);
					    				  }
					    				  else
					    				  {
					    					  dataRowObject.put(node.getNodeName(),0); 
					    				  }
					    				  
					    			  }
					    			  else
					    			  {
					    		        dataRowObject.put(node.getNodeName(),node.getTextContent());	
					    			  }
					    		  }
						      }
					      }
					      
					      catalogueList.add(dataRowObject);
			    	 }
			      }			      
			      
		      }
		      else if(customizationType.equals("smws"))
		      {
		    	 
		    	  NodeList nRecordList = document.getElementsByTagName("Product");
			      
			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 Boolean isProductArchieved = false;
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE)
						      {		
					    		  if(!dataRowObject.containsKey(node.getNodeName()))
					    		  {  
					    		      dataRowObject.put(node.getNodeName(),node.getTextContent());	
					    		      
					    		      if(node.getNodeName().toString().equalsIgnoreCase("Categories") && node.getTextContent().toString().contains("Archive"))
					    		      {
					    		    	  isProductArchieved = true;
					    		    	  break;
					    		      }
					    		  }
						      }
					      }
					      
					      if(!isProductArchieved)
					      {
					    	 catalogueList.add(dataRowObject);
					      }
			    	 }
			      }	
		      }
		      else if(customizationType.equals("leekes"))
		      {
		    	  NodeList nRecordList = document.getElementsByTagName("item");
			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE)
						      {		
					    		  if(!dataRowObject.containsKey(node.getNodeName()) || node.getNodeName().equals("g:product_type"))
					    		  {  
					    			  if(node.getNodeName().equals("g:price"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace("GBP", "").trim()); 
					    			  }
					    			  else if(node.getNodeName().equals("g:sale_price"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace("GBP", "").trim()); 
					    			  }
					    			  else if(node.getNodeName().equals("g:availability"))
					    			  {
					    				  if(node.getTextContent().equals("in stock"))
					    				  {
					    					  dataRowObject.put(node.getNodeName(),1000);
					    				  }
					    				  else
					    				  {
					    					  dataRowObject.put(node.getNodeName(),0); 
					    				  }
					    				  
					    			  }
					    			  else if(node.getNodeName().equals("g:product_type"))
					    			  {
					    				  String productType = "";
					    				  
					    				  if(!node.getTextContent().trim().contains("Sale") && !node.getTextContent().trim().contains("sale"))
					    				  {
						    				  if(dataRowObject.get(node.getNodeName()) != null && node.getTextContent().trim().length() > 0)
						    				  {
						    					  String[] productTypeList = node.getTextContent().trim().split(">");
						    					  productType = dataRowObject.get(node.getNodeName()).toString() + '>' + productTypeList[productTypeList.length - 1];
						    				  }
						    				  else
						    				  {
						    					  String[] productTypeList = node.getTextContent().trim().split(">");
						    					  productType = productTypeList[productTypeList.length - 1];
						    				  }
						    				  
						    				  dataRowObject.put(node.getNodeName(),productType);
					    				  }
					    			  }
					    			  else if(node.getNodeName().equals("increasingly_product_visibility"))
					    			  {
					    				  if(node.getTextContent().trim().length() > 0)
					    				  {
					    					  if(node.getTextContent().trim().equals("4"))
					    					  {
					    						  dataRowObject.put(node.getNodeName(),"Catalog,Search");
					    					  }
					    					  else if(node.getTextContent().trim().equals("3"))
					    					  {
					    						  dataRowObject.put(node.getNodeName(),"Search");
					    					  }
					    					  else if(node.getTextContent().trim().equals("2"))
					    					  {
					    						  dataRowObject.put(node.getNodeName(),"Catalog");
					    					  }
					    					  else if(node.getTextContent().trim().equals("1"))
					    					  {
					    						  dataRowObject.put(node.getNodeName(),"Not Visible Individually");
					    					  }
					    				  }
					    			  }
					    			  else if(node.getNodeName().equals("msrp"))
					    			  {
					    				  dataRowObject.put(node.getNodeName(),node.getTextContent().trim().replace("GBP", "").trim()); 
					    			  }
					    			  else
					    			  {
					    		        dataRowObject.put(node.getNodeName(),node.getTextContent());	
					    			  }
					    		  }
						      }
					      }
					      
					      catalogueList.add(dataRowObject);
			    	 }
			      }
		      }
		      else if(customizationType.equals("inov-8"))
		      {
		    	 
		    	  NodeList nRecordList = document.getElementsByTagName("Product");
			      			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE)
						      {		
					    		  if(!dataRowObject.containsKey(node.getNodeName()))
					    		  {  
					    			  dataRowObject.put(node.getNodeName(),node.getTextContent());	
					    		  }
						      }
					      }
					      
					      catalogueList.add(dataRowObject);
			    	 }
			      }			      
		      }
		      else if(customizationType.equals("samsung"))
		      {
		    	 
		    	  NodeList nRecordList = document.getElementsByTagName("product");
			      			      
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName() != "categories")
						      {		
					    		  if(!dataRowObject.containsKey(node.getNodeName()))
					    		  {  
					    			  dataRowObject.put(node.getNodeName(),node.getTextContent());	
					    		  }
						      }
					    	  else if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName() == "categories")
						      {						        	 
						        	 if(node.hasChildNodes())
						        	 {
							        	 NodeList childNodeList = node.getChildNodes();
							        	 					        	
										 String categoryList = "";
										
							        	 for (int j = 0; j < childNodeList.getLength(); j++)
									     {			        		
									        Node childNode = childNodeList.item(j);
									        				    
									        
									        if(childNode.hasChildNodes())
									        {						        
									        	  for (int k = 0; k < childNode.getChildNodes().getLength(); k++)
											      {							    	 							    	 
											         Node valuesNode = childNode.getChildNodes().item(k);
											         
											         if (valuesNode.getNodeType() == Node.ELEMENT_NODE && valuesNode.getNodeName() == "category_name")
											         {							        	
										        		String elementValue = valuesNode.getTextContent().trim();
										        		
										        		 if(!elementValue.isEmpty())
											        	 {
										        			 if(categoryList.isEmpty())
										        			 {
										        				 categoryList = elementValue; 
										        			 }
										        			 else
										        			 {
										        			   categoryList = categoryList + "|" + elementValue;
										        			 }
											        	 }	
											         }
											      }
									        }
									        
									     }	
							        	 
							        	 if(!categoryList.isEmpty())
							        	 {
							        		 dataRowObject.put("merchant_category", categoryList);
							        	 }
						        	 }
						        	 
						         }		
					    	  
					      }
					      
					      catalogueList.add(dataRowObject);
			    	 }
			      }			      
		      }
		      else if(customizationType.equals("kingwin"))
		      {
		    	 
		    	  NodeList nRecordList = document.getElementsByTagName("item");
			      for (int l = 0; l < nRecordList.getLength(); l++)
			      {		       
			    	 Node nFieldNode = nRecordList.item(l);
			    	 
			    	 if(nFieldNode.getNodeType() == Node.ELEMENT_NODE)
			    	 {
			    		 NodeList childFieldNodeList = nFieldNode.getChildNodes();
			    		 
			    		 LinkedHashMap<String, Object> dataRowObject = new LinkedHashMap<String, Object>();
			    		 
					      for (int temp = 0; temp < childFieldNodeList.getLength(); temp++)
					      { 
					    	  Node node = childFieldNodeList.item(temp);
					    	  
					    	  if(node.getNodeType() == Node.ELEMENT_NODE)
						      {		
					    		  dataRowObject.put(node.getNodeName(),node.getTextContent());	
						      }
					      }
					      
					      catalogueList.add(dataRowObject);
			    	 }
			      }			      
		      }
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ParseXMLFile" , "getXMLParsedData", "Error occured while parsing feed data","");
			logger.error(errorMessage,ex);
   		    ErrorLog.saveErrorLogToDB("ParseXMLFile.java getXMLParsedData()","Error occured while parsing feed data.",ex.getMessage());
		}		
		
		return catalogueList;
	}
	
	
	
	
	
	
}