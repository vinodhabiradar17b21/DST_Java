package com.increasingly.importbulkdata.impl;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.increasingly.importbulkdata.impl.db.ErrorLog;
import com.increasingly.importbulkdata.impl.db.GetClientProductColorCodeDetails;
import com.increasingly.importbulkdata.util.FileUtil;
import com.increasingly.importbulkdata.util.FormatLoggerMessage;

public class Customizations
{
	private static final Logger logger = LoggerFactory.getLogger(Customizations.class.getClass());
			
	public ArrayList<LinkedHashMap<String, Object>> customizeCycleStore(ArrayList<LinkedHashMap<String, Object>> productData) 
	{	
		ArrayList<LinkedHashMap<String, Object>> finalProductList = new ArrayList<LinkedHashMap<String, Object>>();
		Map<String,LinkedHashMap<String, Object>> tempProductList = new HashMap<String,LinkedHashMap<String, Object>>();
		
		try
		{
			for(LinkedHashMap<String,Object> item : productData)
	        {
				if(tempProductList.containsKey(item.get("ID")))
				{
					LinkedHashMap<String, Object> finalItem = tempProductList.get(item.get("ID"));
					ArrayList<LinkedHashMap<String,Object>> tempProductOptions = (ArrayList<LinkedHashMap<String,Object>>)finalItem.get("Product Attributes");
					
					if(item.get("optionID") != null && item.get("optionText") != null)
					{
						if(!item.get("optionID").toString().equalsIgnoreCase("NULL") && !item.get("optionID").toString().isEmpty() &&
								!item.get("optionText").toString().equalsIgnoreCase("NULL") && !item.get("optionText").toString().isEmpty())
						{
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
							
							productOption.put("AttributeCode", "option");
							productOption.put("AttributeId", "1");
							productOption.put("AttributeLabel", "Option");
							productOption.put("optionID", item.get("optionID"));
							productOption.put("optionText", item.get("optionText"));
							tempProductOptions.add(productOption);						
							
						}
					}
				}
				else
				{
					ArrayList<LinkedHashMap<String,Object>> productOptions = new ArrayList<LinkedHashMap<String,Object>>();
					
					if(item.get("Product Type").equals("grouped"))
					{
						item.put("Product Type", "configurable");
					}
					
					if(item.get("Product Status").equals("active"))
					{
						item.put("Product Status", 1);
					}
					else if(!item.get("Product Status").equals("active"))
					{
						item.put("Product Status", 2);
					}
					
					if(item.get("Stock").equals("NULL") || item.get("Stock").toString().isEmpty())
					{
						item.put("Stock", 0);
					}
					
					if(item.get("optionID") != null && item.get("optionText") != null)
					{
						if(!item.get("optionID").toString().equalsIgnoreCase("NULL") && !item.get("optionID").toString().isEmpty() && !item.get("optionText").toString().equalsIgnoreCase("NULL")
								&& !item.get("optionText").toString().isEmpty())
						{
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
							
							productOption.put("AttributeCode", "option");
							productOption.put("AttributeId", "1");
							productOption.put("AttributeLabel", "Option");
							productOption.put("optionID", item.get("optionID"));
							productOption.put("optionText", item.get("optionText"));
							productOptions.add(productOption);
							item.put("Product Attributes",productOptions);
						}
					}	
					
					if(!item.get("ID").toString().isEmpty())
					{
						tempProductList.put(item.get("ID").toString(), item);
					}
				}				
				
	        }
			
			for(Map.Entry<String, LinkedHashMap<String, Object>> entry : tempProductList.entrySet())
	        {
				finalProductList.add(entry.getValue());
	        }
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeCycleStore", "Error occured while customizing Cycle Store feed ","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeCycleStore()", "Error occured while customizing Cycle Store feed", ex.getMessage());
		}
		
		return finalProductList;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeZestBeauty(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
		for(Map<String,Object> item : productData)
        {
			if(item.get(fieldMappingDetails.get(PRODUCT_URL)) != null && item.get(fieldMappingDetails.get(PRODUCT_NAME)) != null)
        	{
			   String productName = (String)item.get(fieldMappingDetails.get(PRODUCT_NAME));
			   String productUrl = (String)item.get(fieldMappingDetails.get(PRODUCT_URL));
			   
			   if(productUrl.contains("dermalogica") && productName.contains("Dermalogica"))
			   {
				   productUrl = productUrl.replace("www.zestbeauty.com", "www.zestbeauty.com/dermalogica");
			   }
			   
			   item.put(fieldMappingDetails.get(PRODUCT_URL), productUrl);
        	 
        	}
        }
		
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeSamsungFeed(ArrayList<LinkedHashMap<String, Object>> productData) 
	{	
		for(Map<String,Object> item : productData)
        {
			if(item.get("availability").equals("In stock"))
			{
				item.put("in_stock", 1000);
			}
			else
			{
				item.put("in_stock", 0);
			}	
			
			if(item.get("deeplink") != null && !item.get("deeplink").toString().isEmpty())
			{
				//String deepLink = item.get("deeplink").toString().split("wgtarget=")[1];
				String deepLink = item.get("deeplink").toString();
				item.put("deeplink", deepLink);
			}			
			
			
			if(item.get("merchant_category") != null && !item.get("merchant_category").toString().isEmpty())
        	{
			   String merchantCategory = (String)item.get("merchant_category");			 
			   item.put("merchant_category", merchantCategory.toLowerCase().replace("&", "and"));
        	 
        	}
			
			if(item.get("recommended_retail_price") != null && !item.get("recommended_retail_price").toString().isEmpty())	
			{
				double rrp = Double.valueOf(item.get("recommended_retail_price").toString());
				
				if(rrp <= 0)
				{
					if(item.get("price") != null && !item.get("price").toString().isEmpty())
					{
						double price = Double.valueOf(item.get("price").toString());
						
						if(price > 0)
						{
							item.put("recommended_retail_price", price);
						}
						else
						{
							productData.remove(item);
						}
					}
					else
					{
						productData.remove(item);
					}
				}
			}
			else
			{
				if(item.get("price") != null && !item.get("price").toString().isEmpty())
				{
					double price = Double.valueOf(item.get("price").toString());
					
					if(price > 0)
					{
						item.put("recommended_retail_price", price);
					}
					else
					{
						productData.remove(item);
					}
				}
				else
				{
					productData.remove(item);
				}
			}
        }
		
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeCurrentBodyFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails,Integer feedId) 
	{	
		try
		{
			LinkedHashMap<String,Object> colorMapping = new LinkedHashMap<String,Object>();
			Map<String,Object> input = new HashMap<String,Object>();
			input.put(FEED_ID, feedId);
		
		GetClientProductColorCodeDetails getClientProductColorCodeDetails = GetClientProductColorCodeDetails.getInstance();
		colorMapping = getClientProductColorCodeDetails.runService(input);
		
		for(Map<String,Object> item : productData)
        {
			if(item.get(fieldMappingDetails.get(PRODUCT_PRICE)) != null && !item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString().isEmpty())
        	{
			   double price = Double.valueOf(item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString());
			   price = price + (price * 0.20); // Add VAT amount of 20% to the base price of the product.
			   
			   item.put(fieldMappingDetails.get(PRODUCT_PRICE), price);
        	 
        	}
			
			if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
        	{
			   double specialPrice = Double.valueOf(item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString());
			   
			   if(specialPrice > 0)
			   {
			      specialPrice = specialPrice + (specialPrice * 0.20); // Add VAT amount of 20% to the base price of the product.
			   
			      item.put(fieldMappingDetails.get(SPECIAL_PRICE), specialPrice);
			   }
        	 
        	}
			
			if(item.get(fieldMappingDetails.get(PRODUCT_ID)) != null && !item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().isEmpty())
        	{
				if(item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("1430") || item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("110")
					|| item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("108") || item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("1527")
					|| item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("700") || item.get(fieldMappingDetails.get(PRODUCT_ID)).toString().equalsIgnoreCase("701"))
				{
					item.put(fieldMappingDetails.get(VISIBILITY), "Catalog");
				}
        	}
			
			if(item.get(fieldMappingDetails.get(PRODUCT_OPTIONS)) != null)
        	{	
    			ArrayList<LinkedHashMap<String,Object>> productOptions = (ArrayList<LinkedHashMap<String,Object>>)item.get(fieldMappingDetails.get(PRODUCT_OPTIONS));
    			
    			if(productOptions != null)
    			{
    				try
    				{        				
        				for(LinkedHashMap<String,Object> option : productOptions)
				        {	        					
        					if(option.get(fieldMappingDetails.get(ATTRIBUTE_ID)) != null)
        					{
	        					String attributeId = (String)option.get(fieldMappingDetails.get(ATTRIBUTE_ID));
	        					
	        					if(attributeId.equals("92"))
	        					{        			
	        						
		        					if(option.get(fieldMappingDetails.get(OPTION_ID)) != null)
		        					{		        					   
		        					   String optionId= String.valueOf(option.get(fieldMappingDetails.get(OPTION_ID)));
		        					   String colorCode = (String)colorMapping.get(optionId);	
		        					   option.put(COLOR_CODE, colorCode);
		        					}
	        					}
        					}
        					
        					
        					if(option.get(fieldMappingDetails.get(PRICING_VALUE)) != null)
        					{
        						Integer isPercent = 0;
        						if(option.get(fieldMappingDetails.get(IS_PERCENT)) != null)
        						{
        							isPercent = Integer.parseInt((String)option.get(fieldMappingDetails.get(IS_PERCENT)));
        						}
        						
        						if(isPercent == 0)
        						{
        							double pricingValue = Double.valueOf(option.get(fieldMappingDetails.get(PRICING_VALUE)).toString());
        							
        							 if(pricingValue > 0)
        							 {
        								 pricingValue = pricingValue + (pricingValue * 0.20); // Add VAT amount of 20% to the base price of the product.
        							   
        								 option.put(fieldMappingDetails.get(PRICING_VALUE), pricingValue);
        							 }
        							
        						}
	        					
        					}
        					
				        }
        				
        				
    				}
    				catch(Exception ex)
    				{    					
    					String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeCurrentBodyFeed", "Error occured while setting color mapping","");
    					logger.error(errorMessage,ex);
    					ErrorLog.saveErrorLogToDB("Customizations.java customizeCurrentBodyFeed()", "Error occured while setting color mapping", ex.getMessage());
    				}
    				
    			}
        	}
        	
        }
		
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeCurrentBodyFeed", "Error occured while setting color mapping","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeCurrentBodyFeed()", "Error occured while customizing Current Body feed", ex.getMessage());
		}
		
		return productData;
	}

	public ArrayList<LinkedHashMap<String, Object>> customizeSoakAndSleepFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails,Integer feedId) 
	{	
		try
		{
		
			for(Map<String,Object> item : productData)
	        {
				if(item.get(fieldMappingDetails.get(PRODUCT_PRICE)) != null && !item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString().isEmpty())
	        	{
				   double price = Double.valueOf(item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString());
				   price = price + (price * 0.20); // Add VAT amount of 20% to the base price of the product.
				   
				   item.put(fieldMappingDetails.get(PRODUCT_PRICE), price);
	        	 
	        	}
				
				if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
	        	{
				   double specialPrice = Double.valueOf(item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString());
				   
				   if(specialPrice > 0)
				   {
				      specialPrice = specialPrice + (specialPrice * 0.20); // Add VAT amount of 20% to the base price of the product.
				   
				      item.put(fieldMappingDetails.get(SPECIAL_PRICE), specialPrice);
				   }
	        	 
	        	}
				
				if(item.get(ATTRIBUTE_DETAILS) != null)
	        	{	
	    			ArrayList<LinkedHashMap<String,Object>> attributeDetails = (ArrayList<LinkedHashMap<String,Object>>)item.get(ATTRIBUTE_DETAILS);
	    			
	    			if(attributeDetails != null)
	    			{
	    				try
	    				{        				
	        				for(LinkedHashMap<String,Object> attribute : attributeDetails)
					        {	        					
	        					if(attribute.get(ATTRIBUTE_ID) != null)
	        					{
		        					String attributeId = (String)attribute.get(ATTRIBUTE_ID);
		        					
		        					if(attributeId.equals("203"))
		        					{        			
		        						
			        					if(attribute.get(OPTION_ID) != null)
			        					{		        					   
			        					   double highStreetPrice = Double.valueOf(attribute.get(OPTION_ID).toString());
			        					   item.put("High Street Price", highStreetPrice);			        					  
			        					}
		        					}	
		        					
		        					if(attributeId.equals("505"))
	                                {       
                                        if(attribute.get(OPTION_ID) != null && !attribute.get(OPTION_ID).toString().equalsIgnoreCase("no"))
                                        {        
                                           String groupColour = attribute.get(OPTION_ID).toString();
                                           item.put("group_colour", groupColour);
                                        }
	                                }
	        					}
					        }
	        				
	        				
	    				}
	    				catch(Exception ex)
	    				{    					
	    					String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeSoakAndSleepFeed", "Error occured while setting color mapping","");
	    					logger.error(errorMessage,ex);
	    					ErrorLog.saveErrorLogToDB("Customizations.java customizeSoakAndSleepFeed()", "Error occured while setting color mapping", ex.getMessage());
	    				}
	    				
	    			}
	        	}
	        	
	        }
		
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeSoakAndSleepFeed", "Error occured while setting color mapping","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeSoakAndSleepFeed()", "Error occured while customizing Soak & Sleep feed", ex.getMessage());
		}
		
		return productData;
	}

	public ArrayList<LinkedHashMap<String, Object>> customizeIMOMOKOFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails,Integer feedId) 
	{	
		try
		{
			
			for(Map<String,Object> item : productData)
	        {	
				
				if(item.get(fieldMappingDetails.get(VISIBILITY)) != null && !item.get(fieldMappingDetails.get(VISIBILITY)).toString().isEmpty())
	        	{
					Integer visibility = Integer.parseInt(item.get(fieldMappingDetails.get(VISIBILITY)).toString());
					String visibilityText = "Not Visible Individually";
					
					if(visibility == 1)
					{
						visibilityText = "Not Visible Individually";
					}
					else if(visibility == 2)
					{
						visibilityText = "Catalog";
					}
					else if(visibility == 3)
					{
						visibilityText = "Search";
					}
					else if(visibility == 4)
					{
						visibilityText = "Catalog, Search";
					}
					
					item.put(fieldMappingDetails.get(VISIBILITY), visibilityText);
					
	        	}
				
				DateTime specialPriceFromDate = null;
				DateTime specialPriceToDate = null;
				
				if(item.get("special_from_date") != null)
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spStartDate = sdf.parse(item.get("special_from_date").toString());
					specialPriceFromDate = new DateTime(spStartDate);
				}
				
				if(item.get("special_to_date") != null)
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spEndDate = sdf.parse(item.get("special_to_date").toString());
					specialPriceToDate = new DateTime(spEndDate);
					
				}
				
				if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
	        	{
				   DateTime todaysDate = new DateTime();
				   
				   if(specialPriceFromDate != null && todaysDate.isBefore(specialPriceFromDate))
				   {				      
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);				      
				   }
				   
				   if(specialPriceToDate != null && todaysDate.isAfter(specialPriceToDate))
				   {
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);
				   }
	        	 
	        	}
	        	
	        }
		
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeIMOMOKOFeed", "Error occured while setting color mapping","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeIMOMOKOFeed()", "Error occured while customizing IMOMOKO feed", ex.getMessage());
		}
		
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeTravisPerkins(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
		LinkedHashMap<String, LinkedHashMap<String,Object>> configurableProducts = new LinkedHashMap<String, LinkedHashMap<String,Object>>();
        for(Map<String,Object> item : productData)
        {
        	if(item.get("g:sale_price") != null && item.get("g:sale_price") != null)
        	{	
			   item.put(fieldMappingDetails.get(PRODUCT_PRICE), item.get("g:sale_price"));        	 
        	}
			
			if(item.get("g:item_group_id") != null && !item.get("g:item_group_id").toString().trim().isEmpty())
        	{				   
			   LinkedHashMap<String,Object> mainConfigurableProduct = new LinkedHashMap<String,Object>(item);
			   
			   String configurableProductId="";
			   String url="";
			   
			   if(!configurableProducts.containsKey(item.get("g:item_group_id")))
			   {
				   configurableProductId = item.get("g:item_group_id").toString();
				   url = item.get("link").toString().split("/p/")[0]+"/p/"+configurableProductId;
				   mainConfigurableProduct.put("g:id", configurableProductId);
				   mainConfigurableProduct.put("link", url);
				   mainConfigurableProduct.put("type", "configurable");
				   
				   /*if(item.get(fieldMappingDetails.get(PRODUCT_NAME)) != null)
		           {
					   productName = item.get(fieldMappingDetails.get(PRODUCT_NAME)).toString();
					   if(item.get("g:size") !=null && !item.get("g:size").toString().trim().isEmpty())
					   {
						   size = item.get("g:size").toString().trim();
					   }
					   regex = "."+size;
		           }*/
				   
				   ArrayList<LinkedHashMap<String,Object>> productOptions = new ArrayList<LinkedHashMap<String,Object>>();

				   if(item.get("g:size") != null)
					{
						if(!item.get("g:size").toString().equalsIgnoreCase("NULL") && !item.get("g:size").toString().isEmpty())
						{
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
							
							productOption.put("AttributeCode", "dimensions");
							productOption.put("AttributeId", "1");
							productOption.put("AttributeLabel", "Dimensions");
							productOption.put("optionID","1");
							productOption.put("optionText", item.get("g:size").toString().trim());
							productOption.put("ChildProductId", item.get("g:id").toString().trim());
							productOptions.add(productOption);
							mainConfigurableProduct.put("Product Attributes",productOptions);
						}
					}	
				   // mainConfigurableProduct.put(PRODUCT_NAME, productName.replaceAll(regex,"").trim());
					configurableProducts.put(configurableProductId, mainConfigurableProduct);
			   }  			   
			   else
			   {
				   Map<String,Object> existingConfigurableProduct = configurableProducts.get(item.get("g:item_group_id"));
				   ArrayList<LinkedHashMap<String,Object>>  existingProductOptions = (ArrayList<LinkedHashMap<String, Object>>) existingConfigurableProduct.get("Product Attributes");
				   double configurableProductPrice = Double.parseDouble(item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString());
				   if(Double.parseDouble(existingConfigurableProduct.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString())!=0 && Double.parseDouble(existingConfigurableProduct.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString()) > configurableProductPrice)
				   {
					   existingConfigurableProduct.put(PRODUCT_PRICE, configurableProductPrice);
				   }

				   if(item.get("g:size") != null)
					{
						if(!item.get("g:size").toString().equalsIgnoreCase("NULL") && !item.get("g:size").toString().isEmpty())
						{
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
							productOption.put("AttributeCode", "dimensions");
							productOption.put("AttributeId", "1");
							productOption.put("AttributeLabel", "Dimensions");
							productOption.put("optionID","1");
							productOption.put("optionText", item.get("g:size").toString().trim());
							productOption.put("ChildProductId", item.get("g:id").toString().trim());
							
							Boolean isSizeAlreadyExist = false;
							for(LinkedHashMap<String,Object> tempProductOption:existingProductOptions)
							{
								if(tempProductOption.get("optionText").toString().equalsIgnoreCase(item.get("g:size").toString().trim()))
								{
									isSizeAlreadyExist = true;
									break;
								}
							}
							
							if(!isSizeAlreadyExist)
							{
								existingProductOptions.add(productOption);
							}
							
						}
					}	
			   }
        	}
        }
        if(configurableProducts!=null && configurableProducts.size() > 0)
        {
        	List<String> productIdListWithOneOption = new ArrayList<String>();
        	for(Map.Entry<String, LinkedHashMap<String,Object>> entry: configurableProducts.entrySet())
            {
        		String configurableProductId = entry.getValue().get("g:id").toString();
        		ArrayList<LinkedHashMap<String,Object>>  productOptions = (ArrayList<LinkedHashMap<String,Object>>)entry.getValue().get("Product Attributes");
        		
        		if(productOptions.size() <= 1)
        		{
        			productIdListWithOneOption.add(configurableProductId);        			
        		}
            }
       
        	if(productIdListWithOneOption.size() > 0)
        	{
        		for(String configurableProductId:productIdListWithOneOption)
        		{
        			configurableProducts.remove(configurableProductId);        			
        		}
        	}
        	
        	for(Map<String,Object> item : productData)
	        {
        		if(item.get("g:item_group_id")!=null)
       		 	{
       			 	if(configurableProducts.get(item.get("g:item_group_id"))!=null)
       			 	{
       			 		if(configurableProducts.get(item.get("g:item_group_id")).get("Product Attributes")!=null)
       			 		{      			 		
           			 		item.put("Product Attributes", configurableProducts.get(item.get("g:item_group_id")).get("Product Attributes"));
           			 		item.put("type", "configurable");
       			 		}
       			 	}
       		 	}	
	        }
        	
        	for(Map.Entry<String, LinkedHashMap<String,Object>> entry: configurableProducts.entrySet())
            {        		
            	productData.add(entry.getValue());
            }
        }
        
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeRuthlandCycling(ArrayList<LinkedHashMap<String, Object>>  productData) 
    {  
		ArrayList<LinkedHashMap<String,Object>> uniqueProductlist = new ArrayList<LinkedHashMap<String,Object>>();
        Map<String,Map<String,Object>> finalData = new HashMap<String,Map<String,Object>>();        
        
		try{
		        
		        for(LinkedHashMap<String, Object> item : productData)
		        {    
		        	double temprrp = 0.00, price = 0.00; 
		        	double tempprice = 0.00, specialPrice = 0.00;
		        	int tempqty = 0, qty = 0;
		        	
		            ArrayList<LinkedHashMap<String,Object>> attributeList = new ArrayList<LinkedHashMap<String,Object>>();       
		            
		            if(item.get("availability").equals("in stock"))
					{
						item.put("availability", 1000);
						tempqty = 1000;
					}
					else
					{
						item.put("availability", 0);
						tempqty = 0;
					}  
		            
		            String link = item.get("link").toString().replace("http://", "https://");
		            item.put("link",link);
		            
		            String imageLink = item.get("image_link").toString().replace("http://", "https://");
		            item.put("image_link",imageLink);
		            
		            // for getting minimum special price        
		            if(!item.get("Price").equals(" "))
					{
		            	
		            	tempprice = Double.valueOf(item.get("Price").toString().trim().replace("GBP", ""));
		            	item.put("Price", tempprice);
						
					}
					
		            
		            if(!item.get("RRP").equals(" "))
		            	
					{
                        temprrp = Double.valueOf(item.get("RRP").toString().trim().replace("GBP", ""));
		            		
		            		item.put("RRP", temprrp);
		            	
					}
					 
		            
		            if(item.get("size")!= null && !item.get("size").toString().isEmpty() )
		            {
		                LinkedHashMap<String,Object> attributeDetails = new LinkedHashMap<String,Object>(); 
		                attributeDetails.put("attribute_uid", item.get("attribute_uid"));
		                attributeDetails.put("attributedetail_uid", item.get("attributedetail_uid"));
		                attributeDetails.put("attribute_code","Option");
		                attributeDetails.put("size", item.get("size"));
		                attributeDetails.put("availability", tempqty);
		                attributeDetails.put("RRP", Double.valueOf(item.get("RRP").toString().trim().replace("GBP", "")));
		                attributeDetails.put("Price", Double.valueOf(item.get("Price").toString().trim().replace("GBP", "")));
		                attributeList.add(attributeDetails);
		            }
		            
		          
		                    
		            if(!(finalData.containsKey(item.get("product_uid").toString())))
		            {
		                if(attributeList.size() > 0)
		                {		                   
		                    item.put("Product Options", attributeList);
		                    item.put("Product Type", "configurable");		                    
		                }
		                else
		                {
		                	item.put("Product Type", "simple");
		                }
		                
		                finalData.put(item.get("product_uid").toString(), item);
		            }
		            else 
		            {
		                if(attributeList.size() > 0)
		                {
		                  Map<String,Object> uniqueItem = finalData.get(item.get("product_uid").toString());
		                 
		                  ArrayList<LinkedHashMap<String,Object>> attributes = (ArrayList<LinkedHashMap<String,Object>>)uniqueItem.get("Product Options");
		                  
		                  price = Double.valueOf(uniqueItem.get("RRP").toString());
		                  		                  
		                  specialPrice = Double.valueOf(uniqueItem.get("Price").toString());
		                  
		                  qty = Integer.parseInt(uniqueItem.get("availability").toString());
		                  
		                  if(tempqty > qty)
		                  {		                	  
		                	 uniqueItem.put("availability", tempqty);
		                  }
		                  
		                  if( temprrp < price){
		                	  uniqueItem.put("RRP", temprrp);
		                  }
		                  
		                  if(tempprice < specialPrice){
		                	  uniqueItem.put("Price", tempprice);
		                  }
		                  
		                  if(attributes != null && attributes.size() > 0)
		                  {
		                     attributes.addAll(attributeList);
		                     uniqueItem.put("Product Options", attributes);   
		                  }
		                  else
		                  {
		                      uniqueItem.put("Product Options", attributeList);
		                  }
		                  
		                  uniqueItem.put("Product Type", "configurable");
		                                   
		                  finalData.put(item.get("product_uid").toString(), uniqueItem);   
		                }
		            }   
		            
		            
		        }   
		        
		        for(Entry<String, Map<String, Object>> datamap : finalData.entrySet())
		        {
		            LinkedHashMap<String,Object> uniquedatamap = (LinkedHashMap<String, Object>) datamap.getValue();
		            uniqueProductlist.add(uniquedatamap);
		        }
		        
		}catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeRuthlandCycling", "Error occured while customizing Ruthland Cycling Feed","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeRuthlandCycling()", "Error occured while customizing Ruthland Cycling feed", ex.getMessage());
		}
		
		 return uniqueProductlist; 
        
       
    }

	public ArrayList<LinkedHashMap<String, Object>> customize7FAMFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
		try
		{
			
			for(Map<String,Object> item : productData)
	        {	
				ArrayList<LinkedHashMap<String,Object>> tempProductOptions = new ArrayList<LinkedHashMap<String,Object>>();
				
				if(item.get(" Discounted Price") != null && !item.get(" Discounted Price").toString().isEmpty())
				{
					double discountedPrice = Double.valueOf(item.get(" Discounted Price").toString());
					
					if(discountedPrice > 0)
					{
						item.put(fieldMappingDetails.get(SPECIAL_PRICE), item.get(" Discounted Price"));
					}
				}
				
				if(item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)) != null && !item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().isEmpty())
	        	{
					String productStatus = item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().trim();
								
					if(productStatus.equals("Enabled"))
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 1);
					else
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 0);
					
	        	}
				
				if(item.get(fieldMappingDetails.get(PRODUCT_OPTIONS)) != null && !item.get(fieldMappingDetails.get(PRODUCT_OPTIONS)).toString().isEmpty())
	        	{	
					String[] productAttributeOptionsValue = item.get(fieldMappingDetails.get(PRODUCT_OPTIONS)).toString().trim().split("\\|");
					
					for(String productAttributeOption:productAttributeOptionsValue)
					{
						LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
						
						try
						{
							String[] attributeOptionDetails = productAttributeOption.split(",");
							
							if(attributeOptionDetails[0] != null && !attributeOptionDetails[0].trim().isEmpty())
							{
								productOption.put(CHILD_PRODUCT_ID, attributeOptionDetails[0]);
							}
							
							if(attributeOptionDetails[1] != null && !attributeOptionDetails[1].trim().isEmpty())
							{
								productOption.put(ATTRIBUTE_CODE, attributeOptionDetails[1]);
							}
							
							if(attributeOptionDetails[2] != null && !attributeOptionDetails[2].trim().isEmpty())
							{
								productOption.put(ATTRIBUTE_ID, attributeOptionDetails[2]);
							}
							
							if(attributeOptionDetails[3] != null && !attributeOptionDetails[3].trim().isEmpty())
							{
								productOption.put(ATTRIBUTE_LABEL, attributeOptionDetails[3]);
							}
							
							if(attributeOptionDetails[4] != null && !attributeOptionDetails[4].trim().isEmpty())
							{
								productOption.put(OPTION_ID, attributeOptionDetails[4]);
							}
							
							if(attributeOptionDetails[5] != null && !attributeOptionDetails[5].trim().isEmpty())
							{
								productOption.put(OPTION_TEXT, attributeOptionDetails[5]);
							}
							
							if(attributeOptionDetails[6] != null && !attributeOptionDetails[6].trim().isEmpty())
							{
								productOption.put(IS_PERCENT, attributeOptionDetails[6]);
							}
							
							if(attributeOptionDetails.length > 7 && attributeOptionDetails[7] != null)
							{
								if(!attributeOptionDetails[7].trim().isEmpty())
								{
									productOption.put(PRICING_VALUE, attributeOptionDetails[7]);
								}
							}
						}
						catch(Exception ex)
						{
							String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customize7FAMFeed", "Error occured while parsing attribute options","");
							logger.error(errorMessage,ex);
							ErrorLog.saveErrorLogToDB("Customizations.java customize7FAMFeed()", "Error occured while parsing attribute options", ex.getMessage());
						}
						
						tempProductOptions.add(productOption);			
					}
					
									
	        	}
				item.put(fieldMappingDetails.get(PRODUCT_OPTIONS), tempProductOptions);	
	        }
		
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customize7FAMFeed", "Error occured while customizing feed","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customize7FAMFeed()", "Error occured while customizing 7FAM feed", ex.getMessage());
		}
		
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeSMWSFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
		try
		{
			
			for(Map<String,Object> item : productData)
	        {
				
				DateTime specialPriceFromDate = null;
				DateTime specialPriceToDate = null;
								
				if(item.get("special_from_date") != null && !item.get("special_from_date").toString().trim().isEmpty())
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spStartDate = sdf.parse(item.get("special_from_date").toString());
					specialPriceFromDate = new DateTime(spStartDate);
				}
				
				if(item.get("special_to_date") != null && !item.get("special_to_date").toString().trim().isEmpty())
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spEndDate = sdf.parse(item.get("special_to_date").toString());
					specialPriceToDate = new DateTime(spEndDate);
					
				}
				
				if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
	        	{
				   DateTime todaysDate = new DateTime();
				   
				   if(specialPriceFromDate != null && todaysDate.isBefore(specialPriceFromDate))
				   {				      
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);				      
				   }
				   
				   if(specialPriceToDate != null && todaysDate.isAfter(specialPriceToDate))
				   {
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);
				   }
	        	 
	        	}				
				
				if(item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)) != null && !item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().isEmpty())
	        	{
					String productStatus = item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().trim();
								
					if(productStatus.equals("Enabled"))
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 1);
					else
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 0);
					
	        	}
				if(item.get("AssociatedProds")!=null)
				{
					ArrayList<LinkedHashMap<String,Object>> productOptions = new ArrayList<LinkedHashMap<String,Object>>();
					String tempAssociatedProductOptions = (String) item.get("AssociatedProds");	
					if(tempAssociatedProductOptions!=null && !tempAssociatedProductOptions.trim().isEmpty()){
						
						String[] associatedProductOptions = tempAssociatedProductOptions.split(Pattern.quote("|"));
						for(String productAttributes : associatedProductOptions)
						{
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();	
							String[] productAttibuteOptions = productAttributes.split(",");
							productOption.put("child_product_id", productAttibuteOptions[0]);
							productOption.put("attribute_code", "option");
							productOption.put("attribute_id", 1);
							productOption.put("attribute_label", "Option");
							productOption.put("option_id", 1);
							productOption.put("option_text", productAttibuteOptions[1]);
							productOptions.add(productOption);
							item.put("Product Attributes",productOptions);
						}	
					}
				}
							
				
				String productFullDescription = "";
				String distilledDate = "";
				String caskType = "";
				
				if(item.get("whisky_age")!=null && !item.get("whisky_age").toString().isEmpty()){
					productFullDescription += "AGE - "+item.get("whisky_age").toString() + " Years";
				}
				
				
				if(item.get("spirit_classification")!=null && !item.get("spirit_classification").toString().isEmpty() && !item.get("spirit_classification").toString().equalsIgnoreCase("NO")){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "CLASSIFICATION - "+item.get("spirit_classification").toString();
				}
				
				
				if(item.get("spirit_appellation")!=null && !item.get("spirit_appellation").toString().isEmpty() && !item.get("spirit_appellation").toString().equalsIgnoreCase("NO")){
					
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "APPELLATION - "+item.get("spirit_appellation").toString();
				}
				
				
				if(item.get("whisky_date_distilled_day")!=null && !item.get("whisky_date_distilled_day").toString().trim().isEmpty() && !item.get("whisky_date_distilled_day").toString().equalsIgnoreCase("NO")){
					distilledDate += item.get("whisky_date_distilled_day").toString();
				}				
				if(item.get("whisky_date_distilled_month")!=null && !item.get("whisky_date_distilled_month").toString().trim().isEmpty() && !item.get("whisky_date_distilled_month").toString().equalsIgnoreCase("NO")){
					distilledDate = distilledDate + " " + item.get("whisky_date_distilled_month").toString();
				}
				if(item.get("whisky_date_distilled_year")!=null && !item.get("whisky_date_distilled_year").toString().trim().isEmpty() && !item.get("whisky_date_distilled_year").toString().equalsIgnoreCase("NO")){
					distilledDate = distilledDate + " " + item.get("whisky_date_distilled_year").toString();
				}
				
				if(!distilledDate.isEmpty())
				{
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "DATE DISTILLED - " + distilledDate;	
				}
				
				
				if(item.get("whisky_cask_type_number_fills")!=null && !item.get("whisky_cask_type_number_fills").toString().trim().isEmpty() && !item.get("whisky_cask_type_number_fills").toString().equalsIgnoreCase("NO")){
					caskType += item.get("whisky_cask_type_number_fills").toString();
				}
				if(item.get("whisky_cask_type_prev_content")!=null && !item.get("whisky_cask_type_prev_content").toString().trim().isEmpty() && !item.get("whisky_cask_type_prev_content").toString().equalsIgnoreCase("NO")){
					caskType = caskType + " " +item.get("whisky_cask_type_prev_content").toString();
				}
				if(item.get("whisky_cask_type_size")!=null && !item.get("whisky_cask_type_size").toString().trim().isEmpty() && !item.get("whisky_cask_type_size").toString().equalsIgnoreCase("NO")){
					caskType = caskType + " " + item.get("whisky_cask_type_size").toString();
				}
				
				if(!caskType.isEmpty())
				{
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					
					productFullDescription += "CASK TYPE - " + caskType;
				}
				
				
				if(item.get("whisky_region")!=null && !item.get("whisky_region").toString().trim().isEmpty() && !item.get("whisky_region").toString().equalsIgnoreCase("NO")){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "REGION - " + item.get("whisky_region").toString();
				}
								
				
				if(item.get("spirit_grape")!=null && !item.get("spirit_grape").toString().isEmpty() && !item.get("spirit_grape").toString().equalsIgnoreCase("NO")){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "GRAPE VARIETY - "+item.get("spirit_grape").toString();
				}
				
				
				if(item.get("whisky_outturn")!=null && !item.get("whisky_outturn").toString().trim().isEmpty() && !item.get("whisky_outturn").toString().equalsIgnoreCase("NO")){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "OUTRURN - 1 of " + item.get("whisky_outturn").toString() + " bottles";
				}			

				
				if(item.get("whisky_abv")!=null && !item.get("whisky_abv").toString().isEmpty()){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "ABV - "+item.get("whisky_abv").toString() + "%";
				}
				
				if(item.get("whisky_colour_description")!=null && !item.get("whisky_colour_description").toString().isEmpty()){
					if(!productFullDescription.isEmpty())
					{
						productFullDescription = productFullDescription + "|";
					}
					productFullDescription += "COLOUR - "+item.get("whisky_colour_description").toString();
				}
				
				item.put(fieldMappingDetails.get(DESCRIPTION),productFullDescription);
				
				if(item.get(fieldMappingDetails.get(QUANTITY))!=null )
				{
					String qty = item.get(fieldMappingDetails.get(QUANTITY)).toString();
					item.put(fieldMappingDetails.get(QUANTITY),(int) Double.parseDouble(qty));
				}
				
				if(item.get("whisky_cask_code")!=null && !item.get("whisky_cask_code").toString().trim().isEmpty()){
					if(item.get(fieldMappingDetails.get(PRODUCT_NAME)) != null)
					{
						String productName = "CASK No. "+item.get("whisky_cask_code").toString()+"|"+item.get(fieldMappingDetails.get(PRODUCT_NAME)).toString(); 
						item.put(fieldMappingDetails.get(PRODUCT_NAME),productName);
					}						
				}
				
				if(item.get("AttributeSetName") != null && !item.get("AttributeSetName").toString().trim().isEmpty())
	        	{
					if(item.get("AttributeSetName").toString().trim().equalsIgnoreCase("Whisky (Default)"))
					{
						item.put(fieldMappingDetails.get(FIELD1),item.get("whisky_flavour").toString());
					}
					else{
						item.put(fieldMappingDetails.get(FIELD1),item.get("AttributeSetName").toString().replace(" (Spirit)", ""));
					}					
	        	}
				
	        }
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeSMWSFeed", "Error occured while setting color mapping","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeSMWSFeed()", "Error occured while customizing SMWS feed", ex.getMessage());
		}
		
		return productData;
	}
	
	/**
	 * @param:-ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails
	 * @return:- ArrayList<LinkedHashMap<String, Object>>
	 * @exception:-Error while setting Data
	 * @see:- customizeWORLDSIMFeed() is for client World SIM
	 */
	public ArrayList<LinkedHashMap<String, Object>> customizeWORLDSIMFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails,String categoryDelimiter) 
	{	
		try
		{
			
			for(Map<String,Object> item : productData)
	        {
				if(item.get(fieldMappingDetails.get(CATEGORIES)) != null)
	        	{
                    String categories = (String)item.get(fieldMappingDetails.get(CATEGORIES));
                        			
        			List<String> tempCategorylist = new ArrayList<String>();
        			String[] categoryTempArr;
        			String categoryData="";
        			
					if (!Strings.isNullOrEmpty(categoryDelimiter))
					{
						tempCategorylist = Arrays.asList(categories.split(Pattern.quote(categoryDelimiter)));
					}
					else
					{
						tempCategorylist.add(categories);
					}
					
					for(String category : tempCategorylist)
			        {
		        		categoryTempArr = category.split(Pattern.quote(","));
		        		categoryData=categoryData+categoryTempArr[1]+"|";			        	
			        }
					item.put(fieldMappingDetails.get(CATEGORIES), categoryData);
	        	}			
				
				DateTime specialPriceFromDate = null;
				DateTime specialPriceToDate = null;
												
				if(item.get("SpecialPriceFromDate") != null && !item.get("SpecialPriceFromDate").toString().trim().isEmpty())
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spStartDate = sdf.parse(item.get("SpecialPriceFromDate").toString());
					specialPriceFromDate = new DateTime(spStartDate);
				}
				
				if(item.get("SpecialPriceToDate") != null && !item.get("SpecialPriceToDate").toString().trim().isEmpty())
				{
					String pattern = "yyyy-MM-dd HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date spEndDate = sdf.parse(item.get("SpecialPriceToDate").toString());
					specialPriceToDate = new DateTime(spEndDate);
					
				}
				
				if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
	        	{
				   DateTime todaysDate = new DateTime();
				   
				   if(specialPriceFromDate != null && todaysDate.isBefore(specialPriceFromDate))
				   {				      
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);				      
				   }
				   
				   if(specialPriceToDate != null && todaysDate.isAfter(specialPriceToDate))
				   {
					   item.put(fieldMappingDetails.get(SPECIAL_PRICE), null);
				   }
	        	 
	        	}				
				
				if(item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)) != null && !item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().isEmpty())
	        	{
					String productStatus = item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().trim();
								
					if(productStatus.equals("Enabled"))
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 1);
					else
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 0);
					
	        	}
				
				if(item.get(fieldMappingDetails.get(QUANTITY))!=null )
				{
					String qty = item.get(fieldMappingDetails.get(QUANTITY)).toString();
					item.put(fieldMappingDetails.get(QUANTITY),(int) Double.parseDouble(qty));
				}
				
				if(item.get("CustomAttributes")!=null)
				{					
					ArrayList<LinkedHashMap<String,Object>> productOptions = new ArrayList<LinkedHashMap<String,Object>>();
					String tempAssociatedProductOptions = (String) item.get("CustomAttributes");
					
					/*if(tempAssociatedProductOptions.contains("Size") && tempAssociatedProductOptions.contains("Credit") && !tempAssociatedProductOptions.contains("Color"))
					{
						tempAssociatedProductOptions=tempAssociatedProductOptions.substring(tempAssociatedProductOptions.indexOf('|'), tempAssociatedProductOptions.length());
				    }*/

					if(tempAssociatedProductOptions!=null && !tempAssociatedProductOptions.trim().isEmpty())
					{
						String[] associatedProductOptions = tempAssociatedProductOptions.split(Pattern.quote("|"));
						
						for(String productAttributes : associatedProductOptions)
						{
							
							String[] productAttibuteOptions = productAttributes.split(",");
							int inc=2;	
							
							while(productAttibuteOptions.length>0 && inc<productAttibuteOptions.length)
							{
								LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();	
	
								productOption.put("attribute_id", productAttibuteOptions[0]);
								productOption.put("attribute_label", productAttibuteOptions[1]);
								productOption.put("option_id", productAttibuteOptions[inc++]);
								productOption.put("option_text", productAttibuteOptions[inc++]);
								productOption.put("pricing_value", productAttibuteOptions[inc++]);
								productOptions.add(productOption);
							
							}
						}	
					}
					item.put("Product Attributes",productOptions);
					
					if (item.get("CustomAttributes") != null && !item.get("CustomAttributes").toString().isEmpty())
					{
						item.put("ProductType", "configurable");
					}	
				}
				
				if(item.get("ProductType").toString().equals("Simple"))
				{
					item.put("ProductType", "simple");
				}
							
	        }
		}	
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeWorldSIMFeed", "Error occured while customizing feed","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeWorldSIMFeed()", "Error occured while customizing WorldSIM feed", ex.getMessage());
		}
		
		return productData;
	}
	
	public ArrayList<LinkedHashMap<String, Object>> customizeLeekes(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
        for(Map<String,Object> item : productData)
        {	
        	if(item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)) != null && !item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().isEmpty())
        	{
				String productStatus = item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().trim();
							
				if(productStatus.equals("enabled"))
					item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 1);
				else
					item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 0);
				
        	}
        	
        	if(item.get("msrp") != null && !item.get("msrp").toString().isEmpty())
        	{
        		if(item.get(fieldMappingDetails.get(PRODUCT_PRICE)) != null && !item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString().isEmpty())
            	{
        			if((Double.parseDouble(item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString()) < Double.parseDouble(item.get("msrp").toString())) && Double.parseDouble(item.get("msrp").toString())!=0)
        			{
        				item.put(fieldMappingDetails.get(PRODUCT_PRICE),item.get("msrp").toString().trim());
        			}
               	}
        		
        		if(item.get(fieldMappingDetails.get(SPECIAL_PRICE)) != null && !item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().isEmpty())
            	{
        			if((Double.parseDouble(item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString()) < Double.parseDouble(item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString())) && Double.parseDouble(item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString())!=0)
        			{
        				item.put(fieldMappingDetails.get(SPECIAL_PRICE),item.get(fieldMappingDetails.get(SPECIAL_PRICE)).toString().trim());
        			}
        			else
            		{
            			item.put(fieldMappingDetails.get(SPECIAL_PRICE),item.get(fieldMappingDetails.get(PRODUCT_PRICE)).toString().trim());
            		}
            	}        		
        	}   
        	
        	if(item.get(fieldMappingDetails.get(IMAGE_URL)) != null && !item.get(fieldMappingDetails.get(IMAGE_URL)).toString().isEmpty())
        	{
        		String imageUrl=item.get(fieldMappingDetails.get(IMAGE_URL)).toString().trim();
                String [] temp=imageUrl.split("/");
                String productSku=temp[temp.length-1];    
                
                productSku=productSku.replaceAll("[a-zA-Z_.]","");
                
                item.put(fieldMappingDetails.get(PRODUCT_SKU),productSku);
        	}
        }
        
		return productData;
	}
	
	/**
	 * @param:-ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails,categoryDelimiter
	 * @return:- ArrayList<LinkedHashMap<String, Object>>
	 * @exception:-Error while setting Data
	 * @see:- customizeINOV8Feed() is for client Inov-8
	 */
	public ArrayList<LinkedHashMap<String, Object>> customizeINOV8Feed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{	
		try
		{
			for(Map<String,Object> item : productData)
	        {	
				
				if(item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)) != null && !item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().isEmpty())
	        	{
					String productStatus = item.get(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS)).toString().trim();
								
					if(productStatus.equals("Enabled"))
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 1);
					else
						item.put(fieldMappingDetails.get(CLIENT_PRODUCT_STATUS), 0);
					
	        	}				
				
				if(item.get("AttributeOptionDetails")!=null){
					
					ArrayList<LinkedHashMap<String,Object>> productOptions = new ArrayList<LinkedHashMap<String,Object>>();
					
					String tempAssociatedProductOptions = (String) item.get("AttributeOptionDetails");	
					
					if(tempAssociatedProductOptions!=null && !tempAssociatedProductOptions.trim().isEmpty()){
						
						String[] associatedProductOptions = tempAssociatedProductOptions.split(Pattern.quote("|"));
						
						for(String productAttributes : associatedProductOptions)
						{
								
							String[] productAttibuteOptions = productAttributes.split(",");
							LinkedHashMap<String,Object> productOption = new LinkedHashMap<String,Object>();
							
							if(productAttibuteOptions[4]!=null && !productAttibuteOptions[4].equals("") && !productAttibuteOptions[4].trim().isEmpty()
								&&	productAttibuteOptions[5]!=null && !productAttibuteOptions[5].equals("") && !productAttibuteOptions[5].trim().isEmpty()	){
							
							if(productAttibuteOptions[0] != null && !productAttibuteOptions[0].trim().isEmpty())
							{
							productOption.put("child_product_id", productAttibuteOptions[0]);
							}
							if(productAttibuteOptions[1] != null && !productAttibuteOptions[1].trim().isEmpty())
							{
							productOption.put("attribute_code",  productAttibuteOptions[1]);
							}
							if(productAttibuteOptions[2] != null && !productAttibuteOptions[2].trim().isEmpty())
							{
							productOption.put("attribute_id", productAttibuteOptions[2]);
							}
							if(productAttibuteOptions[3] != null && !productAttibuteOptions[3].trim().isEmpty())
							{
							productOption.put("attribute_label", productAttibuteOptions[3]);
							}
							if(productAttibuteOptions[4] != null && !productAttibuteOptions[4].trim().isEmpty())
							{
							productOption.put("option_id", productAttibuteOptions[4]);							
							}
							if(productAttibuteOptions[5] != null && !productAttibuteOptions[5].trim().isEmpty())
							{
							productOption.put("option_text", productAttibuteOptions[5]);
							}											
							if(productAttibuteOptions[6].equalsIgnoreCase("Fixed") && productAttibuteOptions[6] != null && !productAttibuteOptions[6].trim().isEmpty())
							{
							productOption.put("is_percent", String.valueOf(0));
							}
							if(productAttibuteOptions[6].equalsIgnoreCase("Percentage") && productAttibuteOptions[6] != null && !productAttibuteOptions[6].trim().isEmpty())
							{
							productOption.put("is_percent", String.valueOf(1));
							}
							if(productAttibuteOptions[7] != null && !productAttibuteOptions[7].trim().isEmpty())
							{
							productOption.put("pricing_value", productAttibuteOptions[7]);
							}
														
							productOptions.add(productOption);														
						}
							
					   }	
						item.put("AttributeOptionDetails",productOptions);
					}
					
				}					
	        }
		}	
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeINOV8Feed", "Error occured while customizing Inov-8 feed","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeINOV8Feed()", "Error occured while customizing Inov-8 feed", ex.getMessage());
		}
		
		return productData;
	}
	
	
	public ArrayList<LinkedHashMap<String, Object>> customizeKingwinFeed(ArrayList<LinkedHashMap<String, Object>> productData,LinkedHashMap<String, String> fieldMappingDetails) 
	{
		ArrayList<LinkedHashMap<String, Object>> finalProductsList = new ArrayList<LinkedHashMap<String,Object>>();

		try
		{
			
			if(productData != null && productData.size() > 0)
			{ 
				for(Map<String,Object> item : productData)
		        {
					String feedUrl = "https://api.kinguin.net/v1/catalog/categories-full/"+item.get("g:id").toString();

				    InputStream jsonDataStream = FileUtil.fetchContent(feedUrl);
				    
				    if(jsonDataStream!=null)
				    {
						 //create JsonReader object
				        JsonReader jsonReader = Json.createReader(jsonDataStream);			         
				      			         
				        //get JsonObject from JsonReader
				        JsonObject jsonObejct = jsonReader.readObject();
				        
			            JsonObject jsonCategory = jsonObejct.getJsonObject("category");
			            JsonArray jsonProducts = jsonObejct.getJsonArray("products");

			            if(jsonProducts!=null && jsonProducts.size() > 0 )
			            {
			            	for (int j = 0; j < jsonProducts.size(); j++) 
					        {
			            		LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>(); 
				            	JsonObject prodObject = jsonProducts.getJsonObject(j);

				            	if(prodObject.get("entity_id") != null)
				            	{
					            	data.put(fieldMappingDetails.get(PRODUCT_ID), prodObject.get("entity_id").toString());
				            	}
				            	if(prodObject.get("sku") != null)
								{
					            	String sku = prodObject.get("sku").toString();
					            	sku = sku.substring(1, sku.length()-1); 
					            	data.put(fieldMappingDetails.get(PRODUCT_SKU), sku);
								}
				            	if(prodObject.get("price") != null)
				            	{
						            data.put(fieldMappingDetails.get(PRODUCT_PRICE), prodObject.get("price").toString());
				            	}
					            if(prodObject.get("is_in_stock") != null && prodObject.get("is_in_stock").toString().equalsIgnoreCase("true"))
					            {
						            data.put(fieldMappingDetails.get(QUANTITY), 1000);
					            }
					            else
					            {
					            	data.put(fieldMappingDetails.get(QUANTITY), 0);
					            }
					            
					            if(jsonCategory.get("description") != null)
				            	{
					            	String description = jsonCategory.get("description").toString();
					            	description = description.substring(1, description.length()-1); 
						            data.put(fieldMappingDetails.get(DESCRIPTION), description);
				            	}
					            
					            if(jsonCategory.get("name") != null)
								{
					            	String productName = jsonCategory.get("name").toString();
					            	productName = productName.substring(1, productName.length()-1); 
					            	data.put(fieldMappingDetails.get(PRODUCT_NAME), productName);
								}
								
								if(item.get("link") != null)
								{
									data.put(fieldMappingDetails.get(PRODUCT_URL), item.get("link").toString());
								}
								if(item.get("g:image_link") != null)
								{
									data.put(fieldMappingDetails.get(IMAGE_URL), item.get("g:image_link").toString());
								}
								if(item.get("g:additional_image_link") != null)
								{
									data.put(fieldMappingDetails.get(OTHER_IMAGE_LIST), item.get("g:additional_image_link").toString());
								}
								if(item.get("g:product_type") != null)
								{
									data.put(fieldMappingDetails.get(CATEGORIES), item.get("g:product_type").toString());
								}
							
								data.put("Visibility", "Visible");
								data.put("Product Status", 1);
								
								finalProductsList.add(data);
					        }
			            }
			            
				    	jsonReader.close();
				    	jsonDataStream.close();	
						
				    }
		        }
			}
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Customizations" , "customizeKingwinFeed", "Error occured while customizing Kingwin feed","");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("Customizations.java customizeKingwinFeed()", "Error occured while customizing Kingwin feed", ex.getMessage());
		}
		
	return finalProductsList;
	
	}
}