package com.increasingly.importbulkdata.impl.db;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.jdbc.object.StoredProcedure;

import com.increasingly.db.BaseDB;
import com.increasingly.importbulkdata.interfaces.ServiceInterface;

public class GetAutoProductFeedUpdateList extends StoredProcedure implements ServiceInterface<ArrayList<Map<String, Object>>>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Get_Auto_Product_Feed_Update_List";	
	private static GetAutoProductFeedUpdateList instance = null;
	
	private GetAutoProductFeedUpdateList()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);	
		compile();		
	}

	public static GetAutoProductFeedUpdateList getInstance()
	{
		if (instance == null)
		{
			instance = new GetAutoProductFeedUpdateList();
		}
		return instance;
	}

	public ArrayList<Map<String, Object>> runService(Map<String, Object> input)
	{
		ArrayList<Map<String, Object>> results = (ArrayList<Map<String, Object>>) execute().get("#result-set-1");
		return results;
	}
}