package com.increasingly.importbulkdata.util;


import static com.increasingly.importbulkdata.util.Constants.LOG_APPLICATION_FLOW;
import static com.increasingly.importbulkdata.util.Constants.LOG_ERROR;
import static com.increasingly.importbulkdata.util.Constants.LOG_INFO;
import static com.increasingly.importbulkdata.util.Constants.PROTOCOL_HTTP;
import static com.increasingly.importbulkdata.util.Constants.PROTOCOL_HTTPS;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.increasingly.importbulkdata.impl.db.ErrorLog;
import com.jcraft.jsch.Session;

/**
 * @author Shreehari.Padaki
 *
 */
public class FileUtil
{
	/**
	 * Appends contents to a file. Will create the file if it doesn't exist.
	 * 
	 * @param path
	 * @param filename
	 * @param content
	 * @throws Exception
	 */
	private static final Logger logger = LoggerFactory.getLogger(FileUtil.class.getClass());
	public static String fileFormat = "";
	public static InputStream importDataStream;
	public static HttpURLConnection connection;
    static Session session = null;
    public static GZIPInputStream gZipInputStream;
    public static ZipInputStream zipInputStream;
    public static String tmpFeedDwnldPath = System.getProperty("user.home")+"/DownloadedFeeds";
    public static String temporaryFeedSavePath = "";

	public static void appendFile(String path, String fileName, String content) throws Exception
	{
		try
		{
			// Create folders
			File files = new File(path);
			if (!files.exists())
			{
				files.mkdirs();
			}
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path + fileName, true)));
			out.println(content);
			out.close();
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Copies an uploaded file to a destination specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static Boolean uploadFile(InputStream uploadedInputStream, String uploadedFileLocation) throws Exception
	{
		OutputStream out = null;
		try
		{
			out = new FileOutputStream(new File(uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];
			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1)
			{
				out.write(bytes, 0, read);
			}

			return true;
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
		finally
		{
			if (out != null)
			{
				out.flush();
				out.close();
			}
		}
	}

	/**
	 * Decompress an uploaded Gzip file & copies to a destination specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static Boolean uploadGZipedFileAndDecompress(GZIPInputStream uploadedGZIPInputStream, String uploadedFileLocation) throws Exception
	{
		OutputStream out = null;
		try
		{
			out = new FileOutputStream(new File(uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];
			while ((read = uploadedGZIPInputStream.read(bytes)) != -1)
			{
				out.write(bytes, 0, read);
			}

			return true;
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
		finally
		{
			if (out != null)
			{
				out.flush();
				out.close();
				uploadedGZIPInputStream.close();
			}
		}
	}

	/**
	 * Decompress an uploaded Zip file & copies to a destination specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static Boolean uploadZipedFileAndDecompress(ZipInputStream uploadedZipInputStream, String uploadFileLocation) throws Exception
	{
		OutputStream out = null;
		try
		{
			// now write zip file in extracted file
			byte[] buff = new byte[1024];
			while ((uploadedZipInputStream.getNextEntry()) != null)
			{
				out = new FileOutputStream(uploadFileLocation);
				int l = 0;
				while ((l = uploadedZipInputStream.read(buff)) > 0)
				{
					out.write(buff, 0, l);
				}
			}

			return true;
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
		finally
		{
			if (out != null)
			{
				out.flush();
				out.close();
				uploadedZipInputStream.close();
			}
		}
	}

	/**
	 * Decompress a Zip file & copies to a destination specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static Boolean uploadZipedFileAndDecompress(ZipInputStream uploadedZipInputStream, ZipEntry uploadedZipInput, String uploadFileLocation) throws Exception
	{
		OutputStream out = null;
		try
		{
			// now write extracted file
			byte[] buff = new byte[1024];
			if (uploadedZipInput != null)
			{
				out = new FileOutputStream(uploadFileLocation);
				int l = 0;
				while ((l = uploadedZipInputStream.read(buff)) > 0)
				{
					out.write(buff, 0, l);
				}
			}

			return true;
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
		finally
		{
			if (out != null)
			{
				out.flush();
				out.close();
				uploadedZipInputStream.close();
			}
		}
	}

	/**
	 * Deletes an file from specified specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static void deleteFile(String fileLocation) throws Exception
	{
		try
		{
			File f = new File(fileLocation);

			if (f.exists())
			{
				f.delete();
			}
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Parses the XML content to DOM, which will make the content easier to iterate.
	 * 
	 * @param xmlPath - URL / Absolute path of the XML file
	 *
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static Document xmlToDoc(String xmlPath) throws ParserConfigurationException, SAXException, IOException
	{
		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			builder = factory.newDocumentBuilder();
			return builder.parse(xmlPath);
		}
		catch (Exception e)
		{
			return null;
		}
	}

	/**
	 * Returns the content/value of tag given from Element. If tag not found, returns attribute's value.
	 * 
	 * @param tagName
	 * @param element
	 * @return
	 */
	public static String getString(String name, Element element)
	{
		NodeList list = element.getElementsByTagName(name);
		if (list != null && list.getLength() > 0)
		{
			NodeList subList = list.item(0).getChildNodes();
			if (subList != null && subList.getLength() > 0)
			{
				return subList.item(0).getNodeValue();
			}
		}
		else if (element.hasAttribute(name))
		{
			return element.getAttribute(name);
		}
		else if (!element.hasAttribute(name))
		{
			NodeList nl = element.getElementsByTagName("*");
			for (int i = 0; i < nl.getLength(); i++)
			{
				Element innerElement = (Element) nl.item(i);
				if (innerElement.hasAttribute(name))
				{
					return innerElement.getAttribute(name);
				}
			}
		}
		return null;
	}

	public static InputStream fetchContent(String feedUrl) 
	{
		logger.info(LOG_APPLICATION_FLOW + "Downloading product data from : " + feedUrl + "...");
		InputStream inputStream = null;
		try
		{
			String protocol;
			URL url = null;
			url = new URL(URLDecoder.decode(feedUrl));
			protocol = new URL(URLDecoder.decode(feedUrl)).getProtocol();
			
			if (protocol.equalsIgnoreCase(PROTOCOL_HTTP) || protocol.equalsIgnoreCase(PROTOCOL_HTTPS))
			{
				connection = (HttpURLConnection) url.openConnection();
				connection.setConnectTimeout(90000);
				connection.setRequestProperty("User-Agent", "Mozilla/5.0");
				
				String basicAuth = "Basic " + new String("aW5jcmVhc2luZ2x5Z3NyQGNpdHJ1c2xpbWUuY29tOmR1b3NkaGZpdXNkZmdoc2RmdTEyM2Y1NDM=");
			    connection.setRequestProperty("Authorization", basicAuth);
				
				inputStream = connection.getInputStream();
			}			
			else
			{			
				logger.info(LOG_INFO + "Invalid protocol.");
			}

			logger.info(LOG_APPLICATION_FLOW + "Downloading of product data completed.");
			return inputStream;
		}
		catch (Exception e)
		{		
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "FileUtil" , "fetchContent", "Error occured while downloading content from url" + feedUrl,"");
			logger.error(errorMessage,e);
			ErrorLog.saveErrorLogToDB("FileUtil.java fetchContent()","Error occured while downloading content from url" + feedUrl,  e.getMessage());
			return null;
		}
	}
}