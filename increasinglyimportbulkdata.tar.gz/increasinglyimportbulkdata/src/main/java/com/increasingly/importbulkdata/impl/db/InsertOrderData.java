package com.increasingly.importbulkdata.impl.db;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasingly.db.BaseDB;
import com.increasingly.importbulkdata.interfaces.ServiceInterface;



public class InsertOrderData extends StoredProcedure implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final String SPROC_NAME = "Insert_Order_Details";

	private static InsertOrderData instance = null;
	private static final Logger logger = LoggerFactory.getLogger(InsertOrderData.class.getName());

	private InsertOrderData()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ClientId", Types.INTEGER));
		declareParameter(new SqlParameter("PlatformId", Types.INTEGER));
		declareParameter(new SqlOutParameter("result", Types.INTEGER));
		compile();		
	}

	public static InsertOrderData getInstance()
	{
		if (instance == null)
		{
			instance = new InsertOrderData();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		Integer platformId = (Integer) input.get(PLATFORM_ID);
		Map<String, Object> results = execute(clientId,platformId);	
		
		if (results.get("result") == null)
		{
			return 0;
		}
		else
		{
			Integer res = (Integer) results.get("result");
			return res;			
		}	
	}
}