package com.increasingly.importbulkdata.impl;

import static com.increasingly.importbulkdata.util.Constants.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.increasingly.importbulkdata.impl.db.BatchInsertOrderData;
import com.increasingly.importbulkdata.impl.db.BatchInsertOrderItemsData;
import com.increasingly.importbulkdata.impl.db.DeleteTemporaryStorageData;
import com.increasingly.importbulkdata.impl.db.GetOrderDataFieldMappingDetails;
import com.increasingly.importbulkdata.impl.db.InsertOrderData;
import com.increasingly.importbulkdata.util.FileUtil;
import com.increasingly.importbulkdata.util.FormatLoggerMessage;
import com.increasingly.importbulkdata.util.GetProperties;
import com.increasingly.importbulkdata.util.ParseCSVFile;
import com.increasingly.importbulkdata.util.ParseXMLFile;
import com.increasingly.importbulkdata.util.UrlUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ImportOrderDataImpl
{
	private static final Logger logger = LoggerFactory.getLogger(ImportOrderDataImpl.class.getClass());
	private static Properties increasinglyProperties = null;
	private String fileUrl = "";
	private Integer clientId = 0;
	public HttpURLConnection connection;
	public InputStream importDataStream;
	public GZIPInputStream gZipInputStream;
	public ZipInputStream zipInputStream;
	
	private static String tmpFeedDwnldPath = System.getProperty("user.home")+"/DownloadedFeeds";
	private String temporaryFileSavePath = "";
	private String fileFormat = "";
	private String delimiter = ",";
	private String characterSetEncoder = "UTF-8";
		
	ArrayList<OrderDetails> orderDetailsList;
	ArrayList<OrderItemDetails> orderItemDetailsList;
	private Integer totalRecordsCount = 1000;
	private Integer limit = 20;
	ObjectMapper mapper = new ObjectMapper();
	Boolean isMagentoOrderExport = false;


	public void runService() 
	{			
		try
		{			
			Boolean isApi = false;
			GetProperties getProperties = new GetProperties();
			increasinglyProperties = getProperties.readProperties("webapp/WEB-INF/increasingly.properties");	
			
			String baseFileUrl = increasinglyProperties.getProperty("baseFileurl");
			clientId = Integer.parseInt(increasinglyProperties.getProperty("clientId"));
			limit  = Integer.parseInt(increasinglyProperties.getProperty("limit","1000"));
			isMagentoOrderExport = Boolean.parseBoolean(increasinglyProperties.getProperty("isMagentoOrderExport","false"));
			isApi  = Boolean.parseBoolean(increasinglyProperties.getProperty("isApi","false"));	
			
			
			if (!(Strings.isNullOrEmpty(baseFileUrl)) && UrlUtil.isValidUrl(baseFileUrl))
			{
				if(isApi)
				{
					for (int offset = 1; offset <= totalRecordsCount; offset++)
					{							
						fileUrl = baseFileUrl + "&offset=" + offset + "&limit=" + limit;						 
					    downloadAndReadFile();			    
					    offset = offset + limit - 1;					    
					   
					}
				}
				else
				{
					fileUrl = baseFileUrl;
					downloadAndReadFile();		
				}
			}
			else
			{
				logger.info(LOG_INFO + "Invalid client Import URL (" + fileUrl + ") for clientId : " + clientId);			
			}
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportOrderDataImpl" , "runService", "Error occured " ,"");
			logger.error(errorMessage,ex);
		}		
	}
	
	private void downloadAndReadFile()
	{		
		if(downloadFile())
		{
		  readOrderContent(temporaryFileSavePath);		 
		  processOrderData();
		}
				
	}
	
	private Boolean downloadFile()
	{
		Boolean isFileUploadSuccessful = false;
		try
		{
			String[] tmpArr = fileUrl.trim().split("\\.");
			String fileExt = tmpArr[tmpArr.length - 1];			
			Integer fileCompressionType = FILE_COMPRESSION_TYPE_NONE;
			
			URL url = new URL(fileUrl);

			if (!fileExt.toLowerCase().contains(FILE_EXTENSION_EXE))
			{
				importDataStream = fetchContent();
				
				if (importDataStream != null)
				{
					String contentType = "";
					if (url.getProtocol().equalsIgnoreCase(PROTOCOL_HTTP) || url.getProtocol().equalsIgnoreCase(PROTOCOL_HTTPS))
					{
						contentType = connection.getContentType();
						
						if(contentType.contains("application/json"))
						{
							fileExt = "txt";
							fileFormat = "json";
						}
						else if(contentType.contains("text/plain"))
						{
							fileExt = "txt";
							fileFormat = "txt";
						}
						else if(contentType.contains("application/csv"))
						{
							fileExt = "csv";
							fileFormat = "csv";
						}
						else if(contentType.contains("application/xml"))
						{
							fileExt = "xml";
							fileFormat = "xml";
						}
					}					
				
					temporaryFileSavePath = tmpFeedDwnldPath + "_" + clientId.toString() + "." + fileExt;

					if ((!Strings.isNullOrEmpty(contentType) && (contentType.contains(FILE_EXTENSION_GZ) || contentType.contains(FILE_EXTENSION_DEFLATE)))
							|| fileExt.toLowerCase().contains(FILE_EXTENSION_GZ) || fileExt.toLowerCase().contains(FILE_EXTENSION_DEFLATE))
					{
						fileCompressionType = FILE_COMPRESSION_TYPE_GZIP;
						gZipInputStream = new GZIPInputStream(importDataStream);
					}
					else if ((!Strings.isNullOrEmpty(contentType) && contentType.contains(FILE_EXTENSION_ZIP)) || fileExt.toLowerCase().contains(FILE_EXTENSION_ZIP))
					{
						fileCompressionType = FILE_COMPRESSION_TYPE_ZIP;
						zipInputStream = new ZipInputStream(importDataStream);
					}

					/** Delete file if it already exist */
					FileUtil.deleteFile(temporaryFileSavePath);

					if (fileCompressionType.equals(FILE_COMPRESSION_TYPE_NONE))
					{
						isFileUploadSuccessful = FileUtil.uploadFile(importDataStream, temporaryFileSavePath);
					}
					else if (fileCompressionType.equals(FILE_COMPRESSION_TYPE_GZIP))
					{
						// .gz files will have the original filename (Eg: test.xml.gz)
						fileFormat = tmpArr[tmpArr.length - 2];
						isFileUploadSuccessful = FileUtil.uploadGZipedFileAndDecompress(gZipInputStream, temporaryFileSavePath);
					}
					else if (fileCompressionType.equals(FILE_COMPRESSION_TYPE_ZIP))
					{
						// zipInputStream.getNextEntry().getName() will give the original file name
						ZipEntry ze = zipInputStream.getNextEntry();
						String[] tArr = ze.getName().split("\\.");
						fileFormat = tArr[tArr.length - 1];
						isFileUploadSuccessful = FileUtil.uploadZipedFileAndDecompress(zipInputStream, ze, temporaryFileSavePath);
					}
					
					logger.info("File " + fileUrl + " downloaded successfully...");
				}
			}
			else
			{				
				logger.info("File is not in proper format...");
			}
		}
		catch (Exception e)
		{			
			logger.error(e.getMessage(), e);
		}

		return isFileUploadSuccessful;
	}

	private InputStream fetchContent() 
	{
		logger.info(LOG_APPLICATION_FLOW + "Downloading order data from : " + fileUrl + "...");
		InputStream inputStream = null;
		try
		{
			URL url = new URL(URLDecoder.decode(fileUrl));

			if (url.getProtocol().equalsIgnoreCase(PROTOCOL_FTP))
			{
				URLConnection uc = (URLConnection) url.openConnection();
				uc.setConnectTimeout(10000); // CONNECTION_TIMEOUT
				inputStream = uc.getInputStream();				
			}
			else if (url.getProtocol().equalsIgnoreCase(PROTOCOL_HTTP) || url.getProtocol().equalsIgnoreCase(PROTOCOL_HTTPS))
			{
				connection = (HttpURLConnection) url.openConnection();
				connection.setConnectTimeout(90000);
				inputStream = connection.getInputStream();
			}
			else
			{			
				logger.info(LOG_INFO + "Invalid protocol. Only ftp, http or https allowed.");
			}

			logger.info(LOG_APPLICATION_FLOW + "Downloading of order data completed.");
			return inputStream;
		}
		catch (Exception e)
		{		
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportOrderDataImpl" , "fetchContent", "Error occured while downloading content from url" + fileUrl,"");
			logger.error(errorMessage,e);
			return null;
		}
	}
		
	/** This method is used to read complete order data */
	public void readOrderContent(String localFilePath) 
	{	
		orderDetailsList = new ArrayList<OrderDetails>();
		orderItemDetailsList = new ArrayList<OrderItemDetails>();
		List<LinkedHashMap<String,Object>> orderData = new ArrayList<LinkedHashMap<String,Object>>();
		List<LinkedHashMap<String,Object>> orderItemData = new ArrayList<LinkedHashMap<String,Object>>();
		
		try
		{	
			logger.info(LOG_APPLICATION_FLOW + "Started reading order content from downloaded file.");
			
			if (fileFormat.equals(CONTENT_TYPE_CSV) || fileFormat.equals(CONTENT_TYPE_TXT))
			{
				ParseCSVFile parseCsvFile = new ParseCSVFile();
				orderData = parseCsvFile.getCSVParsedData(delimiter, localFilePath, characterSetEncoder);
			}
			else if (fileFormat.equals(CONTENT_TYPE_XML))
			{
				ParseXMLFile parseXmlFile = new ParseXMLFile();
				//Map<String,Object> parsedOrderAndItemData = parseXmlFile.getXMLParsedData(localFilePath);
				//orderData = (ArrayList<LinkedHashMap<String, Object>>)parsedOrderAndItemData.get("orderData");
				
			}
			else if(fileFormat.equals(CONTENT_TYPE_JSON))
			{
			    File jsonInputFile = new File(localFilePath);
			    InputStream jsonDataStream = new FileInputStream(jsonInputFile);
		
				 //create JsonReader object
		        JsonReader jsonReader = Json.createReader(jsonDataStream);			         
		      			         
		        //get JsonObject from JsonReader
		        JsonObject jsonObject = jsonReader.readObject();
		        
		        if(jsonObject.get(TOTAL_ORDER_COUNT) != null)
		        {
		        	totalRecordsCount = jsonObject.getInt(TOTAL_ORDER_COUNT);
		        }
		       
		        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		        orderData = mapper.readValue(String.valueOf(jsonObject.get("orders")),new TypeReference<ArrayList<Map<String,Object>>>(){});
				
		    	jsonReader.close();
		    	jsonDataStream.close();
		        importDataStream.close();
			        
			}
			
			Map<String,Object> input = new HashMap<String,Object>();
			input.put(CLIENT_ID,clientId);
			ArrayList<Map<String,String>> fieldMappingDetailsFromDb = getFieldMappingDetails(input);
			
			LinkedHashMap<String, String> fieldMappingDetails = new LinkedHashMap<String, String>();

			for (Map<String, String> s : fieldMappingDetailsFromDb)
			{
				fieldMappingDetails.put(s.get("field_name"), s.get("client_field_name"));
			}
			    	
	        for(Map<String,Object> order : orderData)
	        {	
	        	String clientOrderId = (String)order.get(fieldMappingDetails.get(CLIENT_ORDER_ID));
	        	
	        	OrderDetails orderDetails = new OrderDetails();
	        	orderDetails.setClientId(clientId);
	        	orderDetails.setClientOrderId(clientOrderId);
	        	
	        	if(order.get(fieldMappingDetails.get(ORDER_STATUS)) != null)
	        	{
	        		orderDetails.setOrderStatus((String)order.get(fieldMappingDetails.get(ORDER_STATUS)));
	        	}	        	
	        	if(order.get(fieldMappingDetails.get(ORDER_AMOUNT)) != null)
	        	{
	        		orderDetails.setOrderAmount(String.valueOf(order.get(fieldMappingDetails.get(ORDER_AMOUNT))));
	        	}
	        	if(order.get(fieldMappingDetails.get(ORDER_TIME)) != null)
	        	{
	        		String pattern = "yyyy-MM-dd'T'HH:mm:ss";
					SimpleDateFormat sdf = new SimpleDateFormat(pattern);
					Date orderDateTime = sdf.parse((String)order.get(fieldMappingDetails.get(ORDER_TIME)));
					DateTime dt = new DateTime(orderDateTime);
					 
	        		orderDetails.setOrderTime(dt.toString("yyyy-MM-dd HH:mm:ss"));
	        	}
	        	if(order.get(fieldMappingDetails.get(COUPON_CODE)) != null)
	        	{
	        		orderDetails.setCouponCode((String)order.get(fieldMappingDetails.get(COUPON_CODE)));
	        	}
	        	if(order.get(fieldMappingDetails.get(DISCOUNT_AMOUNT)) != null)
	        	{
	        		orderDetails.setDiscountAmount((String)order.get(fieldMappingDetails.get(DISCOUNT_AMOUNT)));
	        	}
	        	if(order.get(fieldMappingDetails.get(TAX_AMOUNT)) != null)
	        	{
	        		orderDetails.setTaxAmount(String.valueOf(order.get(fieldMappingDetails.get(TAX_AMOUNT))));
	        	}
	        	if(order.get(fieldMappingDetails.get(SHIPPING_AMOUNT)) != null)
	        	{
	        		orderDetails.setShippingAmount(String.valueOf(order.get(fieldMappingDetails.get(SHIPPING_AMOUNT))));
	        	}
	        	if(order.get(fieldMappingDetails.get(SHIPPING_METHOD)) != null)
	        	{
	        		orderDetails.setShippingMethod(String.valueOf(order.get(fieldMappingDetails.get(SHIPPING_METHOD))));
	        	}
	        	if(order.get(fieldMappingDetails.get(CURRENCY_CODE)) != null)
	        	{
	        		orderDetails.setCurrencyCode((String)order.get(fieldMappingDetails.get(CURRENCY_CODE)));
	        	}
	        	if(order.get(fieldMappingDetails.get(PAYMENT_METHOD)) != null)
	        	{
	        		orderDetails.setPaymentMethod((String)order.get(fieldMappingDetails.get(PAYMENT_METHOD)));
	        	}
	        	if(order.get(fieldMappingDetails.get(USER_IP)) != null)
	        	{
	        		orderDetails.setUserIp((String)order.get(fieldMappingDetails.get(USER_IP)));
	        	}
	        	if(order.get(fieldMappingDetails.get(USER_AGENT)) != null)
	        	{
	        		orderDetails.setUserAgent((String)order.get(fieldMappingDetails.get(USER_AGENT)));
	        	}	        	
	        	if(order.get(fieldMappingDetails.get(CUSTOMER_EMAIL)) != null)
	        	{
	        		orderDetails.setCustomerEmailAddress((String)order.get(fieldMappingDetails.get(CUSTOMER_EMAIL)));
	        	}
	        	if(order.get(fieldMappingDetails.get(CUSTOMER_NAME)) != null)
	        	{
	        		orderDetails.setCustomerName((String)order.get(fieldMappingDetails.get(CUSTOMER_NAME)));
	        	}
	        	if(order.get(fieldMappingDetails.get(CUSTOMER_FIRST_NAME)) != null)
	        	{
	        		orderDetails.setCustomerFirstName((String)order.get(fieldMappingDetails.get(CUSTOMER_FIRST_NAME)));
	        	}
	        	if(order.get(fieldMappingDetails.get(CUSTOMER_LAST_NAME)) != null)
	        	{
	        		orderDetails.setCustomerLastName((String)order.get(fieldMappingDetails.get(CUSTOMER_LAST_NAME)));
	        	}
	        	if(order.get(fieldMappingDetails.get(VISITOR_ID)) != null)
	        	{
	        		orderDetails.setVisitorId((String)order.get(fieldMappingDetails.get(VISITOR_ID)));
	        	}	        		
	        	
	        	orderDetailsList.add(orderDetails); 	        		        	
	        	orderItemData = (ArrayList<LinkedHashMap<String, Object>>)order.get("items");
	        		
	        	if(orderItemData != null && !orderItemData.isEmpty())
		        {
	        	
		        	for(Map<String,Object> orderItem : orderItemData)
			        {				        	
			        	String productId = (String)orderItem.get(fieldMappingDetails.get(PRODUCT_ID));
			        	
			        	OrderItemDetails orderItemDetails = new OrderItemDetails();
			        	orderItemDetails.setClientId(clientId);
			        	orderItemDetails.setClientOrderId(clientOrderId);
			        	orderItemDetails.setProductId(productId);
			        		        	
			        	if(orderItem.get(fieldMappingDetails.get(PRODUCT_NAME)) != null)
			        	{
			        		orderItemDetails.setProductName((String)orderItem.get(fieldMappingDetails.get(PRODUCT_NAME)));
			        	}
			        	
			        	if(orderItem.get(fieldMappingDetails.get(PRODUCT_PRICE)) != null)
			        	{
			        		orderItemDetails.setProductPrice(String.valueOf(orderItem.get(fieldMappingDetails.get(PRODUCT_PRICE))));
			        	}
			        	
			        	if(orderItem.get(fieldMappingDetails.get(PRODUCT_URL)) != null)
			        	{
			        		orderItemDetails.setProductUrl((String)orderItem.get(fieldMappingDetails.get(PRODUCT_URL)));
			        	}
			        	
			        	if(orderItem.get(fieldMappingDetails.get(PRODUCT_SKU)) != null)
			        	{
			        		orderItemDetails.setProductSku((String)orderItem.get(fieldMappingDetails.get(PRODUCT_SKU)));
			        	}
			        	
			        	if(orderItem.get(fieldMappingDetails.get(PRODUCT_TYPE)) != null)
			        	{
			        		orderItemDetails.setProductType((String)orderItem.get(fieldMappingDetails.get(PRODUCT_TYPE)));
			        	}
			        	
			        	if(orderItem.get(fieldMappingDetails.get(QUANTITY)) != null)
			        	{
			        		orderItemDetails.setQuantity(Integer.parseInt(orderItem.get(fieldMappingDetails.get(QUANTITY)).toString()));
			        	}
			        	
			        	orderItemDetailsList.add(orderItemDetails);
			        }
		        } 
	        	else
	        	{
	        		String productId = (String)order.get(fieldMappingDetails.get(PRODUCT_ID));
		        	
		        	OrderItemDetails orderItemDetails = new OrderItemDetails();
		        	orderItemDetails.setClientId(clientId);
		        	orderItemDetails.setClientOrderId(clientOrderId);
		        	orderItemDetails.setProductId(productId);
		        		        	
		        	if(order.get(fieldMappingDetails.get(PRODUCT_NAME)) != null)
		        	{
		        		orderItemDetails.setProductName((String)order.get(fieldMappingDetails.get(PRODUCT_NAME)));
		        	}
		        	
		        	if(order.get(fieldMappingDetails.get(PRODUCT_PRICE)) != null)
		        	{
		        		orderItemDetails.setProductPrice(String.valueOf(order.get(fieldMappingDetails.get(PRODUCT_PRICE))));
		        	}
		        	
		        	if(order.get(fieldMappingDetails.get(PRODUCT_URL)) != null)
		        	{
		        		orderItemDetails.setProductUrl((String)order.get(fieldMappingDetails.get(PRODUCT_URL)));
		        	}
		        	
		        	if(order.get(fieldMappingDetails.get(PRODUCT_SKU)) != null)
		        	{
		        		orderItemDetails.setProductSku((String)order.get(fieldMappingDetails.get(PRODUCT_SKU)));
		        	}
		        	
		        	if(order.get(fieldMappingDetails.get(PRODUCT_TYPE)) != null)
		        	{
		        		orderItemDetails.setProductType((String)order.get(fieldMappingDetails.get(PRODUCT_TYPE)));
		        	}
		        	
		        	if(order.get(fieldMappingDetails.get(QUANTITY)) != null)
		        	{
		        		orderItemDetails.setQuantity(Integer.parseInt(order.get(fieldMappingDetails.get(QUANTITY)).toString()));
		        	}
		        	
		        	orderItemDetailsList.add(orderItemDetails);
	        	}
	        }
			
			logger.info(LOG_APPLICATION_FLOW + "Completed reading product content from downloaded feed.");
			
		}
		catch (Exception e)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportOrderDataImpl" , "readOrderContent", "Error occured while parsing order data, client id - " + clientId,"");
			logger.error(errorMessage,e);
		}
		
		
	}
	
	public ArrayList<Map<String,String>> getFieldMappingDetails(Map<String,Object> input)
	{		
		GetOrderDataFieldMappingDetails getOrderDataFieldMappingDetails = GetOrderDataFieldMappingDetails.getInstance();
		return getOrderDataFieldMappingDetails.runService(input);
	}
	
	public Integer processOrderData()
	{	
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(CLIENT_ID, clientId);
		
		Boolean hasOrderItemsSaved = false;
		Boolean hasOrderDetailsSaved = false;
		int result = 0;
		
		try
		{		
			if(orderItemDetailsList.size() > 0)
			{
				logger.info(LOG_APPLICATION_FLOW + "Started inserting order item bulk data.");
				Map<String,Object> orderItemData = new HashMap<String,Object>();
				orderItemData.put(CLIENT_ID, clientId);
				orderItemData.put(ORDER_ITEM_LIST, orderItemDetailsList);
				BatchInsertOrderItemsData batchInsertOrderItemsData = new BatchInsertOrderItemsData(); 
				hasOrderItemsSaved = batchInsertOrderItemsData.runService(orderItemData);
				orderItemData = null;
				logger.info(LOG_APPLICATION_FLOW + "Completed bulk inserting order item data.");				
				
			}
			
			if(orderDetailsList.size() > 0 && hasOrderItemsSaved)
			{
				logger.info(LOG_APPLICATION_FLOW + "Started bulk inserting order data.");
				Map<String,Object> orderData = new HashMap<String,Object>();
				orderData.put(CLIENT_ID, clientId);
				orderData.put(ORDER_LIST, orderDetailsList);
				BatchInsertOrderData batchInsertOrderData = new BatchInsertOrderData(); 
				hasOrderDetailsSaved = batchInsertOrderData.runService(orderData);
				orderData = null;
				logger.info(LOG_APPLICATION_FLOW + "Completed bulk inserting order data.");
			}
			
			if(hasOrderDetailsSaved)
			{
				InsertOrderData insertOrderData = InsertOrderData.getInstance();
				result = insertOrderData.runService(input);
				
				if(result > 0)
				{
				  logger.info(LOG_APPLICATION_FLOW + "Completed inserting order data to main tables.");
				}
				else if(result == 0)
				{
					logger.info(LOG_APPLICATION_FLOW + "Failed to insert order data to main tables.");
				}
			}
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportOrderDataImpl" , "processOrderData", "Error occured while processing order data for the client - " + clientId,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryOrderItemDetails(input);
			deleteTemporaryStorageData.deleteTemporaryOrderDetails(input);
		}
		
		return 1;
	}
}