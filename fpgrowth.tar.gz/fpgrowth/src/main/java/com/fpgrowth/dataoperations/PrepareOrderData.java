package com.fpgrowth.dataoperations;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.bytecode.opencsv.CSVWriter;

import com.fpgrowth.impl.db.GetOrderData;
import com.fpgrowth.util.FormatLoggerMessage;

import static com.fpgrowth.util.Constants.*;

public class PrepareOrderData
{
	private static final Logger logger = LoggerFactory.getLogger(PrepareOrderData.class.getClass());
	
	 
	public void generateOrderDataFile(Integer configId,String filePath)
	{
		try
		{
			Map<String,Object> input = new HashMap<String,Object>();
			
			input.put(CONFIG_ID, configId);
			GetOrderData getOrderData = GetOrderData.getInstance();
			ArrayList<String> orderList = getOrderData.runService(input);
						
			List<String[]> orderArrayList = new ArrayList<String[]>();
			
			if(orderList!=null)
			{
				for(String order :orderList)
				{
					 String[] strOrderDataArray = new String[1];
					 strOrderDataArray[0] = order;
					 orderArrayList.add(strOrderDataArray);
				}
			}
			
			orderList = null;
			exportToCsv(orderArrayList,filePath);
			orderArrayList = null;
			
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "PrepareOrderData" , "generateOrderDataFile", "Error fetching order data " ,"");
			logger.error(errorMessage,ex);
		}
		
	}
	
	public void exportToCsv(List<String[]> data,String filePath) throws IOException 
	{
		CSVWriter writer = null;
		try
		{		 
		  writer = new CSVWriter(new FileWriter(filePath), ',', CSVWriter.NO_QUOTE_CHARACTER);
		  writer.writeAll(data);		  
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "FileOperations" , "exportToCsv Error" ,"","Error occured while exporting content to file" + filePath);
			logger.error(errorMessage,ex);
		}
		finally
		{
			if(writer != null)
			{
			   writer.close();
			}
		}
	}	
	
}