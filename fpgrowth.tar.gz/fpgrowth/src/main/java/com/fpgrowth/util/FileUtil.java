package com.fpgrowth.util;

import java.io.File;


public class FileUtil
{
	/**
	 * Deletes an file from specified specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static void deleteFile(String fileLocation) throws Exception
	{
		try
		{
			File f = new File(fileLocation);

			if (f.exists())
			{
				f.delete();
			}
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}
}