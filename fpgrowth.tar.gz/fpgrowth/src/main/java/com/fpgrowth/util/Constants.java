package com.fpgrowth.util;

public class Constants
{
	public static final String LOG_INFO = "[INFO]";
	public static final String LOG_ERROR = "[ERROR]";
	public static final String LOG_APPLICATION_FLOW = "[FLOW]";
	public static final String CONFIG_ID = "config_id";
	public static final String FREQUENT_PATTERN_SETS = "frequent_pattern_sets";
	public static final String BUNDLE_TYPE_ID = "bundle_type_id";
}