package com.fpgrowth.util;

import java.util.Comparator;

public class SortOrderData implements Comparator<Long>
{
	public int compare(Long o1, Long o2) {
        return o1.compareTo(o2);
    }
	
}