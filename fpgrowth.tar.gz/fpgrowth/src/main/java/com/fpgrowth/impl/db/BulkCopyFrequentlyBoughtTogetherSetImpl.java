package com.fpgrowth.impl.db;

import static com.fpgrowth.util.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.fpgrowth.util.FormatLoggerMessage;
import com.fpgrowth.util.SortOrderData;
import com.google.common.base.Joiner;


public class BulkCopyFrequentlyBoughtTogetherSetImpl
{
	private static BulkCopyFrequentlyBoughtTogetherSetImpl instance = null;
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BulkCopyFrequentlyBoughtTogetherSetImpl.class.getName());

	public static BulkCopyFrequentlyBoughtTogetherSetImpl getInstance()
	{
		if (instance == null)
		{
			instance = new BulkCopyFrequentlyBoughtTogetherSetImpl();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{
		JdbcTemplate jdbcTemplate = com.fpgrowth.db.BaseDB.getJdbcTemplate(dataSourceLookupName);

		final Map<String,Integer> frequentPatterns = (Map<String,Integer>)input.get(FREQUENT_PATTERN_SETS);		
		final Integer configId = (Integer) input.get(CONFIG_ID);
	    
		String queryTmpl = "INSERT INTO frequently_bought_together_items"
				+ "(config_id,frequent_item_set,purchase_count,item_count) VALUES (?, ?, ?, ?)";

		final int batchSize = 5000;

		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;

					for (String frequentPattern : frequentPatterns.keySet())
					{
			    		String[] outputSequence = frequentPattern.split(",");
			    		
			    		if(outputSequence.length > 1 && outputSequence.length < 4) // Don't consider individual products
			    		{			  
			    			List<Long> ItemList = new ArrayList<Long>();
				    		for(String itemId :outputSequence)
				    		{
				    			ItemList.add(Long.parseLong(itemId));
				    		}
				    		
				    		Collections.sort(ItemList,new SortOrderData());		
				    		
			                ps.setInt(1, configId);
							ps.setString(2, Joiner.on(",").join(ItemList).toString());
							ps.setInt(3, frequentPatterns.get(frequentPattern));						
							ps.setInt(4, outputSequence.length);
						
							ps.addBatch();

							if (++count % batchSize == 0)
							{
								ps.executeBatch();
							}
			    		}    
					}
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR,"BulkCopyFrequentlyBoughtTogetherSetImpl.java","runService","failed to bulk insert the frequent patterns for the config id - " + configId, "");
			logger.error(errorMessage, ex);	
			return false;
		}
	}
}