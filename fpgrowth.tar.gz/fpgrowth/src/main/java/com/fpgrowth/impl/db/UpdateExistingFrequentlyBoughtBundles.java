package com.fpgrowth.impl.db;

import static com.fpgrowth.util.Constants.CONFIG_ID;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.fpgrowth.db.BaseDB;

public class UpdateExistingFrequentlyBoughtBundles extends StoredProcedure
{
	private static UpdateExistingFrequentlyBoughtBundles instance = null;
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Update_Existing_Bundle_Data";
	
	public static UpdateExistingFrequentlyBoughtBundles getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateExistingFrequentlyBoughtBundles();
		}
		return instance;
	}

	private UpdateExistingFrequentlyBoughtBundles()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ConfigId", Types.INTEGER));		
		compile();		
	}

	public Boolean runService(Map<String, Object> input) throws Exception
	{		
		Integer configId = (Integer) input.get(CONFIG_ID);			
		execute(configId);
		return true;
	}
}