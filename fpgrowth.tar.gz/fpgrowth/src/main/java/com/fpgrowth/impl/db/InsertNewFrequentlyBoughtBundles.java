package com.fpgrowth.impl.db;

import static com.fpgrowth.util.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.fpgrowth.db.BaseDB;

public class InsertNewFrequentlyBoughtBundles extends StoredProcedure
{
	private static InsertNewFrequentlyBoughtBundles instance = null;
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Generate_Frequently_Bought_Together_Product_Bundles";
	
	public static InsertNewFrequentlyBoughtBundles getInstance()
	{
		if (instance == null)
		{
			instance = new InsertNewFrequentlyBoughtBundles();
		}
		return instance;
	}

	private InsertNewFrequentlyBoughtBundles()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ConfigId", Types.INTEGER));		
		declareParameter(new SqlParameter("BundleTypeId", Types.INTEGER));
		compile();		
	}

	public Boolean runService(Map<String, Object> input) throws Exception
	{		
		Integer configId = (Integer) input.get(CONFIG_ID);	
		Integer bundleTypeId = (Integer) input.get(BUNDLE_TYPE_ID);	
		execute(configId,bundleTypeId);
		return true;
	}
	
}