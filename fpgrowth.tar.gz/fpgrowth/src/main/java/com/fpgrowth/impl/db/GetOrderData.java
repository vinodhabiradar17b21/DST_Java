package com.fpgrowth.impl.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.object.StoredProcedure;
import static com.fpgrowth.util.Constants.*;

import com.fpgrowth.db.BaseDB;


public class GetOrderData extends StoredProcedure
{
	private static GetOrderData instance = null;
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Export_Data_For_Frequent_Pattern_Algorithm";
	
	public static GetOrderData getInstance()
	{
		if (instance == null)
		{
			instance = new GetOrderData();
		}
		return instance;
	}

	private GetOrderData()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ConfigId", Types.INTEGER));
		declareParameter(new SqlReturnResultSet("#result-set-1", orderDataRowMapper));
		compile();
		
	}

	public ArrayList<String> runService(Map<String, Object> input) throws Exception
	{		
		Integer configId = (Integer) input.get(CONFIG_ID);			
		ArrayList<String> orderList = (ArrayList<String>) execute(configId).get("#result-set-1");
		return orderList;
	}
	
	private static final RowMapper<String> orderDataRowMapper;
	static
	{		
		orderDataRowMapper = new RowMapper<String>()
		{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{	
				return rs.getString("order_list");	
			}
		};
	}
}