package com.fpgrowth.impl.db;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.jdbc.object.StoredProcedure;

import com.fpgrowth.db.BaseDB;


public class GetBundleConfigurationList extends StoredProcedure
{
	private static GetBundleConfigurationList instance = null;
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Get_Bundle_Config_List_For_Frequent_Pattern_Algorithm";
	
	public static GetBundleConfigurationList getInstance()
	{
		if (instance == null)
		{
			instance = new GetBundleConfigurationList();
		}
		return instance;
	}

	private GetBundleConfigurationList()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);		
		compile();
		
	}

	public ArrayList<Map<String,Integer>> runService() throws Exception
	{				
		ArrayList<Map<String,Integer>> bundleConfigurationList = (ArrayList<Map<String,Integer>>) execute().get("#result-set-1");
		return bundleConfigurationList;
	}
}