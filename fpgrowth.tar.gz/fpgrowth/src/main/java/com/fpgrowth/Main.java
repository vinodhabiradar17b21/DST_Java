package com.fpgrowth;

import java.io.FileNotFoundException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import com.fpgrowth.util.AESBouncyCastle;
import com.fpgrowth.util.FormatLoggerMessage;
import com.fpgrowth.util.GetProperties;
import static com.fpgrowth.util.Constants.*;


public class Main {

	private static final Logger logger = LoggerFactory.getLogger(Main.class.getClass());
	private static Properties properties = null;
	private final static String SERVERAPPLICATIONCONTEXT = "webapp/WEB-INF/applicationContext.xml";
	private final static String SERVERPROPSFILE = "webapp/WEB-INF/service.properties";
	public static com.fpgrowth.util.AESBouncyCastle aes;
    

    public static void main(String[] args) throws FileNotFoundException {
    	
    	try
		{	
    		aes = AESBouncyCastle.getInstance("AirFrameBegining");    		
			logger.info(LOG_INFO + "Application started..");
			new FileSystemXmlApplicationContext(SERVERAPPLICATIONCONTEXT);			
			properties = GetProperties.readProperties(SERVERPROPSFILE);			
			
			logger.info(LOG_INFO + "Import data is scheduled to run at - "+ properties.getProperty("cron_timer"));
		}
		catch (Exception e)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "App" , "main", "Error reading prop file " ,"");
			logger.error(errorMessage,e);
			return;
		}
        
    }
}
