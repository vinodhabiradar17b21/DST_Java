package com.bestperformingcategorybundlescreator;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.bestperformingcategorybundlescreator.impl.GenerateCategoryBundlesImpl;
import com.bestperformingcategorybundlescreator.util.AESBouncyCastle;
import com.bestperformingcategorybundlescreator.util.FormatLoggerMessage;
import com.bestperformingcategorybundlescreator.util.GetProperties;

import static com.bestperformingcategorybundlescreator.util.Constants.*;


/**
 * Hello world!
 *
 */
public class App 
{
	private static final Logger logger = LoggerFactory.getLogger(App.class.getClass());
	public static com.bestperformingcategorybundlescreator.util.AESBouncyCastle aes;
	private static Properties properties = null;
	private final static String SERVERAPPLICATIONCONTEXT = "webapp/WEB-INF/applicationContext.xml";
	private final static String SERVERPROPSFILE = "webapp/WEB-INF/service.properties";

    public static void main(String[] args) throws FileNotFoundException    
    {
    	try
		{	
    		aes = AESBouncyCastle.getInstance("AirFrameBegining");   
    		new FileSystemXmlApplicationContext(SERVERAPPLICATIONCONTEXT);			
			properties = GetProperties.readProperties(SERVERPROPSFILE);	
			
			logger.info(LOG_INFO + "Application started..");
        	
			GenerateCategoryBundlesImpl generateCategoryBundlesImpl = new GenerateCategoryBundlesImpl();
			generateCategoryBundlesImpl.runService();
			
			logger.info(LOG_INFO + "Application Ended");
		}
		catch (Exception e)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "App" , "main", "Error reading prop file " ,"");
			logger.error(errorMessage,e);
			return;
		}
    }
}
