package com.bestperformingcategorybundlescreator.util;

public class Constants
{
	public static final String LOG_INFO = "[INFO]";
	public static final String LOG_ERROR = "[ERROR]";
	public static final String LOG_APPLICATION_FLOW = "[FLOW]";
	public static final String CLIENT_ID = "client_id";
	public static final String CONFIG_ID = "config_id";
	public static final String FREQUENT_PATTERN_SETS = "frequent_pattern_sets";
	public static final String BUNDLE_TYPE_ID = "bundle_type_id";
	public static final String INTERNAL_CATEGORY_ID = "internal_category_id";
	public static final String SPECIFIC_INTERNAL_PRODUCT_ID = "specific_internal_product_id";
	public static final String SPECIFIC_INTERNAL_PRODUCT_IDS_EXCLUDED = "specific_internal_product_ids_to_be_excluded";
	public static final String INTERNAL_CATEGORY_ID_LIST_EXCLUDED = "internal_category_id_list_to_be_excluded";
	public static final String PRIORITY_CROSS_CATEGORIES = "priority_cross_categories";
	public static final String USE_PARENT_CATEGORY_FOR_EXCLUSION = "use_parent_category_for_exclusion";
	public static final String USE_SAME_CATEGORY_OTHER_PRODUCTS = "use_same_category_other_products";
	public static final String PRIORITY_PRODUCT_LIST = "priority_product_list";
	public static final String PURCHASE_COUNT = "purchase_count";
	public static final String PURCHASE_COUNT_DECREMENTER = "purchase_count_decrementer";	
}