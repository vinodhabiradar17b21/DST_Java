package com.bestperformingcategorybundlescreator.db.impl;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.bestperformingcategorybundlescreator.db.BaseDB;

import static com.bestperformingcategorybundlescreator.util.Constants.*;


public class GenerateCategoryBasedBundlesDBSP4Impl 
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(GenerateCategoryBasedBundlesDBSP4Impl.class.getClass());
	
	private static GenerateCategoryBasedBundlesDBSP4Impl instance = null;
	
	private GenerateCategoryBasedBundlesDBSP4Impl()
	{
		
	}

	public static GenerateCategoryBasedBundlesDBSP4Impl getInstance()
	{
		if (instance == null)
		{
			instance = new GenerateCategoryBasedBundlesDBSP4Impl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Generate_CategoryBased_Algo_Bundles_Final(?, ?)}");
			
			cStmt.setInt(1, (Integer) input.get(CONFIG_ID));
			cStmt.setInt(2, Integer.parseInt((String) input.get(BUNDLE_TYPE_ID)));
												
			cStmt.execute();
					
			return 1;
			
		} 
		catch (Exception ex) 
		{
			System.out.println("Failed to generate category based bundles in GenerateCategoryBasedBundlesDBSP4Impl: ");
			return 0;
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		
	}
}