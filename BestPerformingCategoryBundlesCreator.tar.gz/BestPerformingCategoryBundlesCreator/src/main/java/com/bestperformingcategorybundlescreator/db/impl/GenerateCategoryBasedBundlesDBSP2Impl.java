package com.bestperformingcategorybundlescreator.db.impl;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.bestperformingcategorybundlescreator.db.BaseDB;

import static com.bestperformingcategorybundlescreator.util.Constants.*;


public class GenerateCategoryBasedBundlesDBSP2Impl 
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(GenerateCategoryBasedBundlesDBSP2Impl.class.getClass());
	
	private static GenerateCategoryBasedBundlesDBSP2Impl instance = null;
	
	private GenerateCategoryBasedBundlesDBSP2Impl()
	{
		
	}

	public static GenerateCategoryBasedBundlesDBSP2Impl getInstance()
	{
		if (instance == null)
		{
			instance = new GenerateCategoryBasedBundlesDBSP2Impl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Generate_Category_Based_Bundles(?, ?, ?, ?)}");
			
			cStmt.setInt(1, (Integer) input.get(CONFIG_ID));
			cStmt.setInt(2, Integer.parseInt((String)input.get(PURCHASE_COUNT)));	
			cStmt.setInt(3, Integer.parseInt((String)input.get(BUNDLE_TYPE_ID)));	
			cStmt.setInt(4, Integer.parseInt((String)input.get(PURCHASE_COUNT_DECREMENTER)));	
												
			cStmt.execute();
					
			return 1;
			
		} 
		catch (Exception ex) 
		{
			System.out.println("Failed to generate category based bundles in GenerateCategoryBasedBundlesDBSP2Impl: ");
			return 0;
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		
	}
}