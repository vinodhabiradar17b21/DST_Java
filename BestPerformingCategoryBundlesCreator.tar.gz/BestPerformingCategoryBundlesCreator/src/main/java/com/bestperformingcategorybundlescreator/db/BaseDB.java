package com.bestperformingcategorybundlescreator.db;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;



public class BaseDB
{
	/**
	 * Holds the JDBCTemplates used for each Datasource.  Accessed by lookupName defined in Spring Application Context
	 */
	private static Map<String, JdbcTemplate> jdbcTemplateMap = new HashMap<String, JdbcTemplate>();

	
	/**
	 * Sets the Datasource map
	 * @param dataSourceList - List of Beans from App Context
	 */
    public void setDataSourceList(List<DriverManagerDataSource> dataSourceList) 
    {
    	for (DriverManagerDataSource dataSource : dataSourceList)
    	{
    		jdbcTemplateMap.put(dataSource.getDataSourceLookupName(), new JdbcTemplate((DataSource) dataSource));
    	}
    }
    
    /**
     * Gets the Datasource given a particular Datasource lookupName
     * @param dataSourceLookupName - as defined in Application Context Datasource bean
     * @return Spring JDBCTemplate for executing queries against the datasource
     */
    public static JdbcTemplate getJdbcTemplate(String dataSourceLookupName)
    {
    	return jdbcTemplateMap.get(dataSourceLookupName);
    }

}