package com.bestperformingcategorybundlescreator.db.impl;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.bestperformingcategorybundlescreator.db.BaseDB;

import static com.bestperformingcategorybundlescreator.util.Constants.*;


public class GenerateCategoryBasedBundlesDBSP1Impl 
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(GenerateCategoryBasedBundlesDBSP1Impl.class.getClass());
	
	private static GenerateCategoryBasedBundlesDBSP1Impl instance = null;
	
	private GenerateCategoryBasedBundlesDBSP1Impl()
	{
		
	}

	public static GenerateCategoryBasedBundlesDBSP1Impl getInstance()
	{
		if (instance == null)
		{
			instance = new GenerateCategoryBasedBundlesDBSP1Impl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Generate_Best_Performing_Category_Bundles_Leekes(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			
			cStmt.setInt(1, (Integer) input.get(CLIENT_ID));
			cStmt.setInt(2, (Integer) input.get(CONFIG_ID));	
			cStmt.setInt(3, (Integer) input.get(INTERNAL_CATEGORY_ID));
			if(input.get(SPECIFIC_INTERNAL_PRODUCT_ID)!=null)
			{
				cStmt.setNString(4, (String) input.get(SPECIFIC_INTERNAL_PRODUCT_ID));
			}
			else
			{
				cStmt.setNString(4, null);
			}
			if(input.get(SPECIFIC_INTERNAL_PRODUCT_IDS_EXCLUDED)!=null)
			{
				cStmt.setNString(5, (String) input.get(SPECIFIC_INTERNAL_PRODUCT_IDS_EXCLUDED));
			}
			else
			{
				cStmt.setNString(5, null);
			}
			if(input.get(INTERNAL_CATEGORY_ID_LIST_EXCLUDED)!=null)
			{
				cStmt.setNString(6, (String) input.get(INTERNAL_CATEGORY_ID_LIST_EXCLUDED));
			}
			else
			{
				cStmt.setNString(6, null);
			}
			
			cStmt.setNString(7, (String) input.get(PRIORITY_CROSS_CATEGORIES));
			cStmt.setBoolean(8, (Boolean) input.get(USE_PARENT_CATEGORY_FOR_EXCLUSION));
			cStmt.setBoolean(9, (Boolean) input.get(USE_SAME_CATEGORY_OTHER_PRODUCTS));
			
			if(input.get(PRIORITY_PRODUCT_LIST)!=null)
			{
				cStmt.setNString(10, (String) input.get(PRIORITY_PRODUCT_LIST));
			}
			else
			{
				cStmt.setNString(10, null);
			}
												
			cStmt.execute();
					
			return 1;
			
		} 
		catch (Exception ex) 
		{
			System.out.println("Failed to generate category based bundles in GenerateCategoryBasedBundlesDBSP1Impl: ");
			return 0;
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		
	}
}