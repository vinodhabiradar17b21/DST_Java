package com.bestperformingcategorybundlescreator.db.impl;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.jdbc.object.StoredProcedure;

import com.bestperformingcategorybundlescreator.db.BaseDB;
import com.bestperformingcategorybundlescreator.interfaces.ServiceInterface;

public class ImportCategoryBundlesConfiguration extends StoredProcedure implements ServiceInterface<ArrayList<Map<String, Object>>>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static String SPROC_NAME = "Get_Category_Bundle_Generation_Configuration";	
	private static ImportCategoryBundlesConfiguration instance = null;
	
	private ImportCategoryBundlesConfiguration()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);	
		compile();		
	}

	public static ImportCategoryBundlesConfiguration getInstance()
	{
		if (instance == null)
		{
			instance = new ImportCategoryBundlesConfiguration();
		}
		return instance;
	}

	public ArrayList<Map<String, Object>> runService(Map<String, Object> input)
	{
		ArrayList<Map<String, Object>> results = (ArrayList<Map<String, Object>>) execute().get("#result-set-1");
		return results;
	}
}