package com.bestperformingcategorybundlescreator.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bestperformingcategorybundlescreator.db.impl.GenerateCategoryBasedBundlesDBSP1Impl;
import com.bestperformingcategorybundlescreator.db.impl.GenerateCategoryBasedBundlesDBSP2Impl;
import com.bestperformingcategorybundlescreator.db.impl.GenerateCategoryBasedBundlesDBSP3Impl;
import com.bestperformingcategorybundlescreator.db.impl.GenerateCategoryBasedBundlesDBSP4Impl;
import com.bestperformingcategorybundlescreator.db.impl.ImportCategoryBundlesConfiguration;
import com.bestperformingcategorybundlescreator.util.FormatLoggerMessage;

import static com.bestperformingcategorybundlescreator.util.Constants.*;

public class GenerateCategoryBundlesImpl
{
	private static final Logger logger = LoggerFactory.getLogger(GenerateCategoryBundlesImpl.class.getClass());
	
	public void runService() 
	{			
		try
		{
			Map<String, Object> input = new HashMap<String, Object>();

			ArrayList<Map<String,Object>> categoryBundlesConfigurationFromDB = new ArrayList<Map<String,Object>>();
			ImportCategoryBundlesConfiguration importCategoryBundlesConfiguration = ImportCategoryBundlesConfiguration.getInstance();
			categoryBundlesConfigurationFromDB = importCategoryBundlesConfiguration.runService(input);
			
			Map<String, Object> input2 = new HashMap<String, Object>();
			if(categoryBundlesConfigurationFromDB != null && categoryBundlesConfigurationFromDB.size() > 0)
			{
				for (Map<String, Object> field : categoryBundlesConfigurationFromDB)
				{
					input2.put(CLIENT_ID,field.get("client_id"));	
					input2.put(CONFIG_ID,field.get("config_id"));	
					input2.put(INTERNAL_CATEGORY_ID,field.get("internal_category_id"));	
					input2.put(SPECIFIC_INTERNAL_PRODUCT_ID,field.get("specific_internal_product_id"));	
					input2.put(SPECIFIC_INTERNAL_PRODUCT_IDS_EXCLUDED,field.get("specific_internal_product_ids_to_be_excluded"));	
					input2.put(INTERNAL_CATEGORY_ID_LIST_EXCLUDED,field.get("internal_category_id_list_to_be_excluded"));	
					input2.put(PRIORITY_CROSS_CATEGORIES,field.get("priority_cross_categories"));	
					input2.put(USE_PARENT_CATEGORY_FOR_EXCLUSION,field.get("use_parent_category_for_exclusion"));	
					input2.put(USE_SAME_CATEGORY_OTHER_PRODUCTS,field.get("use_same_category_other_products"));	
					input2.put(PRIORITY_PRODUCT_LIST,field.get("priority_product_list"));
					input2.put(BUNDLE_TYPE_ID,"3");
					input2.put(PURCHASE_COUNT,"200");
					input2.put(PURCHASE_COUNT_DECREMENTER,"5");
					
					GenerateCategoryBasedBundlesDBSP1Impl generateCategoryBasedBundlesDBSP1Impl = GenerateCategoryBasedBundlesDBSP1Impl.getInstance();
					generateCategoryBasedBundlesDBSP1Impl.runService(input2);
					
					try
					{
						GenerateCategoryBasedBundlesDBSP2Impl generateCategoryBasedBundlesDBSP2Impl = GenerateCategoryBasedBundlesDBSP2Impl.getInstance();
						int isGnerated = generateCategoryBasedBundlesDBSP2Impl.runService(input2);
						
						if(isGnerated == 0)
						{
							try
							{
								GenerateCategoryBasedBundlesDBSP3Impl generateCategoryBasedBundlesDBSP3Impl = GenerateCategoryBasedBundlesDBSP3Impl.getInstance();
								generateCategoryBasedBundlesDBSP3Impl.runService(input2);
								
								GenerateCategoryBasedBundlesDBSP4Impl generateCategoryBasedBundlesDBSP4Impl = GenerateCategoryBasedBundlesDBSP4Impl.getInstance();
								generateCategoryBasedBundlesDBSP4Impl.runService(input2);
							}
							catch(Exception ex2)
							{
								String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "GenerateCategoryBundlesImpl" , "runService", "Error occured " ,"");
								logger.error(errorMessage,ex2);
							}
						}
					}
					catch(Exception ex1)
					{	
						String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "GenerateCategoryBundlesImpl" , "runService", "Error occured " ,"");
						logger.error(errorMessage,ex1);
					}
				}
			}
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "GenerateCategoryBundlesImpl" , "runService", "Error occured " ,"");
			logger.error(errorMessage,ex);
		}		
	}

}