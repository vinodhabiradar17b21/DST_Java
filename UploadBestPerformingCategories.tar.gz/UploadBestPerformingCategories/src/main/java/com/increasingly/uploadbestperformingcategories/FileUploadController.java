package com.increasingly.uploadbestperformingcategories;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.increasingly.uploadbestperformingcategories.impl.InsertBestCategories;



@Path("/test")
public class FileUploadController  {
	
@POST  
@Path("/upload")  
@Consumes(MediaType.MULTIPART_FORM_DATA)
public Response uploadFile(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail) 
{  
	String fileLocation = "/home/shree/" + fileDetail.getFileName();  
	try 
	{  
		FileOutputStream out = new FileOutputStream(new File(fileLocation));  
		
	    int read = 0;  
	    byte[] bytes = new byte[1024];  
	    out = new FileOutputStream(new File(fileLocation));  
	    
	    while ((read = uploadedInputStream.read(bytes)) != -1) 
	    {  
	        out.write(bytes, 0, read);  
	    }  
	    
	    out.flush();  
	    out.close(); 
	    
	    Map<String, Object> input = new HashMap<String, Object>();
	    input.put("filelocation", fileLocation);
	    
	    InsertBestCategories categories = InsertBestCategories.getInstance();
	    categories.runService(input);
	} 
	catch (IOException e) 
	{
		e.printStackTrace();
	}  
	
	String output = "File successfully read and inserted to DB : ";  
	
	return Response.status(200).entity(output).build();  
} 

}