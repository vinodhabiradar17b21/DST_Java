package com.increasingly.uploadbestperformingcategories.impl;




import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasingly.uploadbestperformingcategories.db.BaseDB;
import com.increasingly.uploadbestperformingcategories.utils.FormatLoggerMessage;


public class InsertBestCategories 
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertBestCategories.class.getClass());
	
	private static InsertBestCategories instance = null;
	
	public InsertBestCategories()
	{
		
	}

	public static InsertBestCategories getInstance()
	{
		if (instance == null)
		{
			instance = new InsertBestCategories();
		}
		return instance;
	}

	public void runService(Map<String, Object> input) 
	{
		Connection conn = null;

		try
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("LOAD DATA LOCAL INFILE ? "
					+ "INTO TABLE  best_performing_category_bundles_configurations FIELDS TERMINATED BY '|' "
					+ "LINES TERMINATED BY '\n' "
					+ "IGNORE 1 LINES (@client_id, @config_id, @internal_category_id, @specific_internal_product_id,"
					+ "@specific_internal_product_ids_to_be_excluded, @internal_category_id_list_to_be_excluded, "
					+ "@priority_cross_categories, @use_parent_category_for_exclusion, @use_same_category_other_products, "
					+ "@priority_product_list) "
					+ "SET client_id = nullif(@client_id,''),"
					+ "config_id = nullif(@config_id,''),"
					+ "internal_category_id = nullif(@internal_category_id,''),"
					+ "specific_internal_product_id = nullif(@specific_internal_product_id,''),"
					+ "specific_internal_product_ids_to_be_excluded = nullif(@specific_internal_product_ids_to_be_excluded,''),"
					+ "internal_category_id_list_to_be_excluded = nullif(@internal_category_id_list_to_be_excluded,''),"
					+ "priority_cross_categories = nullif(@priority_cross_categories,''),"
					+ "use_parent_category_for_exclusion = nullif(@use_parent_category_for_exclusion,''),"
					+ "use_same_category_other_products = nullif(@use_same_category_other_products,''),"
					+ "priority_product_list = nullif(@priority_product_list,'');");
					
			cStmt.setString(1, (String)input.get("filelocation"));	
			cStmt.executeUpdate();
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError("[ERROR]" , "InsertBestCategories" , "Error Occured while inserting record." ,"");
			logger.error(errorMessage,ex);
		}
	}
}