package com.increasingly.uploadbestperformingcategories.utils;

public class FormatLoggerMessage
{
	private FormatLoggerMessage()
	{
		
	}
	
    public static String formatError(String constantType, String type, String errorType, String data)
    {
       return (constantType + "\t" + type + "\t" + errorType + "\t" + data);
    }
    
    public static String formatInfo(String constantType,String type, String infoType, String data)
    {
    	return (constantType + "\t" + type + "\t" + infoType + "\t" + data);
    }
}