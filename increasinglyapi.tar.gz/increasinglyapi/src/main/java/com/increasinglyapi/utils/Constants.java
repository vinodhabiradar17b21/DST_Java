package com.increasinglyapi.utils;

public class Constants
{
	public static final String LOG_INFO = "[INFO]";
	public static final String LOG_ERROR = "[ERROR]";
	public static final String LOG_APPLICATION_FLOW = "[FLOW]";
	
	public static final String EVENT_TYPE = "event_type";
	public static final String EVENT_TYPE_ORDER = "order";
	public static final String EVENT_TYPE_HOME_PAGE_VISIT = "home_page_visit";
	public static final String EVENT_TYPE_CATEGORY_PAGE_VISIT = "category_page_visit";
	public static final String EVENT_TYPE_PRODUCT_PAGE_VISIT = "product_page_visit";
	public static final String EVENT_TYPE_SEARCH_PAGE = "search_page";
	public static final String EVENT_TYPE_ADD_TO_CART = "add_to_cart";
	public static final String EVENT_TYPE_REMOVE_FROM_CART = "remove_from_cart";
	public static final String EVENT_TYPE_CUSTOMER_LOGIN = "login";
	public static final String EVENT_TYPE_PRODUCT_ADD_OR_UPDATE = "product_add_or_update";
	public static final String EVENT_TYPE_PRODUCT_DELETE = "product_delete";
	public static final String EVENT_TYPE_VALIDATE_API = "validate_api";
	public static final String EVENT_TYPE_SAVE_API_ENABLE_STATUS = "save_api_enable_status";
	public static final String EVENT_TYPE_BUNDLE_ORDER = "bundle_order";
	public static final String EVENT_TYPE_SHIPPING_DETAILS_IMPORT = "shipping_details_import";
	public static final String EVENT_TYPE_BUNDLE_ADD_TO_CART = "bundle_add_to_cart";
	public static final String EVENT_TYPE_BUNDLE_REMOVE_FROM_CART = "bundle_delete_from_cart";
	public static final String EVENT_TYPE_TRACK_ERROR = "track_error";
	public static final String EVENT_TYPE_BUNDLE_ADD_TO_CART_FAILURE = "bundle_add_to_cart_failuer";
	public static final String EVENT_TYPE_BUNDLE_PRODUCT_CLICK_TRACKING = "bundle_product_click_tracking";
	public static final String EVENT_TYPE_PRODUCT_ATTRIBUTE_UPDATE_TRACKING = "product_attribute_update";
	public static final String EVENT_TYPE_ADD_TO_CART_MULTIPLE= "shopping_cart_visit";

	public static final String EVENT_METHOD = "method";
	public static final String EVENT_METHOD_TRACK = "track";
	public static final String EVENT_METHOD_IMPORT = "import";
	
	public static final String PLATFORM = "platform";
	public static final String PLATFORM_ID = "platform_id";
	public static final String CLIENT_ID = "client_id";
	public static final String TOKEN = "token";
	public static final String VERSION = "version"; // Our application version
	public static final String EVENT_DATA = "event_data";
	public static final String VISITOR_ID = "vid";
	public static final String VISIT_TIME = "time";
	public static final String REFERRAL_URL = "uri";
	public static final String USER_AGENT = "user_agent";
	public static final String IS_API_ENABLED = "is_api_enabled";
	public static final String STORE_NAME = "store_name";
	public static final String STORE_URL = "store_url";
	public static final String BUNDLE_ID = "bundle_id";
	public static final String PRODUCT_IDS = "product_ids";
	public static final String BUNDLE_ID_LIST = "bundleIdList";
	
	
	public static final String ORDER_ID = "order_id";
	public static final String ORDER_STATUS = "order_status";
	public static final String ORDER_AMOUNT = "order_amount";
	public static final String SHIPPING_AMOUNT = "shipping_amount";
	public static final String TAX_AMOUNT = "tax_amount";
	
	public static final String SHIPPING_METHOD = "shipping_method";
	public static final String CURRENCY_CODE = "currency_code";
	public static final String PAYMENT_METHOD = "payment_method";
	public static final String CUSTOMER_NAME = "customer_name";	
	public static final String CUSTOMER_FIRST_NAME = "customer_first_name";	
	public static final String CUSTOMER_LAST_NAME = "customer_last_name";
	public static final String CUSTOMER_EMAIL = "customer_email";
	
	public static final String DISCOUNT_AMOUNT = "discount_amount";
	public static final String COUPON_CODE = "coupons";
	public static final String USER_IP = "user_ip";
	public static final String ORDER_TIME = "order_time";
	
	public static final String FEED_ID = "feed_id";
	public static final String ITEMS = "items";
	public static final String BUNDLES = "bundles";
	public static final String BUNDLE_DATA = "bundle_data";
	public static final String CUSTOMER_DATA = "customer_data";
	public static final String PRODUCT_ID = "product_id";
	public static final String PRODUCT_PRICE = "product_price";
	public static final String PRODUCT_NAME = "product_name";
	public static final String PRODUCT_URL = "product_url";
	
	public static final String TOTAL_PRICE = "totalPrice";
	public static final String BUNDLE_DISCOUNT_AMOUNT = "discountPrice";
	
	public static final String SPECIAL_PRICE = "special_price";
	public static final String IMAGE_URL = "image_url";
	public static final String DESCRIPTION = "description";
	public static final String SHORT_DESCRIPTION = "short_description";
	public static final String CLIENT_PRODUCT_STATUS = "status";
	public static final String MANUFACTURER = "manufacturer";
	public static final String VISIBILITY = "visibility";
	public static final String PRICE = "price";
	public static final String AVAILABILITY = "availability";
	
	public static final String COLOR = "color";
	public static final String SIZE = "size";
	public static final String WEIGHT = "weight";
	
	public static final String PRODUCT_SKU = "product_sku";
	public static final String PRODUCT_TYPE = "product_type";
	public static final String QUANTITY = "qty";
	public static final String CATEGORY_ID = "category_id";
	
	public static final String CREATED_DATE = "created_at";
	public static final String UPDATED_DATE = "updated_at";
	public static final String ASSOCIATED_PRODUCTS = "associated_products";
	public static final String RELATED_PRODUCTS = "related_products";
	public static final String UP_SELL_PRODUCTS = "up_sell_products";
	public static final String CROSS_SELL_PRODUCTS = "cross_sell_products";
	public static final String CATEGORIES = "categories";
	public static final String PRODUCT_OPTIONS = "product_attribute_data";
	
	public static final String CATEGORY_LIST = "category_list";
	public static final String PRODUCT_LIST = "product_list";
	public static final String ASSOCIATED_PRODUCT_LIST = "associated_product_list";
	public static final String OTHER_IMAGE_LIST = "other_image_list";
	
	public static final String ID = "id";
	public static final String NAME = "name";
	
	public static final String OPTION_PRODUCT_ID = "option_product_id";
	public static final String OPTION_PRODUCT_NAME = "option_product_name";
	public static final String OPTION_PRODUCT_SKU = "option_product_sku";
	public static final String OPTION_PRODUCT_PRICE = "option_product_price";
	
	public static final String CHILD_PRODUCT_ID = "child_product_id";
	public static final String CHILD_PRODUCT_SKU = "child_product_sku";
	public static final String STORE_ID = "store_id";
	public static final String ATTRIBUTE_CODE = "attribute_code";
	public static final String ATTRIBUTE_ID = "attribute_id";
	public static final String ATTRIBUTE_LABEL = "attribute_label";
	public static final String OPTION_ID = "option_id";
	public static final String OPTION_TEXT = "option_text";
	public static final String OPTION_IMAGE_URL = "option_image_url";
	public static final String IS_PERCENT = "is_percent";
	public static final String PRICING_VALUE = "pricing_value";
	public static final String COLOR_CODE = "color_code";
	public static final String FIELD_TYPE = "field_type";
	public static final String PRODUCT_OPTIONS_LIST = "product_options_data";
	public static final String ITEM_ATTRIBUTE_LIST = "item_attribute_list";
	public static final String ORDER_DATA_IS_BULK_PROCESSING = "order_data_is_bulk_processing";
	public static final String ATTRIBUTES_DATA = "attributes_data";
	
	public static final String IS_LOGGED_IN = "is_logged_in";
	public static final String SEARCH_QUERY = "query";
	public static final String SEARCH_RESULT_COUNT = "result_count";
	
	public static final String ALGORITHM = "MD5";
	public static final String ORDER_LIST = "order_list";
	
	public static final String BUNDLE_PRICE = "bundle_price";
	
	public static final String INCREASINGLY_VISITOR_ID = "inc_vid"; 
	
	public static final String IS_FREE_SHIPPING_ACTIVE = "is_free_shipping_active"; 
	public static final String FREE_SHIPPING_SUB_TOTAL = "free_shipping_subtotal"; 
	public static final String FREE_SHIPPING_TITLE = "free_shipping_title"; 
	
	public static final String HAS_ASSOCIATED_PRODUCTS = "has_associated_products"; 
	public static final String HAS_RELATED_PRODUCTS = "has_related_products"; 
	public static final String HAS_CROSS_SELL_PRODUCTS = "has_cross_sell_products"; 
	public static final String HAS_UP_SELL_PRODUCTS = "has_up_sell_products"; 
	public static final String HAS_OTHER_IMAGES = "has_other_images"; 
	
	public static final String PRODUCT_INVENTORY_DATA = "inventory_details";
	public static final String BACKORDERS = "backorders";
	public static final String USE_CONFIG_BACKORDERS = "use_config_backorders";
	public static final String MIN_SALE_QUANTITY = "min_sale_qty";
	public static final String USE_CONFIG_MIN_SALE_QUANTITY = "use_config_min_sale_qty";
	public static final String MAX_SALE_QUANTITY = "max_sale_qty";
	public static final String USE_CONFIG_MAX_SALE_QUANTITY = "use_config_max_sale_qty";
	public static final String IS_IN_STOCK = "is_in_stock";
	public static final String MIN_QUANTITY = "min_qty";	
	
	public static final String ERROR_MESSAGE = "error_message";
	
	public static final String PAGE_TYPE_ID = "page_type";
	public static final String PURCHASE_TYPE = "purchase_type"; // click & collect or delivery
	public static final String CORE_PRODUCT_ID = "core_product_id";
	public static final String IS_LOGGED_IN_USER = "is_logged";
	public static final String IS_ABANDONED_CART_BUNDLE = "is_abandoned";
	
}