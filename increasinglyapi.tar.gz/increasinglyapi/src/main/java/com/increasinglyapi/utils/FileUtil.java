package com.increasinglyapi.utils;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class FileUtil
{
	/**
	 * Deletes an file from specified specified
	 * 
	 * @return Boolean
	 * @throws Exception
	 */
	public static void deleteFile(String fileLocation) throws Exception
	{
		try
		{
			File f = new File(fileLocation);

			if (f.exists())
			{
				f.delete();
			}
		}
		catch (Exception e)
		{
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Parses the XML content to DOM, which will make the content easier to iterate.
	 * 
	 * @param xmlPath - URL / Absolute path of the XML file
	 *
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static Document xmlToDoc(String xmlData) throws ParserConfigurationException, SAXException, IOException
	{
		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			builder = factory.newDocumentBuilder();	
			
			InputSource is = new InputSource(new StringReader(xmlData));			
			return builder.parse(is);
		}
		catch (Exception e)
		{
			return null;
		}
	}

	/**
	 * Returns the content/value of tag given from Element. If tag not found, returns attribute's value.
	 * 
	 * @param tagName
	 * @param element
	 * @return
	 */
	public static String getString(String name, Element element)
	{
		NodeList list = element.getElementsByTagName(name);
		if (list != null && list.getLength() > 0)
		{
			NodeList subList = list.item(0).getChildNodes();
			if (subList != null && subList.getLength() > 0)
			{
				return subList.item(0).getNodeValue();
			}
		}
		else if (element.hasAttribute(name))
		{
			return element.getAttribute(name);
		}
		else if (!element.hasAttribute(name))
		{
			NodeList nl = element.getElementsByTagName("*");
			for (int i = 0; i < nl.getLength(); i++)
			{
				Element innerElement = (Element) nl.item(i);
				if (innerElement.hasAttribute(name))
				{
					return innerElement.getAttribute(name);
				}
			}
		}
		return null;
	}

}