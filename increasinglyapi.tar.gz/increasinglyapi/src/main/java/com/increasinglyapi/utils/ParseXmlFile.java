package com.increasinglyapi.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ParseXmlFile
{
	public LinkedHashMap<String, String> getXMLParsedData(String xmlData) throws Exception
	{
		Document dom = null;
		
		dom = FileUtil.xmlToDoc(xmlData);

		// This can hold attribute name/value also
		LinkedHashMap<String, String> xmlTagNamesWithData = new LinkedHashMap<String, String>();
		Element rootElement = dom.getDocumentElement();
		NodeList nodeList = rootElement.getElementsByTagName("*");
		Boolean hasParsedOneSet = false; 
		ArrayList<String> rootNameArr = new ArrayList<String>();

		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node element = (Node) nodeList.item(i);
			String tagName = element.getNodeName();
			Integer nodeCount = element.getChildNodes().getLength();
			String value = xmlTagNamesWithData.get(element.getNodeName());

			String attrValue = "";
			NamedNodeMap attrNodes = null;
			if ((attrNodes = element.getAttributes()) != null)
			{
				for (int j = 0; j < attrNodes.getLength(); ++j)
				{
					Node attr = attrNodes.item(j);					
					attrValue = attr.getNodeValue();					
				}
			}

			if (nodeCount < 2 && value == null)
			{
				String tagContent = hasParsedOneSet ? "" : element.getTextContent();
				xmlTagNamesWithData.put(attrValue, tagContent);
			}
			else if (nodeCount > 1 && hasParsedOneSet == false)
			{
				if (rootNameArr.contains(tagName))
				{
					hasParsedOneSet = true;
				}
				else
				{
					rootNameArr.add(tagName);
				}
			}
		}
		
		return xmlTagNamesWithData;
	}
}