package com.increasinglyapi;

import static com.increasinglyapi.utils.Constants.*;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.io.Charsets;
import org.eclipse.jetty.http.HttpStatus;
import org.glassfish.jersey.server.ParamException.CookieParamException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.impl.Configuration;
import com.increasinglyapi.impl.ImportDataImpl;
import com.increasinglyapi.impl.ImportDataParameters;
import com.increasinglyapi.impl.JsonResponse;
import com.increasinglyapi.impl.TrackRequest;
import com.increasinglyapi.impl.db.ErrorLog;
import com.increasinglyapi.utils.FormatLoggerMessage;

/**
 * All requests hits this end point
 * @author shreehari.padaki
 *
 */
@Path("")
public class ImportData
{
	private static final Logger logger = LoggerFactory.getLogger(ImportData.class.getClass());
	static byte[] trackingGif = { 0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x1, 0x0, 0x1, 0x0, (byte) 0x80, 0x0, 0x0, (byte)  0xff, (byte)  0xff,  (byte) 0xff, 0x0, 0x0, 0x0, 0x2c, 0x0, 0x0, 0x0, 0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x2, 0x2, 0x44, 0x1, 0x0, 0x3b };
	
	
	/**
	 * @return
	 * @throws MalformedURLException Valid example URL 
	 */
	@SuppressWarnings("finally")
	@POST	
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	@Path("ImportData")	
	public Response importData(ImportDataParameters importData,@Context HttpServletRequest request,
			@Context HttpHeaders headers)
	{
		Map<String, Cookie> cookieList = new HashMap<String,Cookie>();
		JsonResponse jsonResponse = null;
		ResponseBuilder responseBuilder = Response.ok();	
		String domain = "";
		
		
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Import data tracking request started.");
			/*importData.setUserIpAddress(headers.getHeaderString("X-Forwarded-For"));
	
			if (importData.getUserIpAddress() == null || importData.getUserIpAddress().length() == 0) 
			{
				importData.setUserIpAddress(request.getRemoteAddr());
			}			*/
			
			TrackRequest trackRequest = new TrackRequest();
			cookieList = headers.getCookies();
			trackRequest.setCookieList(cookieList);		
			
			importData.setUserAgent(request.getHeader("User-Agent"));
						
			 if(headers.getHeaderString("Origin") != null)
			 {
					if(!headers.getHeaderString("Origin").isEmpty())
					{
						domain = headers.getHeaderString("Origin");
					}				
			 }
						
			ImportDataImpl importDataImpl = new ImportDataImpl();
			importDataImpl.setTrackRequest(trackRequest);
			jsonResponse = importDataImpl.saveImportedData(importData);	
			
			/*
			importDataImpl.generateVisitorId(trackRequest);	
			List<Cookie> outCookieList = importDataImpl.getCookies();
			
			if(outCookieList != null && outCookieList.size() > 0)
			{
				for(Cookie cookieItem : outCookieList)
				{					
					NewCookie newCookie = new NewCookie(cookieItem,"",31536000,false);		
				    responseBuilder.cookie(newCookie);			    
				}
			}
			*/
			
			logger.info(LOG_APPLICATION_FLOW + "Import data tracking request completed.");
				
		}
		catch(Exception ex)
		{
			String errorMessage = com.increasinglyapi.utils.FormatLoggerMessage.formatError(LOG_ERROR , "ImportData" ,"Error occured while importing data." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("ImportData.java importData()", "Error occured while importing data.", ex.getMessage());
		}
		finally
		{	
			if(domain.equals(""))
			{
				domain = "*";
			}
			
			if(jsonResponse != null)
			{
				
			   return  responseBuilder					 
					  .header("Pragma", "no-cache")				
					  .header("Access-Control-Allow-Origin",domain)	
					  .header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept")
					  .header("X-Frame-Options", "SAMEORIGIN")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("X-XSS-Protection", "1; mode=block")	
					  .header("p3p", "policyref=\"http://www.increasingly.co/w3c/p3p.xml\", CP=\"NOI DSP COR DEVa PSAa OUR BUS COM NAV\"")
					  .header("Content-Type","application/json; charset=utf-8")
					  .header("Expires", -1)					
					  .entity(jsonResponse)					
					  .build();
			}	
			else
			{		                 
				return responseBuilder						 
						  .header("Pragma", "no-cache")	
						  .header("Access-Control-Allow-Origin",domain)								
						  .header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,Authorization")
						  .header("X-Frame-Options", "SAMEORIGIN")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("X-XSS-Protection", "1; mode=block")	
						  .header("p3p", "policyref=\"http://www.increasingly.co/w3c/p3p.xml\", CP=\"NOI DSP COR DEVa PSAa OUR BUS COM NAV\"")
						  .header("Content-Type","application/json; charset=utf-8")						
						  .entity("")
						  .build();
			}
			
		}
		
	}
	
	@SuppressWarnings("finally")
	@GET
	@Produces({MediaType.APPLICATION_JSON})
	@Path("GetVisitorId")	
	public Response getVisitorId(@Context HttpServletRequest request,
			@Context HttpHeaders headers)
	{
		Map<String, Cookie> cookieList = new HashMap<String,Cookie>();	
		ResponseBuilder responseBuilder = Response.ok();
		
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Import data tracking request started.");
						
			TrackRequest trackRequest = new TrackRequest();
			cookieList = headers.getCookies();
			trackRequest.setCookieList(cookieList);						
		
			if(request.getParameter("ivid") != null)
			{
			  String ivid = request.getParameter("ivid");
			  
			  if(!ivid.isEmpty())
			  {
				  trackRequest.setIncreasinglyVisitorId(ivid);
			  }
			}
			
			ImportDataImpl importDataImpl = new ImportDataImpl();
			importDataImpl.generateVisitorId(trackRequest);	
			
			List<Cookie> outCookieList = importDataImpl.getCookies();
			
			if(outCookieList != null && outCookieList.size() > 0)
			{
				for(Cookie cookieItem : outCookieList)
				{			
					//NewCookie(String name, String value, String path, String domain, String comment, int maxAge, boolean secure, boolean httpOnly)
					NewCookie newCookie = new NewCookie(cookieItem.getName(),cookieItem.getValue(),"/",Configuration.getDomain(),"",31536000,false,true);		
				    responseBuilder.cookie(newCookie);
				}
			}
			else
			{
			  logger.info(LOG_APPLICATION_FLOW + "Failed to write cookie for the request.");
			}
			
			logger.info(LOG_APPLICATION_FLOW + "Import data tracking request completed.");
				
		}
		catch(Exception ex)
		{
			String errorMessage = com.increasinglyapi.utils.FormatLoggerMessage.formatError(LOG_ERROR , "ImportData" ,"Error occured while getting Visitor Id." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("ImportData.java getVisitorId()", "Error occured while getting Visitor Id.", ex.getMessage());
		}
		finally
		{	
			
			return responseBuilder
					  .status(HttpStatus.OK_200)
					  .header("Pragma", "no-cache")	
					  .header("Access-Control-Allow-Origin","*")
					  .header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept")
					  .header("X-Frame-Options", "SAMEORIGIN")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("X-XSS-Protection", "1; mode=block")	
					  .header("p3p", "policyref=\"http://www.increasingly.co/w3c/p3p.xml\", CP=\"NOI DSP COR DEVa PSAa OUR BUS COM NAV\"")
					  .entity("")
					  .build();
			
		}
		
	}

	/**
	 * @return
	 * @throws MalformedURLException Valid example URL 
	 */
	@SuppressWarnings("finally")
	@GET	
	@Path("track")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response results(@Context HttpServletRequest request,
			@Context HttpHeaders headers) throws MalformedURLException,
			CookieParamException
	{
			
		ResponseBuilder responseBuilder = Response.ok();	
		String domain = "";
		Map<String, Cookie> cookieList = new HashMap<String,Cookie>();
		
		try 
		{
			TrackRequest trackRequest = new TrackRequest();
			cookieList = headers.getCookies();
			trackRequest.setCookieList(cookieList);
			
			String queryString = request.getQueryString();
			
			if(!queryString.contains("CONVERSION_PIXEL"))
			{
				queryString = "CONVERSION_PIXEL/" + queryString;
			}
			
			trackRequest.setQueryString(queryString);
			logger.info(LOG_INFO + queryString);
						
            trackRequest.setUserAgent(request.getHeader("User-Agent"));
            trackRequest.setUserHost(request.getRemoteHost());
            
            String referralURL = request.getRequestURL() != null ? request.getRequestURL().toString() : "";
            trackRequest.setReferralURL(referralURL);            
            
            if(headers.getHeaderString("Origin") != null)
			{
				if(!headers.getHeaderString("Origin").isEmpty())
				{
					domain = headers.getHeaderString("Origin");
				}				
			}
                        
			/*trackRequest.setUserIpAddress(headers.getHeaderString("X-Forwarded-For"));

			if (trackRequest.getUserIpAddress() == null || trackRequest.getUserIpAddress().length() == 0) 
			{
				trackRequest.setUserIpAddress(request.getRemoteAddr());
			}
*/
			if (headers.getHeaderString("x-forwarded-proto") != null && headers.getHeaderString("x-forwarded-proto").equals("https"))
			{
				trackRequest.setIsSecure(true);
			} 
			else 
			{
				trackRequest.setIsSecure((trackRequest.getProtocol().equals("https")) ? true : false);
			}

			trackRequest.setProtocol(request.getProtocol());			
			
			if(trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID) == null)
		    {
			  logger.info(LOG_INFO + "Visitor Id is missing - Query String - " + request.getQueryString() + " Is Secure -" + trackRequest.getIsSecure() +" User Agent -" + trackRequest.getUserAgent() + " referral Url - " + trackRequest.getReferralURL() + " Domain - "+ domain);				
			}			
			
			ImportDataImpl importDataImpl = new ImportDataImpl();
			importDataImpl.processPixelRequest(trackRequest);
						
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR,"Tracker", "Error processing request", "");
			logger.error(errorMessage, ex);
			ErrorLog.saveErrorLogToDB("ImportData.java results()", "Error occured while processing request.", ex.getMessage());
		}
		finally 
		{
			String responseContentType = "charSet=" + Charsets.UTF_8;

			Object responseContent = "";
			responseContentType = "image/gif;" + responseContentType;
								
			responseContent = trackingGif;
			
			if(domain.equals(""))
			{
				domain = "*";
			}	
					
			return responseBuilder						 
					  .header("Pragma", "no-cache")	
					  .header("Access-Control-Allow-Origin",domain)								
					  .header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,Authorization")
					  .header("p3p", "policyref=\"http://www.increasingly.co/w3c/p3p.xml\", CP=\"NOI DSP COR DEVa PSAa OUR BUS COM NAV\"")
					  .header("X-Frame-Options", "SAMEORIGIN")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("X-XSS-Protection", "1; mode=block")	
					  .header("Content-Type",responseContentType)						
					  .entity(responseContent)
					  .build();

		}
	}
	
}
