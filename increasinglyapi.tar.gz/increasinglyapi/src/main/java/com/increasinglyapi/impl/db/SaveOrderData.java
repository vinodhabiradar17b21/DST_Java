package com.increasinglyapi.impl.db;



import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;


public class SaveOrderData  extends StoredProcedure implements ServiceInterface<Boolean>{
	
	private final static String dataSourceLookupName = "mysqlserver";	
	private static final String SPROC_NAME = "Save_Order_Details";
	
	private static SaveOrderData instance = null;
	
	public SaveOrderData()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ClientId", Types.INTEGER));
		declareParameter(new SqlParameter("PlatformId", Types.INTEGER));
		declareParameter(new SqlParameter("ClientOrderId", Types.VARCHAR));
		declareParameter(new SqlParameter("OrderStatus", Types.VARCHAR));
		declareParameter(new SqlParameter("OrderAmount", Types.DECIMAL));
		declareParameter(new SqlParameter("CouponCode", Types.VARCHAR));
		declareParameter(new SqlParameter("DiscountAmount", Types.DECIMAL));
		declareParameter(new SqlParameter("TaxAmount", Types.DECIMAL));
		declareParameter(new SqlParameter("ShippingAmount", Types.DECIMAL));
		declareParameter(new SqlParameter("ShippingMethod", Types.VARCHAR));
		declareParameter(new SqlParameter("PaymentMethod", Types.VARCHAR));
		//declareParameter(new SqlParameter("UserIp", Types.VARCHAR));
		declareParameter(new SqlParameter("IncreasinglyVersion", Types.VARCHAR));
		declareParameter(new SqlParameter("UserAgent", Types.VARCHAR));
		declareParameter(new SqlParameter("VisitorId", Types.VARCHAR));	
		declareParameter(new SqlParameter("CurrencyCode", Types.VARCHAR));
		declareParameter(new SqlOutParameter("result", Types.INTEGER));
		compile();		
	}
	public static SaveOrderData getInstance()
	{
		if (instance == null)
		{
			instance = new SaveOrderData();
		}
		return instance;
	}


	@Override
	public Boolean runService(Map<String, Object> input) throws Exception {
		
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String clientOrderId = (String) input.get(ORDER_ID);
		
		
		String orderStatus = "complete";
		if(input.get(ORDER_STATUS) != null && !input.get(ORDER_STATUS).toString().isEmpty())
		{
			orderStatus= ((String)input.get(ORDER_STATUS));
		}
		else
		{
			orderStatus=null;
		}
		
		Double orderAmount = null;
		if(input.get(ORDER_AMOUNT) != null && !input.get(ORDER_AMOUNT).toString().isEmpty())
		{   
			orderAmount = Double.parseDouble((String)input.get(ORDER_AMOUNT));
		}
		
		
		String couponCode = null;
		if(input.get(COUPON_CODE) != null && !input.get(COUPON_CODE).toString().isEmpty())
		{
			couponCode = (String)input.get(COUPON_CODE);		
		}
		
		Double discountAmount = null;
		if(input.get(DISCOUNT_AMOUNT) != null && !input.get(DISCOUNT_AMOUNT).toString().isEmpty())
		{   
			discountAmount = Double.parseDouble((String)input.get(DISCOUNT_AMOUNT));
		}
		
		Double taxAmount = null;
		if(input.get(TAX_AMOUNT) != null && !input.get(TAX_AMOUNT).toString().isEmpty())
		{   
			taxAmount = Double.parseDouble((String)input.get(TAX_AMOUNT));
		}
		
		Double shippingAmount = null;
		if(input.get(SHIPPING_AMOUNT) != null && !input.get(SHIPPING_AMOUNT).toString().isEmpty())
		{   
			shippingAmount = Double.parseDouble((String)input.get(SHIPPING_AMOUNT));
		}
		
		String shippingMethod = null;
		if(input.get(SHIPPING_METHOD) != null && !input.get(SHIPPING_METHOD).toString().isEmpty())
		{
			shippingMethod = ((String)input.get(SHIPPING_METHOD));	
		}
		
		String paymentMethod = null;
		if(input.get(PAYMENT_METHOD) != null && !input.get(PAYMENT_METHOD).toString().isEmpty())
		{
			paymentMethod = ((String)input.get(PAYMENT_METHOD));	
		}
		
		/*String userIp = null;
		if(input.get(USER_IP) != null && !input.get(USER_IP).toString().isEmpty())
		{
			userIp = ((String)input.get(USER_IP));	
		}
		*/
		String increasinglyVersion = null;
		if(input.get(VERSION)!= null && !input.get(VERSION).toString().isEmpty())
		{
			increasinglyVersion = ((String)input.get(VERSION));
		}
		
		String userAgent = null;
		if(input.get(USER_AGENT) != null && !input.get(USER_AGENT).toString().isEmpty())
		{
			userAgent = ((String)input.get(USER_AGENT));	
		}
		
		String visitorId = null;
		if(input.get(VISITOR_ID) != null && !input.get(VISITOR_ID).toString().isEmpty())
		{
			visitorId = ((String)input.get(VISITOR_ID));	
		}
		
		
		Integer platformId = 1;
		
		if(input.get(PLATFORM_ID) != null && !input.get(PLATFORM_ID).toString().isEmpty())
		{
		  platformId = (Integer)input.get(PLATFORM_ID);
		}		
				
		String currencyCode = null;
		if(input.get(CURRENCY_CODE) != null && !input.get(CURRENCY_CODE).toString().isEmpty())
		{
			currencyCode = ((String)input.get(CURRENCY_CODE));	
		}
		
		Map<String, Object> results = execute(clientId,platformId,clientOrderId,orderStatus,orderAmount,couponCode,
				discountAmount,taxAmount,shippingAmount,shippingMethod,paymentMethod,increasinglyVersion,userAgent,visitorId,currencyCode);
		
		if (!(results.get("result") == null))
		{
			return true;
		}
		else
		{
			return false;			
		}	
	}
	
	
	
	
}