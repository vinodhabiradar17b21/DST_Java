package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import jersey.repackaged.com.google.common.base.Joiner;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertMultipleAddToCartTrackingImpl  implements ServiceInterface<Integer>
{
	

	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertMultipleAddToCartTrackingImpl.class.getClass());
		
	private static InsertMultipleAddToCartTrackingImpl instance = null;
	
	public InsertMultipleAddToCartTrackingImpl()
	{
				
	}

	public static InsertMultipleAddToCartTrackingImpl getInstance()
	{
		if (instance == null)
		{
			instance = new InsertMultipleAddToCartTrackingImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String increasinglyVisitorId = (String)input.get(VISITOR_ID);
		String visitorTime = (String) input.get(VISIT_TIME);
		String referralUrl = (String) input.get(REFERRAL_URL);	
		String userAgent = (String) input.get(USER_AGENT);
		//String visitorIp = (String) input.get(USER_IP);
		
		Connection conn = null;
		
		try 
		{
			if(input.get(PRODUCT_IDS) != null)
			{
				List<String> productIds =  (List<String>)input.get(PRODUCT_IDS);
				
				conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
				CallableStatement cStmt = conn.prepareCall("{call Insert_Multiple_Add_To_Cart_Product(?, ?, ?, ?, ?, ?)}");
						
				cStmt.setString(1,Joiner.on(",").join(productIds).toString());
				cStmt.setString(2, increasinglyVisitorId);
				cStmt.setString(3, visitorTime);
				cStmt.setString(4, referralUrl);
				cStmt.setString(5, userAgent);
				//cStmt.setString(6, visitorIp);
				cStmt.setInt(6, clientId);						
				
				cStmt.execute();
			}
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertMultipleAddToCartTrackingImpl" , "Error Occured while inserting multiple bundle add to cart tracking details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertMultipleAddToCartTrackingImpl", " Error Occured while tracking multiple bundle add to cart tracking data for the client id -"+ clientId  + " visitor id -" +increasinglyVisitorId,  ex.getMessage());
			return 0;
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				ErrorLog.saveErrorLogToDB("InsertMultipleAddToCartTrackingImpl", " Error Occured while closing connection",  e.getMessage());
			}
		}
		return 1;
	}

}
