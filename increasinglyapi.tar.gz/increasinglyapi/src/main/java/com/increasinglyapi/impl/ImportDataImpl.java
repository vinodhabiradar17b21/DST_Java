package com.increasinglyapi.impl;

import static com.increasinglyapi.utils.Constants.*;

import java.io.IOException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.core.Cookie;

import jersey.repackaged.com.google.common.base.Joiner;

import org.apache.commons.lang3.StringEscapeUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.glassfish.jersey.internal.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.increasinglyapi.impl.collections.ClientDetailsCache;
import com.increasinglyapi.impl.collections.PlatformListCache;
import com.increasinglyapi.impl.db.BatchUpdateAssociateProductsDataImpl;
import com.increasinglyapi.impl.db.BatchUpdateCategoryDataImpl;
import com.increasinglyapi.impl.db.BatchUpdateProductOptionsImpl;
import com.increasinglyapi.impl.db.BatchUpdateProductOtherImageDataImpl;
import com.increasinglyapi.impl.db.BulkInsertOrderData;
import com.increasinglyapi.impl.db.BulkInsertOrderItemsData;
import com.increasinglyapi.impl.db.BundleOrderConfirmationTrackingImpl;
import com.increasinglyapi.impl.db.BundleOrderTracking;
import com.increasinglyapi.impl.db.DeleteProductData;
import com.increasinglyapi.impl.db.DeleteTemporaryStorageData;
import com.increasinglyapi.impl.db.ErrorLog;
import com.increasinglyapi.impl.db.GetFeedId;
import com.increasinglyapi.impl.db.InsertAddToCartTracking;
import com.increasinglyapi.impl.db.InsertBundleAddToCartTrackingDetails;
import com.increasinglyapi.impl.db.InsertBundleProductClickTracking;
import com.increasinglyapi.impl.db.InsertCategoryViewTracking;
import com.increasinglyapi.impl.db.InsertMultipleAddToCartTrackingImpl;
import com.increasinglyapi.impl.db.InsertOrUpdateProductDetails;
import com.increasinglyapi.impl.db.InsertOrUpdateProductInventoryDetails;
import com.increasinglyapi.impl.db.InsertOrderData;
import com.increasinglyapi.impl.db.InsertPageViewTracking;
import com.increasinglyapi.impl.db.InsertProductOptionDetailsImpl;
import com.increasinglyapi.impl.db.InsertProductViewTracking;
import com.increasinglyapi.impl.db.InsertRemoveFromCartTracking;
import com.increasinglyapi.impl.db.InsertSearchPageTracking;
import com.increasinglyapi.impl.db.RemoveBundleFromCartTracking;
import com.increasinglyapi.impl.db.SaveOrderData;
import com.increasinglyapi.impl.db.SaveOrderItemDetails;
import com.increasinglyapi.impl.db.TrackOrderData;
import com.increasinglyapi.impl.db.UpdateApiEnableStatus;
import com.increasinglyapi.impl.db.UpdateAssociatedProductsDataImpl;
import com.increasinglyapi.impl.db.UpdateCartStatusAfterRemove;
import com.increasinglyapi.impl.db.UpdateCrawledProductData;
import com.increasinglyapi.impl.db.UpdateCustomerLoginDetails;
import com.increasinglyapi.impl.db.UpdateFreeShippingDetails;
import com.increasinglyapi.impl.db.UpdateMassProductPricingDetails;
import com.increasinglyapi.impl.db.UpdateProductCategoryDataImpl;
import com.increasinglyapi.impl.db.UpdateProductClickTracking;
import com.increasinglyapi.impl.db.UpdateProductOtherImagesDataImpl;
import com.increasinglyapi.utils.FormatLoggerMessage;
import com.increasinglyapi.utils.ParseXmlFile;

public class ImportDataImpl
{
	private static final Logger logger = LoggerFactory.getLogger(ImportDataImpl.class.getClass());
	ObjectMapper mapper = new ObjectMapper();
	JsonResponse jsonResponse;
	
	private TrackRequest trackRequest;
	private TrackResponse trackResponse;
	
	public ImportDataImpl()
	{
		this.trackResponse = new TrackResponse();
	}
	
	public List<Cookie> getCookies()
    {
        return trackResponse.getCookies();
    }
	
	public void generateVisitorId(TrackRequest trackRequest) throws Exception
	{	
	  this.trackRequest = trackRequest;
	  
	  if(!this.trackRequest.getIncreasinglyVisitorId().isEmpty())
      {
  		trackResponse.setCookie(INCREASINGLY_VISITOR_ID,this.trackRequest.getIncreasinglyVisitorId());
      }
	  else
	  {
	    processRequestCookies();
	    processResponseCookies();
	  }
			
	}
	
	public void setTrackRequest(TrackRequest trackRequest) {
		this.trackRequest = trackRequest;
	}
	
	public JsonResponse saveImportedData(ImportDataParameters importData)
	{		
		Map<String,Object> trackedEventData = new HashMap<String,Object>();
		EventDataParameters eventDataParams = new EventDataParameters();
		
		try
		{	
			  
				logger.info(LOG_APPLICATION_FLOW + "Input parameter parsing started.");
				
				mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		    	
				trackedEventData = mapper.readValue(Base64.decodeAsString(importData.getEventData()),new TypeReference<Map<String,Object>>(){});
			
				eventDataParams.setEventType((String)trackedEventData.get(EVENT_TYPE));				
				eventDataParams.setPlatform((String)trackedEventData.get(PLATFORM));
				eventDataParams.setApiKey((String)trackedEventData.get(TOKEN));
				eventDataParams.setVersion((String)trackedEventData.get(VERSION));	
				eventDataParams.setEventMethod((String)trackedEventData.get(EVENT_METHOD));	
				eventDataParams.setPlatformId(PlatformListCache.getCache().get(eventDataParams.getPlatform()));				
				ClientDetailsParameters clientDetailsParameters = ClientDetailsCache.getCache().get(eventDataParams.getApiKey());				
				eventDataParams.setClientId(clientDetailsParameters.getClientId());
				
				if(eventDataParams.getEventType().equals(EVENT_TYPE_ORDER) && eventDataParams.getEventMethod().equals(EVENT_METHOD_IMPORT))
				{
			 	   eventDataParams.setOrderData((ArrayList<Map<String,Object>>)trackedEventData.get(EVENT_DATA));
			 	   
			 	   String md5Signature = generateMd5Signature(importData.getEventData(),clientDetailsParameters.getApiSecret());
			 	   
			 	    if(md5Signature.equals(importData.getSignature()))
					{
			 	       processOrderData(eventDataParams,importData);
				    }
					else
					{
						String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveImportedData" , "Signature doesn't match" ,"");
						logger.error(errorMessage);	
					}
				}
				else if (eventDataParams.getEventMethod().equals(EVENT_METHOD_TRACK))
				{
					if(eventDataParams.getEventType().equals(EVENT_TYPE_ORDER))
					{
						logger.info(LOG_INFO + " Raw Order data - " + Base64.decodeAsString(importData.getEventData())); 
						
						Map<String,Object> newOrderData = (Map<String,Object>)trackedEventData.get(EVENT_DATA);
						List<Map<String,Object>> newOrderList = new ArrayList<Map<String,Object>>();
						newOrderList.add(newOrderData);
						eventDataParams.setOrderData(newOrderList);
					}
					else
					{
						eventDataParams.setTrackedData((Map<String,Object>)trackedEventData.get(EVENT_DATA));
					}
			      
			        switch (eventDataParams.getEventType()) 
			        {
			          case EVENT_TYPE_HOME_PAGE_VISIT: processPageViewTracking(eventDataParams,importData);
                         break;
		              case EVENT_TYPE_PRODUCT_PAGE_VISIT: processProductViewTracking(eventDataParams,importData);
		                 break;
		              case EVENT_TYPE_CATEGORY_PAGE_VISIT: processCategoryViewTracking(eventDataParams,importData);
	                     break;
		              case EVENT_TYPE_SEARCH_PAGE: processSearchPageTracking(eventDataParams,importData);
	                     break;
		              case EVENT_TYPE_ADD_TO_CART: processAddToCartTracking(eventDataParams,importData);
		                 break;
		              case EVENT_TYPE_REMOVE_FROM_CART: processRemoveFromCartTracking(eventDataParams,importData);
		                 break;
		             // case EVENT_TYPE_CUSTOMER_LOGIN: updateCustomerLoginDetails(eventDataParams,importData);
		            	// break;
		              case EVENT_TYPE_ORDER: processOrderData(eventDataParams,importData);
	            	     break;
		              case EVENT_TYPE_PRODUCT_ADD_OR_UPDATE: addOrUpdateProductDetails(eventDataParams);
		                 break;
		              case EVENT_TYPE_PRODUCT_DELETE: deleteProduct(eventDataParams);
		                 break;
		              case EVENT_TYPE_VALIDATE_API: validateApiDetails(eventDataParams,importData,clientDetailsParameters.getApiSecret());
		                 break;
		              case EVENT_TYPE_SAVE_API_ENABLE_STATUS: saveApiEnableStatus(eventDataParams,importData,clientDetailsParameters.getApiSecret());
		                 break;		 
		              case EVENT_TYPE_SHIPPING_DETAILS_IMPORT: saveClientShippingDetails(eventDataParams);
		                 break;
		              case EVENT_TYPE_BUNDLE_ADD_TO_CART:
		            	  
		            	  if(trackedEventData.get(PAGE_TYPE_ID) != null && !trackedEventData.get(PAGE_TYPE_ID).toString().isEmpty())
		  				  {
		  					eventDataParams.setPageTypeId(Integer.valueOf((String)trackedEventData.get(PAGE_TYPE_ID)));
		  				  }
		  				
		  				  if(trackedEventData.get(PURCHASE_TYPE) != null && !trackedEventData.get(PURCHASE_TYPE).toString().isEmpty())
		  				  {
		  					eventDataParams.setPurchaseType(Integer.valueOf((String)trackedEventData.get(PURCHASE_TYPE)));
		  				  }
		  				  if(trackedEventData.get(IS_LOGGED_IN_USER) != null && !trackedEventData.get(IS_LOGGED_IN_USER).toString().isEmpty())
		  				  {
		  					eventDataParams.setIsLoggedInUser(Integer.valueOf(trackedEventData.get(IS_LOGGED_IN_USER).toString()));
		  				  }		            	  

		            	  processBundleAddToCartTracking(eventDataParams,importData);
		                 break;	
		              case EVENT_TYPE_BUNDLE_REMOVE_FROM_CART:removeBundleFromCartTracking(eventDataParams,importData);
		                 break;
		              case EVENT_TYPE_TRACK_ERROR:trackError(eventDataParams,importData);
		              	 break;
		              case EVENT_TYPE_BUNDLE_ADD_TO_CART_FAILURE:processBundleAddToCartFailureTracking(eventDataParams,importData);
		                 break;
		              case EVENT_TYPE_BUNDLE_PRODUCT_CLICK_TRACKING:
		            	  
		            	  if(trackedEventData.get(PAGE_TYPE_ID) != null && !trackedEventData.get(PAGE_TYPE_ID).toString().isEmpty())
		  				  {
		  					eventDataParams.setPageTypeId(Integer.valueOf((String)trackedEventData.get(PAGE_TYPE_ID)));
		  				  }
		            	  if(trackedEventData.get(IS_LOGGED_IN_USER) != null && !trackedEventData.get(IS_LOGGED_IN_USER).toString().isEmpty())
		  				  {
		  					eventDataParams.setIsLoggedInUser(Integer.valueOf(trackedEventData.get(IS_LOGGED_IN_USER).toString()));
		  				  }
		            	  processBundleProductClickTracking(eventDataParams,importData);
		              	 break;	
		              case EVENT_TYPE_PRODUCT_ATTRIBUTE_UPDATE_TRACKING:UpdateMagentoMassProductPricingDetails(eventDataParams);
		            	  break;
		              case EVENT_TYPE_ADD_TO_CART_MULTIPLE: processMultipleAddToCartTracking(eventDataParams,importData);
		            	  break;
		              
				  }				   
					
				}
			
		}
		catch(JsonParseException jsonParseEx)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveImportedData" , "Error parsing json input arguments" ,"");
			logger.error(errorMessage,jsonParseEx);	
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java saveImportedData()", "Error occured while parsing json input arguments.", jsonParseEx.getMessage());
		}
		catch(JsonMappingException jsonMappingEx)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveImportedData" , "Error parsing json input mapping" ,"");
			logger.error(errorMessage,jsonMappingEx);
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java saveImportedData()", "Error occured while parsing json input mapping.", jsonMappingEx.getMessage());
		}
		catch(IOException ioEx)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveImportedData" , "IO Error parsing json input mapping" ,"");
			logger.error(errorMessage,ioEx);
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java saveImportedData()", "IO Error occured while parsing json input mapping.", ioEx.getMessage());
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveImportedData" , "Error Occured" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java saveImportedData()", "Error occured while saving imported data.", ex.getMessage());
		}
		
		return jsonResponse;
	}
	
	/**
	 * Process input request cookies
	 */
	public void processRequestCookies()
	{
		try
		{
			// Get visitor id (Guid) from cookie for the existing user
	        String cookieVisitorId = "";
	        
	        if(trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID) != null)
	        {
	        	cookieVisitorId = trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID).getValue();
	        }
	        
	        if (cookieVisitorId != null && cookieVisitorId.length() > 0)
	        {
	            trackRequest.setVisitorId(UUID.fromString(cookieVisitorId)); 
	            trackRequest.setHasVisitorId(true);
	        }  
		}
		catch(Exception ex)
		{
		  String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processRequestCookies" , "processRequestCookies" , "");
		  logger.error(errorMessage,ex);    
		}

	}
	
	public void processResponseCookies()
	{
		try
        {            
            Cookie httpCookie = null;

            // Set Visitor Id (GUID) for new user
            if (trackRequest.getIsNewUser())
            {
                httpCookie = trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID);
                if (httpCookie == null || httpCookie.getValue().isEmpty())
                {   
                	trackResponse.setCookie(INCREASINGLY_VISITOR_ID,trackRequest.getVisitorId().toString());                  
                }
            }
        }
        catch (Exception ex)
        {
       	  String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processResponseCookies" , "processResponseCookies" , "");
		  logger.error(errorMessage,ex);           
        }
	}	
	
	public void processOrderData(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		int clientId = eventDataParams.getClientId();
		BulkInsertOrderItemsData insertOrderItemsData = new BulkInsertOrderItemsData();
		BundleOrderTracking bundleOrderTracking = new BundleOrderTracking();
		
		Map<String, List<Map<String,Object>>> bundleList = new HashMap<String, List<Map<String,Object>>>();
		Map<String,Object> input = new HashMap<String,Object>();
		
		Boolean isJsBundleTracking = false;
		String clientOrderId = "";
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Order data processing has started.");
			List<Map<String,Object>> orderList = eventDataParams.getOrderData();
			Boolean hasOrderItems = false;
			for(Map<String,Object> order : orderList)
			{
				String orderId = "";
				for(Map.Entry<String, Object> orderData : order.entrySet())
				{				
					 if(orderData.getKey().equals(ORDER_ID))
					 {
						orderId = (String)orderData.getValue();
						clientOrderId = orderId;
					 }				 
					 if(orderId != "" && orderData.getKey().equals(ITEMS))
					 {					
						 insertOrderItemsData.addItemList(orderId, (ArrayList<Map<String,Object>>)orderData.getValue());
						 hasOrderItems = true;
					 }
					 
					 if(orderId != "" && orderData.getKey().equals(BUNDLES))
					 {	
						 ArrayList<Map<String,Object>> bundleData = (ArrayList<Map<String,Object>>)orderData.getValue();
						 if(bundleData.size() > 0)
						 {
							 bundleList.put(orderId,(ArrayList<Map<String,Object>>)orderData.getValue());	
						 }
					 }
					 else if(orderId != "" && orderData.getKey().equals(BUNDLE_DATA))
					 {
						 Map<String,Object> bundleDataItemList = new HashMap<String,Object>();
						 bundleDataItemList = (Map<String,Object>)orderData.getValue();
						 
						 for (Map.Entry<String,Object> entry : bundleDataItemList.entrySet())
						 {
							 bundleList.put(orderId,(List<Map<String,Object>>)entry.getValue());
						 }
						 
						 isJsBundleTracking = true;
					 }
				}
			}
			
			if(bundleList.size() > 0)
			{
				if(eventDataParams.getEventMethod().equals(EVENT_METHOD_TRACK))
				{
				  Map<String,Object> bundleDetailsMap = new HashMap<String,Object>();
				  bundleDetailsMap.put(BUNDLES, bundleList);
				  bundleOrderTracking.runService(bundleDetailsMap);		
				}
				else if(isJsBundleTracking)
				{
				  Map<String,Object> bundleDetailsMap = new HashMap<String,Object>();
				  bundleDetailsMap.put(BUNDLES, bundleList);
				  bundleOrderTracking.runService(bundleDetailsMap);		
				}
				
				for (Map.Entry<String, List<Map<String,Object>>> entry : bundleList.entrySet())
				{	
					String increasinglyVisitorId = importData.getVid();
					List<Map<String,Object>> bundleIds =  entry.getValue();
					
					List<Integer> bundleIdList = new ArrayList<Integer>();
					
					for (Map<String,Object> bundleDetails :bundleIds)
					{
						Integer bundleId = Integer.parseInt(bundleDetails.get(ID).toString());	
						bundleIdList.add(bundleId);							
					}
					
					Map<String,Object> bundleListMap = new HashMap<String,Object>();
					bundleListMap.put(CLIENT_ID, clientId);
					bundleListMap.put(VISITOR_ID, increasinglyVisitorId);
					bundleListMap.put(BUNDLE_ID_LIST,Joiner.on(",").join(bundleIdList).toString());
					
					UpdateProductClickTracking updateProductClickTracking = UpdateProductClickTracking.getInstance();
					updateProductClickTracking.runService(bundleListMap);
				}
			}
			else
			{
				if(eventDataParams.getEventMethod().equals(EVENT_METHOD_TRACK))
				{
					Map<String,Object> bundleTrackingInput = new HashMap<String,Object>();
					bundleTrackingInput.put(CLIENT_ID, clientId);
		     		bundleTrackingInput.put(ORDER_ID, clientOrderId);	     		
		     		bundleTrackingInput.put(INCREASINGLY_VISITOR_ID, importData.getVid());
		     		 
					BundleOrderConfirmationTrackingImpl bundleOrderConfirmationTrackingImpl = BundleOrderConfirmationTrackingImpl.getInstance();
		     		Integer isBundleOrderTrackingSuccessful = bundleOrderConfirmationTrackingImpl.runService(bundleTrackingInput);
		     		
		     		if(isBundleOrderTrackingSuccessful == 1)
		     		{
		     		  logger.info(LOG_INFO + "Bundle order tracking is completed successfully for client order id - " + clientOrderId + " client id - " + clientId + " Increasingly Visitor Id - "+ importData.getVid());
		     		}
		     		else
		     		{
		     		   String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processOrderConfirmation" , "FailedToTrackBundleOrder" , "");
		     		   logger.error(errorMessage + "Bundle order tracking failed for the client order id - " + clientOrderId + " client id - " + clientId + " Increasingly Visitor Id - "+ importData.getVid());
		     		}
				}
			}
			
			input.put(CLIENT_ID, eventDataParams.getClientId());
			input.put(PLATFORM_ID, eventDataParams.getPlatformId());
			input.put(USER_AGENT, importData.getUserAgent());
			
			if (eventDataParams.getEventMethod().equals(EVENT_METHOD_TRACK))
			{
				input.put(ORDER_DATA_IS_BULK_PROCESSING, 0);
				input.put(ORDER_ID, clientOrderId);
				input.put(VISITOR_ID, importData.getVid());
				
				for(Map<String,Object> order : orderList)
				{
					if(order != null)
					{
					  input.putAll(order);
					  break;
					}
				}
				
				processMagentoTrackedOrderData(input);
				
			}
			else
			{
			    input.put(ORDER_DATA_IS_BULK_PROCESSING, 1);
				logger.info(LOG_APPLICATION_FLOW + "Order item data processing has started.");
				
				// Insert order item data into data base 
				Boolean hasItemsSaved = false;
				if(hasOrderItems)
				{
				  hasItemsSaved = insertOrderItemsData.runService(input);
				}
				
				logger.info(LOG_APPLICATION_FLOW + "Order item data processing completed.");
				
				// If order item data insertion is successful then insert order data details into data base
				if(hasItemsSaved)
				{
					input.put(VERSION, eventDataParams.getVersion());
					input.put(ORDER_LIST, orderList);
					input.put(VISITOR_ID, importData.getVid());
					logger.info(LOG_APPLICATION_FLOW + " Visitor Id before Bulk Insert - "+ importData.getVid());
					
					BulkInsertOrderData bulkInsertOrderData = new BulkInsertOrderData();
					
					Boolean hasOrderDetailsSaved = false;
					if(orderList.size() > 0)
					{
					  hasOrderDetailsSaved = bulkInsertOrderData.runService(input);
					}
					
					if(hasOrderDetailsSaved)
					{	
						input.remove(ORDER_LIST);
						Integer hasOrderDataSaved = 0;
						
						InsertOrderData insertOrderData = InsertOrderData.getInstance();
						hasOrderDataSaved = insertOrderData.runService(input);
						
						if(hasOrderDataSaved == 1)
						{
							logger.info(LOG_APPLICATION_FLOW + "Order data processing completed successfully.");						
							
						}
						else
						{
							logger.info(LOG_APPLICATION_FLOW + "Order data processing failed while processing database side.");
							
							try 
							{
								DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
								deleteTemporaryStorageData.deleteTemporaryOrderDetails(input);
								
							} 
							catch (Exception e) 
							{				
								e.printStackTrace();
							}
						}		
						
						
					}
					
				}	
			}
			
		
		}
		catch(Exception ex)
		{
			ErrorLog.saveErrorLogToDB("processOrderData", "Client Id - " + clientId  +" Error Occured while updating order data.",  ex.getMessage());
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processOrderData" , "Error Occured while processing order data" ,"");
			logger.error(errorMessage,ex);

			try 
			{
				DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
				deleteTemporaryStorageData.deleteTemporaryOrderDetails(input);
			} 
			catch (Exception e) 
			{				
				e.printStackTrace();
			}
		}	
		
		
	}
    
	public String generateMd5Signature(String signitureContent,String apiSecret) 
	{
		 StringBuffer sb = new StringBuffer();
		 signitureContent = signitureContent + apiSecret;
		
		 try
		 {
			 MessageDigest md = MessageDigest.getInstance(ALGORITHM);
			 md.update(signitureContent.getBytes()); 
	        
		    byte byteData[] = md.digest();

	       //convert the byte to hex format method 1	        
	       for (int i = 0; i < byteData.length; i++) 
	       {
	         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	       }
		 }
		 catch(Exception ex)
		 {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "generateMd5Signature" , "Error Occured while generating Md5 signature." ,"");
			logger.error(errorMessage,ex);
		 }
       
       return sb.toString();
	}

	public void processPageViewTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Page view tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(CLIENT_ID, eventDataParams.getClientId());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());
		//input.put(USER_IP, importData.getUserIpAddress());
		input.put(USER_AGENT, importData.getUserAgent());
		
		InsertPageViewTracking insertPageViewTracking = new InsertPageViewTracking();
		insertPageViewTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Page view tracking has completed.");
		
	}
	
	public void processProductViewTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Product view tracking has started.");
			Map<String,Object> input = new HashMap<String,Object>();
			
			int clientId = eventDataParams.getClientId();
		    input.put(PRODUCT_ID, eventDataParams.getTrackedData().get(PRODUCT_ID));
			input.put(PRODUCT_PRICE, eventDataParams.getTrackedData().get(PRODUCT_PRICE));
			input.put(PRODUCT_SKU, eventDataParams.getTrackedData().get(PRODUCT_SKU));			
			input.put(CLIENT_ID, eventDataParams.getClientId());
			input.put(PLATFORM_ID, eventDataParams.getPlatformId());
			input.put(VISITOR_ID, importData.getVid());
			input.put(VISIT_TIME,importData.getTime());
			input.put(REFERRAL_URL, importData.getUri());
			//input.put(USER_IP, importData.getUserIpAddress());
			input.put(USER_AGENT, importData.getUserAgent());
			
			InsertProductViewTracking insertProductViewTracking = new InsertProductViewTracking();
			insertProductViewTracking.runService(input);
			
			logger.info(LOG_APPLICATION_FLOW + "Product view tracking has completed.");
			
			if(importData.getProductId() != "" && importData.getImageUrl() != "")
			{
				Map<String,Object> inputProductData = new HashMap<String,Object>();
				
				inputProductData.put(PRODUCT_ID, importData.getProductId());
				inputProductData.put(IMAGE_URL, importData.getImageUrl());
				inputProductData.put(DESCRIPTION, StringEscapeUtils.unescapeHtml4(importData.getDescription()));
				inputProductData.put(CLIENT_ID, clientId);				
				
				inputProductData.put(PRODUCT_URL, importData.getUri());
				inputProductData.put(PRODUCT_NAME, importData.getProductName());
				inputProductData.put(PRODUCT_PRICE, importData.getProductPrice());
				inputProductData.put(SPECIAL_PRICE, importData.getProductSpecialPrice());
				inputProductData.put(AVAILABILITY, importData.getAvailability());
				
				UpdateCrawledProductData updateCrawledProductData = UpdateCrawledProductData.getInstance();
				updateCrawledProductData.runService(inputProductData);				
				
			}
			else if(eventDataParams.getTrackedData().get(PRODUCT_ID) != null && eventDataParams.getTrackedData().get(PRODUCT_ID).toString().trim() != "" && eventDataParams.getTrackedData().get(PRODUCT_ID).toString().trim().startsWith("9000")
					&& (clientId==15 && eventDataParams.getTrackedData().get(PRODUCT_NAME) != null && !eventDataParams.getTrackedData().get(PRODUCT_NAME).toString().trim().isEmpty()))
			{
				Map<String,Object> inputProductData = new HashMap<String,Object>();
				
				inputProductData.put(PRODUCT_ID, eventDataParams.getTrackedData().get(PRODUCT_ID).toString().trim());				
				inputProductData.put(CLIENT_ID, clientId);	
				inputProductData.put(PRODUCT_NAME, StringEscapeUtils.unescapeHtml4(eventDataParams.getTrackedData().get(PRODUCT_NAME).toString().trim()));
								
				UpdateCrawledProductData updateCrawledProductData = UpdateCrawledProductData.getInstance();
				updateCrawledProductData.runService(inputProductData);				
			}
			
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processProductViewTracking" , "processProductViewTracking" , "");
			logger.error(errorMessage,ex);  
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java processProductViewTracking()", "Error occured while processing product view tracking", ex.getMessage());
		}
		
		
		
	}
	
	public void processCategoryViewTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Category view tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
		
	    input.put(CATEGORY_ID, eventDataParams.getTrackedData().get(CATEGORY_ID));
		input.put(CLIENT_ID, eventDataParams.getClientId());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());
		//input.put(USER_IP, importData.getUserIpAddress());
		input.put(USER_AGENT, importData.getUserAgent());
		
		InsertCategoryViewTracking insertCategoryViewTracking = new InsertCategoryViewTracking();
		insertCategoryViewTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Category view tracking has completed.");
		
	}
	
	public void processSearchPageTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Search page view tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
			   
	    input.put(SEARCH_QUERY, eventDataParams.getTrackedData().get(SEARCH_QUERY));	
		input.put(SEARCH_RESULT_COUNT, eventDataParams.getTrackedData().get(SEARCH_RESULT_COUNT));			
		input.put(CLIENT_ID, eventDataParams.getClientId());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());
		//input.put(USER_IP, importData.getUserIpAddress());
		input.put(USER_AGENT, importData.getUserAgent());
		
		InsertSearchPageTracking insertSearchPageTracking = new InsertSearchPageTracking();
		insertSearchPageTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Search page view tracking has completed.");
	}
    
	public void processAddToCartTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Add to cart tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
			
	    input.put(PRODUCT_ID, eventDataParams.getTrackedData().get(PRODUCT_ID));
	    input.put(PRODUCT_NAME, eventDataParams.getTrackedData().get(PRODUCT_NAME));
	    input.put(PRODUCT_URL, eventDataParams.getTrackedData().get(PRODUCT_URL));
	    input.put(PRODUCT_SKU, eventDataParams.getTrackedData().get(PRODUCT_SKU));	
	    input.put(PRODUCT_TYPE, eventDataParams.getTrackedData().get(PRODUCT_TYPE));
		input.put(PRODUCT_PRICE, eventDataParams.getTrackedData().get(PRODUCT_PRICE));
		input.put(QUANTITY, eventDataParams.getTrackedData().get(QUANTITY));		
		input.put(OPTION_PRODUCT_ID, eventDataParams.getTrackedData().get(OPTION_PRODUCT_ID));
	    input.put(OPTION_PRODUCT_NAME, eventDataParams.getTrackedData().get(OPTION_PRODUCT_NAME));
	    input.put(OPTION_PRODUCT_SKU, eventDataParams.getTrackedData().get(OPTION_PRODUCT_SKU));	
		input.put(OPTION_PRODUCT_PRICE, eventDataParams.getTrackedData().get(OPTION_PRODUCT_PRICE));
		input.put(IS_LOGGED_IN, eventDataParams.getTrackedData().get(IS_LOGGED_IN));
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());		
		input.put(USER_AGENT, importData.getUserAgent());
		//input.put(USER_IP, importData.getUserIpAddress());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(CLIENT_ID, eventDataParams.getClientId());		
		
		InsertAddToCartTracking insertAddToCartTracking = new InsertAddToCartTracking();
		insertAddToCartTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Add to cart tracking has completed.");
		
	}

	public void processRemoveFromCartTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Remove from cart tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
			
	    input.put(PRODUCT_ID, eventDataParams.getTrackedData().get(PRODUCT_ID));
	    
	    if(eventDataParams.getTrackedData().get(IS_LOGGED_IN) != null)
	    {
	      input.put(IS_LOGGED_IN, eventDataParams.getTrackedData().get(IS_LOGGED_IN));
	    }
	    else
	    {
	      input.put(IS_LOGGED_IN, false);
	    }
	    
	  	input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());		
		input.put(USER_AGENT, importData.getUserAgent());
		input.put(USER_IP, importData.getUserIpAddress());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(CLIENT_ID, eventDataParams.getClientId());		
		
		UpdateCartStatusAfterRemove updateCartStatusAfterRemove = UpdateCartStatusAfterRemove.getInstance(); 
		updateCartStatusAfterRemove.runService(input);
		
		InsertRemoveFromCartTracking insertRemoveFromCartTracking = new InsertRemoveFromCartTracking();
		insertRemoveFromCartTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Remove from cart tracking has completed.");
		
	}
	
	public void processBundleAddToCartTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Add to budle cart tracking has started.");
			
		Integer bundleId = 0;
		String productId = "";
		Integer pageTypeId = 0;
		Integer isAbandonedCartBundle = 0;
		
		if(eventDataParams.getTrackedData().get(BUNDLE_DATA)!= null)
		{
		  LinkedHashMap<String,Object> bundleData = (LinkedHashMap<String,Object>)eventDataParams.getTrackedData().get(BUNDLE_DATA);
		  bundleId = (Integer)bundleData.get(ID);
		  
		  if(bundleData.get(PRODUCT_ID) != null)
		  {
		    productId = (String)bundleData.get(PRODUCT_ID);
		  }
		  
		  pageTypeId = eventDataParams.getPageTypeId();
		  
		  if(bundleData.get(IS_ABANDONED_CART_BUNDLE) != null && !bundleData.get(IS_ABANDONED_CART_BUNDLE).toString().isEmpty())
		  {
			  isAbandonedCartBundle = Integer.valueOf(bundleData.get(IS_ABANDONED_CART_BUNDLE).toString());
		  }
		}
		else
		{
			bundleId = (Integer) eventDataParams.getTrackedData().get(BUNDLE_ID);
			
			if(eventDataParams.getTrackedData().get(PRODUCT_ID) != null)
			{
				productId = (String)eventDataParams.getTrackedData().get(PRODUCT_ID);
			}
			
			if(eventDataParams.getTrackedData().get(PAGE_TYPE_ID) != null)
			{
				pageTypeId = Integer.valueOf(eventDataParams.getTrackedData().get(PAGE_TYPE_ID).toString());
			}
		}
		
				
		/*
		List<String> productIds = new ArrayList<String>();
		if(bundleData.get(PRODUCT_IDS) != null)
		{
			productIds = (ArrayList<String>)bundleData.get(PRODUCT_IDS);
		}*/
		
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());		
		input.put(USER_AGENT, importData.getUserAgent());
		input.put(USER_IP, importData.getUserIpAddress());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(CLIENT_ID, eventDataParams.getClientId());
		input.put(PAGE_TYPE_ID,pageTypeId);
		input.put(PURCHASE_TYPE,eventDataParams.getPurchaseType());
		input.put(PRODUCT_ID,productId);
		input.put(IS_LOGGED_IN_USER,eventDataParams.getIsLoggedInUser());
		input.put(IS_ABANDONED_CART_BUNDLE,isAbandonedCartBundle);
		
		/*
		for(String productId:productIds)
		{						
		    input.put(PRODUCT_ID, productId);
		    
		    logger.info(LOG_APPLICATION_FLOW + "Add to budle cart product tracking has started.");
		    InsertAddToCartTracking insertAddToCartTracking = new InsertAddToCartTracking();
			insertAddToCartTracking.runService(input);
			logger.info(LOG_APPLICATION_FLOW + "Add to budle cart product tracking has completed.");
		}*/
					
		input.put(BUNDLE_ID, bundleId);
					
		InsertBundleAddToCartTrackingDetails insertBundleAddToCartTrackingDetails = InsertBundleAddToCartTrackingDetails.getInstance();
		insertBundleAddToCartTrackingDetails.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Add to budle cart tracking has completed.");
	   
	}

	public void removeBundleFromCartTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Remove budle from cart tracking has started.");
			
		Integer bundleId = 0;
		
		if(eventDataParams.getTrackedData().get(BUNDLE_DATA)!= null)
		{
		  LinkedHashMap<String,Object> bundleData = (LinkedHashMap<String,Object>)eventDataParams.getTrackedData().get(BUNDLE_DATA);
		  bundleId = (Integer)bundleData.get(BUNDLE_ID);
		}
		else
		{
		  bundleId = Integer.parseInt(eventDataParams.getTrackedData().get(BUNDLE_ID).toString());
		}
		
		/*
		List<String> productIds = new ArrayList<String>();
		if(bundleData.get(PRODUCT_IDS) != null)
		{
			productIds = (ArrayList<String>)bundleData.get(PRODUCT_IDS);
		}*/
		
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(VISITOR_ID, importData.getVid());
		input.put(VISIT_TIME,importData.getTime());
		input.put(REFERRAL_URL, importData.getUri());		
		input.put(USER_AGENT, importData.getUserAgent());
		//input.put(USER_IP, importData.getUserIpAddress());
		input.put(PLATFORM_ID, eventDataParams.getPlatformId());
		input.put(CLIENT_ID, eventDataParams.getClientId());	
		
		/*
		for(String productId:productIds)
		{						
		    input.put(PRODUCT_ID, productId);
		    
		    logger.info(LOG_APPLICATION_FLOW + "Remove bundle product from cart tracking has started.");
		  
			UpdateCartStatusAfterRemove updateCartStatusAfterRemove = UpdateCartStatusAfterRemove.getInstance(); 
			updateCartStatusAfterRemove.runService(input);
			
			InsertRemoveFromCartTracking insertRemoveFromCartTracking = new InsertRemoveFromCartTracking();
			insertRemoveFromCartTracking.runService(input);
			
			logger.info(LOG_APPLICATION_FLOW + "Completed removing bundle product from cart.");
		}*/
					
		input.put(BUNDLE_ID, bundleId);
				
		RemoveBundleFromCartTracking removeObjBundleFromCartTracking = RemoveBundleFromCartTracking.getInstance();
		removeObjBundleFromCartTracking.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Remove bundle from cart tracking has completed.");
	   
	}
	
	public void processBundleProductClickTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		try
		{
			
			
			logger.info(LOG_APPLICATION_FLOW + "Bundle product click tracking has started.");
			Map<String,Object> input = new HashMap<String,Object>();			
			
		    input.put(PRODUCT_ID, eventDataParams.getTrackedData().get(PRODUCT_ID));
			input.put(CORE_PRODUCT_ID, eventDataParams.getTrackedData().get(CORE_PRODUCT_ID));
									
			input.put(PAGE_TYPE_ID, eventDataParams.getPageTypeId());			
			input.put(CLIENT_ID, eventDataParams.getClientId());			
			input.put(VISITOR_ID, importData.getVid());			
			input.put(REFERRAL_URL, importData.getUri());
			input.put(USER_IP, importData.getUserIpAddress());
			input.put(USER_AGENT, importData.getUserAgent());
			input.put(IS_LOGGED_IN_USER, eventDataParams.getIsLoggedInUser());
			
			InsertBundleProductClickTracking insertBundleProductClickTracking = InsertBundleProductClickTracking.getInstance();
			insertBundleProductClickTracking.runService(input);
			
			logger.info(LOG_APPLICATION_FLOW + "Bundle product click tracking has completed.");
						
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processBundleProductClickTracking" , "processBundleProductClickTracking" , "");
			logger.error(errorMessage,ex);     
		}
		
	}

	
	public void updateCustomerLoginDetails(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Update customer login tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
			
	    input.put(CUSTOMER_EMAIL, eventDataParams.getTrackedData().get(CUSTOMER_EMAIL));
	    input.put(CUSTOMER_NAME, eventDataParams.getTrackedData().get(CUSTOMER_NAME));
	    input.put(CUSTOMER_FIRST_NAME, eventDataParams.getTrackedData().get(CUSTOMER_FIRST_NAME));
	    input.put(CUSTOMER_LAST_NAME, eventDataParams.getTrackedData().get(CUSTOMER_LAST_NAME));
	  	input.put(VISITOR_ID, importData.getVid());
		input.put(CLIENT_ID, eventDataParams.getClientId());
		
		UpdateCustomerLoginDetails updateCustomerLoginDetails = UpdateCustomerLoginDetails.getInstance();
		updateCustomerLoginDetails.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Update customer login tracking has completed.");
	}
	
	public void addOrUpdateProductDetails(EventDataParameters eventDataParams)
	{
		
		int feedId = 0;
		String productId = "";
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Product data  add or update has started.");
			feedId = getFeedId(eventDataParams.getClientId());
			productId = (String)eventDataParams.getTrackedData().get(PRODUCT_ID);
			Map<String,Object> input = new HashMap<String,Object>();
				
			input.put(FEED_ID,feedId);
		    input.put(PRODUCT_ID, productId);
		    input.put(PRODUCT_NAME, eventDataParams.getTrackedData().get(PRODUCT_NAME));
		    
		    if(eventDataParams.getTrackedData().get(PRODUCT_SKU) != null)
		    {
		    	input.put(PRODUCT_SKU, eventDataParams.getTrackedData().get(PRODUCT_SKU));
		    }
		    
		    if(eventDataParams.getTrackedData().get(PRODUCT_PRICE) != null)
		    {
		    	input.put(PRODUCT_PRICE, eventDataParams.getTrackedData().get(PRODUCT_PRICE));
		    }
		  	
		    if(eventDataParams.getTrackedData().get(SPECIAL_PRICE) != null)
		    {
		    	input.put(SPECIAL_PRICE, eventDataParams.getTrackedData().get(SPECIAL_PRICE));
		    }
		    
		    if(eventDataParams.getTrackedData().get(IMAGE_URL) != null)
		    {
		    	input.put(IMAGE_URL, eventDataParams.getTrackedData().get(IMAGE_URL));
		    }
		    
		    input.put(PRODUCT_URL, eventDataParams.getTrackedData().get(PRODUCT_URL));
		    
		    if(eventDataParams.getTrackedData().get(DESCRIPTION) != null)
		    {
		    	input.put(DESCRIPTION, eventDataParams.getTrackedData().get(DESCRIPTION));
		    }
		    
		    if(eventDataParams.getTrackedData().get(SHORT_DESCRIPTION) != null)
		    {
		    	input.put(SHORT_DESCRIPTION, eventDataParams.getTrackedData().get(SHORT_DESCRIPTION));
		    }
			
		    if(eventDataParams.getTrackedData().get(CLIENT_PRODUCT_STATUS) != null)
		    {
		    	input.put(CLIENT_PRODUCT_STATUS, eventDataParams.getTrackedData().get(CLIENT_PRODUCT_STATUS));
		    }
		    
		    String productType = "";
		    if(eventDataParams.getTrackedData().get(PRODUCT_TYPE) != null)
		    {
		    	productType = (String)eventDataParams.getTrackedData().get(PRODUCT_TYPE);
		    	input.put(PRODUCT_TYPE, productType);
		    }
		    
		    if(eventDataParams.getTrackedData().get(MANUFACTURER) != null)
		    {
		      input.put(MANUFACTURER, eventDataParams.getTrackedData().get(MANUFACTURER));
		    }
		    
		    if(eventDataParams.getTrackedData().get(COLOR) != null)
		    {
		      input.put(COLOR, eventDataParams.getTrackedData().get(COLOR));
		    }
		    
		    if(eventDataParams.getTrackedData().get(SIZE) != null)
		    {
		      input.put(SIZE, eventDataParams.getTrackedData().get(SIZE));
		    }
		    
		    if(eventDataParams.getTrackedData().get(WEIGHT) != null)
		    {
		      input.put(WEIGHT, eventDataParams.getTrackedData().get(WEIGHT));
		    }
			    
		    if(eventDataParams.getTrackedData().get(OTHER_IMAGE_LIST) != null)
		    {
		      input.put(OTHER_IMAGE_LIST,eventDataParams.getTrackedData().get(OTHER_IMAGE_LIST));
		    }
		    
		    if(eventDataParams.getTrackedData().get(QUANTITY) != null)
		    {
		    	input.put(QUANTITY, eventDataParams.getTrackedData().get(QUANTITY));
		    }
		    
		    if(eventDataParams.getTrackedData().get(CREATED_DATE) != null)
		    {
		    	input.put(CREATED_DATE, eventDataParams.getTrackedData().get(CREATED_DATE));
		    }
		    
		    if(eventDataParams.getTrackedData().get(UPDATED_DATE) != null)
		    {
		    	input.put(UPDATED_DATE, eventDataParams.getTrackedData().get(UPDATED_DATE));
		    }
		    
		    if(eventDataParams.getTrackedData().get(VISIBILITY) != null)
		    {
		    	input.put(VISIBILITY, eventDataParams.getTrackedData().get(VISIBILITY));
		    }
		    
		    InsertOrUpdateProductDetails insertOrUpdateProductDetails = InsertOrUpdateProductDetails.getInstance();
		    Boolean result = insertOrUpdateProductDetails.runService(input);
		    
		    if(result)
		    {
		    	try
		    	{
		    	if(eventDataParams.getTrackedData().get(PRODUCT_OPTIONS) != null)
	        	{	
        			ArrayList<LinkedHashMap<String,Object>> productOptions = (ArrayList<LinkedHashMap<String,Object>>)eventDataParams.getTrackedData().get(PRODUCT_OPTIONS);
        			
        			if(productOptions != null)
        			{        				
        				List<ProductOption> tempProductOptions = new ArrayList<ProductOption>();
        				
        				for(LinkedHashMap<String,Object> option : productOptions)
				        {	        					
        					ProductOption productOption = new ProductOption();		
        					
        					productOption.setParentProductId(productId);
        					
        					if(option.get(CHILD_PRODUCT_ID) != null)
        					productOption.setChildProductId((String)option.get(CHILD_PRODUCT_ID));	
        					
        					if(option.get(CHILD_PRODUCT_SKU) != null)
	        					productOption.setChildProductSku((String)option.get(CHILD_PRODUCT_SKU));
        					
        					if(option.get(STORE_ID) != null)
	        					productOption.setStoreId((String)option.get(STORE_ID));
        					
        					if(option.get(ATTRIBUTE_CODE) != null)
	        					productOption.setAttributeCode((String)option.get(ATTRIBUTE_CODE));
        					
        					if(option.get(ATTRIBUTE_ID) != null)
	        					productOption.setAttributeId((String)option.get(ATTRIBUTE_ID));
        					
        					if(option.get(ATTRIBUTE_LABEL) != null)
	        					productOption.setAttributeLabel((String)option.get(ATTRIBUTE_LABEL));
        					
        					if(option.get(OPTION_ID) != null)
	        					productOption.setOptionId((String)option.get(OPTION_ID));
        					
        					if(option.get(OPTION_TEXT) != null)
	        					productOption.setOptionText((String)option.get(OPTION_TEXT));
        					
        					if(option.get(OPTION_IMAGE_URL) != null)
	        					productOption.setOptionImageUrl((String)option.get(OPTION_IMAGE_URL));
        					
        					if(option.get(IS_PERCENT) != null)
	        					productOption.setIsPercent(Integer.parseInt((String)option.get(IS_PERCENT)));
        					
        					if(option.get(PRICING_VALUE) != null)
	        					productOption.setPricingValue((String)option.get(PRICING_VALUE));
        					
        					if(option.get(FIELD_TYPE) != null)
	        					productOption.setFieldType((String)option.get(FIELD_TYPE));
        					
        					tempProductOptions.add(productOption);
        					
				        }
        				
        				if(tempProductOptions.size() > 0)
        				{
        					logger.info(LOG_APPLICATION_FLOW + "Started bulk insertion of product option list.");
        					
        					Map<String,Object> productOptionData = new HashMap<String,Object>();
        					productOptionData.put(FEED_ID, feedId);
        					productOptionData.put(PRODUCT_ID, productId);
        					productOptionData.put(PRODUCT_OPTIONS_LIST, tempProductOptions);
        					
        					BatchUpdateProductOptionsImpl batchUpdateProductOptionsDataImpl = BatchUpdateProductOptionsImpl.getInstance();
        					Boolean productOptionsBatchUpdateStatus = batchUpdateProductOptionsDataImpl.runService(productOptionData);
        					productOptionData.remove(PRODUCT_OPTIONS_LIST);
        					logger.info(LOG_APPLICATION_FLOW + "Completed bulk insertion of product options list.");
        					
        					if(productOptionsBatchUpdateStatus)
        					{
        						InsertProductOptionDetailsImpl insertProductOptionsDataImpl = InsertProductOptionDetailsImpl.getInstance();
        						Integer hasProductOptionsSaved = insertProductOptionsDataImpl.runService(productOptionData);
        						
        						if(hasProductOptionsSaved == 1)
        						{
        							logger.info(LOG_APPLICATION_FLOW + "Completed insertion of product option list to main table.");
        						}
        						else
        						{
        							logger.info(LOG_INFO + "Failed  to insert product option list.");
        							DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
        							deleteTemporaryStorageData.deleteTemporaryProductOptionDetails(input);
        						}
        					}
        				}
        				
        			}
	        		
	        	}
		    	}
		    	catch(Exception ex)
				{
					ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while updating product option data.",  ex.getMessage());
				}
		    	
		    	try
		    	{
		    	    if(eventDataParams.getTrackedData().get(CATEGORIES) != null)
			    	{
				    	ArrayList<ProductCategoryMapping> categoryList = new ArrayList<ProductCategoryMapping>();	    
			        	ArrayList<LinkedHashMap<String,Object>> categoryArrayList = (ArrayList<LinkedHashMap<String,Object>>)eventDataParams.getTrackedData().get(CATEGORIES);
			        	        	        	
			        	for(LinkedHashMap<String,Object> category : categoryArrayList)
				        {
			        		ProductCategoryMapping productCategoryMapping = new ProductCategoryMapping();
			        		productCategoryMapping.setCategoryId((String)category.get(ID));
			        		productCategoryMapping.setCategoryName((String)category.get(NAME));
			        		productCategoryMapping.setProductId(productId);
			        		productCategoryMapping.setFeedId(feedId);
			        		categoryList.add(productCategoryMapping);				        	
				        }
			        	
			        	if(categoryList.size() > 0)
			        	{
				        	Map<String,Object> categoryData = new HashMap<String,Object>();
							categoryData.put(FEED_ID, feedId);
							categoryData.put(CATEGORY_LIST, categoryList);					
							BatchUpdateCategoryDataImpl batchUpdateCategoryDataImpl = BatchUpdateCategoryDataImpl.getInstance();
							Boolean hasCategoryBulkUpdateSuccessful = batchUpdateCategoryDataImpl.runService(categoryData);
							categoryData = null;
							
							if(hasCategoryBulkUpdateSuccessful)
							{
								Map<String,Object> inputData = new HashMap<String,Object>();
								inputData.put(FEED_ID, feedId);
								inputData.put(PRODUCT_ID, productId);
								UpdateProductCategoryDataImpl updateProductCategoryDataImpl = UpdateProductCategoryDataImpl.getInstance();
								Integer hasCategoryDetailsUpdated = updateProductCategoryDataImpl.runService(inputData);
								inputData = null;
							}
			        	}
			    	}
		    	}		    
		    	catch(Exception ex)
		    	{
				ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while updating product category data.",  ex.getMessage());
		    	}
		    	
	    	    
		    	ArrayList<AssociatedProducts> associatedProductList = new ArrayList<AssociatedProducts>();
		    	Boolean has_associated_products = false;
		    	Boolean has_related_products = false;
		    	Boolean has_up_sell_products = false;
		    	Boolean has_cross_sell_products = false;
		    	Boolean has_other_images = false;
		    	
		    	try
	    	    {
		    	if(eventDataParams.getTrackedData().get(ASSOCIATED_PRODUCTS) != null)
		    	{
		    	    ArrayList<String> tempAssociatedProductList = (ArrayList<String>)eventDataParams.getTrackedData().get(ASSOCIATED_PRODUCTS);
		    	    associatedProductList.addAll(processAssociatedProducts(tempAssociatedProductList,productId,productType,feedId));
		    	    has_associated_products = true;
		    	}
		    	
		    	if(eventDataParams.getTrackedData().get(RELATED_PRODUCTS) != null)
	        	{
	        	  ArrayList<String> tempRelatedProductList = (ArrayList<String>)eventDataParams.getTrackedData().get(RELATED_PRODUCTS);			        	
	        	  associatedProductList.addAll(processAssociatedProducts(tempRelatedProductList,productId,RELATED_PRODUCTS,feedId));
	        	  has_related_products = true;
	        	}
	        	
	        	if(eventDataParams.getTrackedData().get(UP_SELL_PRODUCTS) != null)
	        	{
	        	  ArrayList<String> tempUpSellProductList = (ArrayList<String>)eventDataParams.getTrackedData().get(UP_SELL_PRODUCTS);
	        	  associatedProductList.addAll(processAssociatedProducts(tempUpSellProductList,productId,UP_SELL_PRODUCTS,feedId));	
	        	  has_up_sell_products = true;
	        	}
	        	
	        	if(eventDataParams.getTrackedData().get(CROSS_SELL_PRODUCTS) != null)
	        	{
	        	  ArrayList<String> tempCrossSellProductList = (ArrayList<String>)eventDataParams.getTrackedData().get(CROSS_SELL_PRODUCTS);			        	
	        	  associatedProductList.addAll(processAssociatedProducts(tempCrossSellProductList,productId,CROSS_SELL_PRODUCTS,feedId));	
	        	  has_cross_sell_products = true;
	        	}
		    	    
	    	    if(associatedProductList.size() > 0)
	    	    {
		    	    Map<String,Object> associatedProductData = new HashMap<String,Object>();
					associatedProductData.put(FEED_ID, feedId);
					associatedProductData.put(ASSOCIATED_PRODUCT_LIST, associatedProductList);
					BatchUpdateAssociateProductsDataImpl batchUpdateAssociateProductsDataImpl = BatchUpdateAssociateProductsDataImpl.getInstance();
					Boolean hasAssociateProductBulkUpdateSuccessful = batchUpdateAssociateProductsDataImpl.runService(associatedProductData);
					associatedProductData = null;
					
					if(hasAssociateProductBulkUpdateSuccessful)
					{
						Map<String,Object> inputData = new HashMap<String,Object>();
						inputData.put(FEED_ID, feedId);
						inputData.put(PRODUCT_ID, productId);
						inputData.put(HAS_ASSOCIATED_PRODUCTS, has_associated_products);
						inputData.put(HAS_RELATED_PRODUCTS, has_related_products);
						inputData.put(HAS_UP_SELL_PRODUCTS, has_up_sell_products);
						inputData.put(HAS_CROSS_SELL_PRODUCTS, has_cross_sell_products);
						
						UpdateAssociatedProductsDataImpl updateAssociatedProductsDataImpl = UpdateAssociatedProductsDataImpl.getInstance();
						updateAssociatedProductsDataImpl.runService(inputData);
						inputData = null;
					}
					
	    	    }
	    	    }
	    	    catch(Exception ex)
		    	{
	    	    	ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while updating associated product data.",  ex.getMessage());
		    	}
	    	    
		    	try
		    	{
	    	    ArrayList<ProductImage> productImageList = new ArrayList<ProductImage>();
	    	    if(eventDataParams.getTrackedData().get(OTHER_IMAGE_LIST) != null)
	        	{
	        		ArrayList<String> tempProductImageList = (ArrayList<String>)eventDataParams.getTrackedData().get(OTHER_IMAGE_LIST);
	        		
	        		for(String tempImageUrl : tempProductImageList)
	        	    {
	         	    	ProductImage productImage = new ProductImage();
	         	    	productImage.setProductId(productId);
	         	    	productImage.setImageUrl(tempImageUrl);			         	    	
	         	    	productImageList.add(productImage);			        	    	
	        	    }
	        	}
	    	    
	    	    if(productImageList.size() > 0)
	    	    {
	    	    	has_other_images = true;
	    	    	Map<String,Object> productImageData = new HashMap<String,Object>();
					productImageData.put(FEED_ID, feedId);
					productImageData.put(OTHER_IMAGE_LIST, productImageList);
					BatchUpdateProductOtherImageDataImpl batchUpdateProductOtherImageDataImpl = BatchUpdateProductOtherImageDataImpl.getInstance();
					Boolean isImageUpdateSuccess = batchUpdateProductOtherImageDataImpl.runService(productImageData);
					productImageData = null;
	    	    }
	    	    
    	    	Map<String,Object> inputOtherImageData = new HashMap<String,Object>();
    	    	inputOtherImageData.put(FEED_ID, feedId);
    	    	inputOtherImageData.put(PRODUCT_ID, productId);
    	    	inputOtherImageData.put(HAS_OTHER_IMAGES, has_other_images);
				
				UpdateProductOtherImagesDataImpl updateProductOtherImagesDataImpl = UpdateProductOtherImagesDataImpl.getInstance();
				updateProductOtherImagesDataImpl.runService(inputOtherImageData);
				inputOtherImageData = null;
		    	}
		    	catch(Exception ex)
		    	{
		    		ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while updating product other image data.",  ex.getMessage());
		    	}
	    	  
		    	try
		    	{
	    	    if(eventDataParams.getTrackedData().get(PRODUCT_INVENTORY_DATA) != null)
	        	{	
        	    	LinkedHashMap<String,Object> productInventoryData = (LinkedHashMap<String,Object>)eventDataParams.getTrackedData().get(PRODUCT_INVENTORY_DATA);
	        		
        	    	productInventoryData.put(FEED_ID, feedId);
	        		if(productInventoryData != null)
	        		{
	        			InsertOrUpdateProductInventoryDetails insertOrUpdateProductInventoryDetails = InsertOrUpdateProductInventoryDetails.getInstance();
	        			insertOrUpdateProductInventoryDetails.runService(productInventoryData);
	        		}
	        		
	        	}
		    	}
		    	catch(Exception ex)
		    	{
		    		ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while updating product inventory data.",  ex.getMessage());
		    	}
	    	    
		      }
		    logger.info(LOG_APPLICATION_FLOW + "Product data  add or update has completed.");
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportDataImpl" , "addOrUpdateProductDetails", "Error occured while inserting product data");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("addOrUpdateProductDetails.java", "Feed Id - " + feedId + " Product Id - " + productId +" Error occured while inserting/updating product data.",  ex.getMessage());
		}
	    	
		
	}
	
	public void deleteProduct(EventDataParameters eventDataParams)
	{
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Product delete has started.");
			int feedId = getFeedId(eventDataParams.getClientId());
			String productId = (String)eventDataParams.getTrackedData().get(PRODUCT_ID);
			Map<String,Object> input = new HashMap<String,Object>();
				
			input.put(FEED_ID,feedId);
		    input.put(PRODUCT_ID, productId);	
		    
		    DeleteProductData deleteProductData = DeleteProductData.getInstance();
		    Integer result = deleteProductData.runService(input);
		    
		    if(result == 0)
		    {
		    	String infoMsg = FormatLoggerMessage.formatError(LOG_INFO , "ImportDataImpl" , "deleteProduct", "product data deletion failed.");
				logger.error(infoMsg);
		    }
		    logger.info(LOG_APPLICATION_FLOW + "Product delete has completed.");
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportDataImpl" , "deleteProduct", "Error occured while deleting product data");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java deleteProduct()", "Error occured while deleting product data.", ex.getMessage());

		}
		
	}
	
	// Magento 2 mass update
	public void UpdateMagentoMassProductPricingDetails(EventDataParameters eventDataParams)
	{
		int feedId = 0;		
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Product attribute data update has started.");
			feedId = getFeedId(eventDataParams.getClientId());
			
			if(eventDataParams.getTrackedData().get(PRODUCT_IDS) != null)
			{
				ArrayList<String> tmpProductIdList = (ArrayList<String>)eventDataParams.getTrackedData().get(PRODUCT_IDS);
				
				String productIdList = Joiner.on(",").join(tmpProductIdList).toString();
				
				Map<String,Object> input = new HashMap<String,Object>();
				input.put(FEED_ID,feedId);
			    input.put(PRODUCT_IDS, productIdList);			  
			    
			    if(eventDataParams.getTrackedData().get(ATTRIBUTES_DATA) != null)
			    {
			    	Map<String,Object> attributeData = (Map<String,Object>)eventDataParams.getTrackedData().get(ATTRIBUTES_DATA);
			    	
			    	if(attributeData.get(PRICE) != null)
			    	{
			    		input.put(PRICE, attributeData.get(PRICE));
			    	}
			    	
			    	if(attributeData.get(SPECIAL_PRICE) != null)
					{
					    input.put(SPECIAL_PRICE, attributeData.get(SPECIAL_PRICE));
					}
									    
					if(attributeData.get(CLIENT_PRODUCT_STATUS) != null)
					{
					    input.put(CLIENT_PRODUCT_STATUS, attributeData.get(CLIENT_PRODUCT_STATUS));
					}
					
					UpdateMassProductPricingDetails updateMassProductPricingDetails = UpdateMassProductPricingDetails.getInstance();
					updateMassProductPricingDetails.runService(input);
			    }
			}
			else
			{
				String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportDataImpl" , "UpdateMagentoMassProductPricingDetails", "Missing product attribute data - Magento 2.0 & Feed Id - " + feedId);
				logger.error(errorMessage);
				ErrorLog.saveErrorLogToDB("ImportDataImpl.java UpdateMagentoMassProductPricingDetails()", "Error occured while updating product attribute data for the feed id -","");
			}
		    
		  
		    logger.info(LOG_APPLICATION_FLOW + "Product attribute data update has completed.");
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ImportDataImpl" , "UpdateMagentoMassProductPricingDetails", "Error occured while updating product attribute data for the feed id -" + feedId);
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java UpdateMagentoMassProductPricingDetails()", "Error occured while updating product attribute data for the feed id -" + feedId,  ex.getMessage());
		}
	    	
		
	}
	
	public void validateApiDetails(EventDataParameters eventDataParams,ImportDataParameters importData,String apiSecret)
	{
		String md5Signature = generateMd5Signature(importData.getEventData(),apiSecret);
	 	   
	 	if(md5Signature.equals(importData.getSignature()))
	 	{				
	 		jsonResponse = new JsonResponse(HttpStatus.OK_200, "success", "{\"isValidUser\":\"true\"}", " ");
	 	  
		}
		else
		{
		   jsonResponse = new JsonResponse(HttpStatus.BAD_REQUEST_400, "fail", "{\"isValidUser\":\"false\"}", " ");
		   String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "validateApiDetails" , "Signature doesn't match" ,"");
		   logger.error(errorMessage);	
			ErrorLog.saveErrorLogToDB("ImportDataImpl.java validateApiDetails()", "Error occured while validating api details.", "");
		}
	}
	
	public void saveApiEnableStatus(EventDataParameters eventDataParams,ImportDataParameters importData,String apiSecret)
	{
		logger.info(LOG_APPLICATION_FLOW + "Save API enable status has started.");
		Map<String,Object> apiEnableDetails = new HashMap<String,Object>();
		
		apiEnableDetails.put(CLIENT_ID,eventDataParams.getClientId());
		apiEnableDetails.put(PLATFORM_ID, eventDataParams.getPlatformId());
		apiEnableDetails.put(IS_API_ENABLED, (Boolean)eventDataParams.getTrackedData().get(IS_API_ENABLED));
		apiEnableDetails.put(STORE_NAME, (String)eventDataParams.getTrackedData().get(STORE_NAME));
		apiEnableDetails.put(STORE_URL, (String)eventDataParams.getTrackedData().get(STORE_URL));
		
		UpdateApiEnableStatus updateApiEnableStatus = UpdateApiEnableStatus.getInstance();
		Integer result = updateApiEnableStatus.runService(apiEnableDetails);
		
		if(result == 1)
		{
			jsonResponse = new JsonResponse(HttpStatus.OK_200, "success",null, " ");
		}
		else
		{
		  jsonResponse = new JsonResponse(HttpStatus.OK_200, "fail",null," ");
		  String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveApiEnableStatus" , "failed to update into database." ,"");
		  logger.error(errorMessage);	
		  ErrorLog.saveErrorLogToDB("saveApiEnableStatus.java runService()", "failed to update into database.", "");

		}
		logger.info(LOG_APPLICATION_FLOW + "Save API enable status has completed.");
		
	}
	
	public void saveClientShippingDetails(EventDataParameters eventDataParams)
	{
		logger.info(LOG_APPLICATION_FLOW + "Importing shipping details has started.");
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(CLIENT_ID, eventDataParams.getClientId());		
		input.put(IS_FREE_SHIPPING_ACTIVE, eventDataParams.getTrackedData().get(IS_FREE_SHIPPING_ACTIVE));
		input.put(FREE_SHIPPING_SUB_TOTAL,eventDataParams.getTrackedData().get(FREE_SHIPPING_SUB_TOTAL));
		input.put(FREE_SHIPPING_TITLE, eventDataParams.getTrackedData().get(FREE_SHIPPING_TITLE));
	
		UpdateFreeShippingDetails updateFreeShippingDetails = UpdateFreeShippingDetails.getInstance();
		updateFreeShippingDetails.runService(input);
		
		logger.info(LOG_APPLICATION_FLOW + "Importing shipping details has completed.");
		
	}
	
	public int getFeedId(int clientId)
	{
		logger.info(LOG_APPLICATION_FLOW + "Get feed id method has started.");
		Map<String,Object> input = new HashMap<String,Object>();
		input.put(CLIENT_ID, clientId);
		
		GetFeedId getFeedId = GetFeedId.getInstance();
		int feedId = getFeedId.runService(input);
		logger.info(LOG_APPLICATION_FLOW + "Get feed id method completed.");
		return feedId;
	}
	
	public ArrayList<AssociatedProducts> processAssociatedProducts(ArrayList<String> productList,String productId,String associationType,Integer feedId)
	{
		ArrayList<AssociatedProducts> associatedProductList = new ArrayList<AssociatedProducts>();
		for(String associatedProductId : productList)
	    {
 	    	AssociatedProducts associatedProducts = new AssociatedProducts();
 	    	associatedProducts.setProductId(productId);
 	    	associatedProducts.setAssociatedProductId(associatedProductId);
 	    	associatedProducts.setAssociationType(associationType);
 	    	associatedProducts.setFeedId(feedId);
 	    	associatedProductList.add(associatedProducts);			        	    	
	    }
		
		return associatedProductList;
	}
	
	public void trackError(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Error tracking has started.");
					
		String method = eventDataParams.getTrackedData().get(EVENT_METHOD).toString();
		String errorMessage = eventDataParams.getTrackedData().get(ERROR_MESSAGE).toString();
		
		String otherDetails = "Visitor Id - " + importData.getVid() + " visit time - " + importData.getTime() + " refferral url - "+ importData.getUri() +
				" user agent - " + importData.getUserAgent();
		
		ErrorLog.saveErrorLogToDB(method, " Client Id - " + eventDataParams.getClientId() + " " + errorMessage,  otherDetails);
		
		logger.info(LOG_APPLICATION_FLOW + "Error tracking completed.");
	}
	
	public void processBundleAddToCartFailureTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Bundle Add to cart failure has started.");
		
		LinkedHashMap<String,Object> bundleData = (LinkedHashMap<String,Object>)eventDataParams.getTrackedData().get(BUNDLE_DATA);
		
		String bundleId = bundleData.get(BUNDLE_ID).toString();
		String discountAmount = bundleData.get("discountPrice").toString();
		
		String errorBundleDetails = "Bundle Id - " + bundleId + " discount amount -" + discountAmount;
		String otherDetails = "Visitor Id - " + importData.getVid() + " visit time - " + importData.getTime() + " refferral url - "+ importData.getUri() +
				" user agent - " + importData.getUserAgent();
		
		ErrorLog.saveErrorLogToDB("BundleAddToCart", " Client Id - " + eventDataParams.getClientId() + " " + errorBundleDetails,  otherDetails);
		
		logger.info(LOG_APPLICATION_FLOW + "Bundle Add to cart failure completed.");
	}
		
	public void processPixelRequest(TrackRequest trackRequest)
	{
		String requestQueryString = "";
		try
		{
			this.trackRequest = trackRequest;
						
			trackRequest.readAndValidateTrackRequest();
						
			trackRequest.decryptTrackRequest();
			
			requestQueryString = trackRequest.getQueryString();
						
			switch (trackRequest.getTrackType())
	        {
	         case RequestType.CONVERSION_PIXEL:
	        	  processConversionPixel();
				  break;
	         
	        }
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processPixelRequest" , "processPixelRequest method error" , requestQueryString);
			logger.error(errorMessage,ex);
		}		
	}
	
	public void processConversionPixel()
	{
		OrderPixelImpl orderConfirmationImpl = new OrderPixelImpl();
		orderConfirmationImpl.processOrderConfirmation(trackRequest);
	}
	
	public void processMagentoTrackedOrderData(Map<String,Object> input)
	{
		try
		{			
			Integer clientId =(Integer)input.get(CLIENT_ID);
			String clientOrderId = (String) input.get(ORDER_ID);			
			
			SaveOrderData saveOrder= new SaveOrderData();
	        Boolean hasOrderDetailsSaved = false;
	 			        
	        if(input.size() > 0)
	        {	
	           hasOrderDetailsSaved = saveOrder.runService(input);	          
	        }
	        else
	        {
	           String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "Issue occured while inserting order details for the client id -" + clientId + " client order id - "+ clientOrderId , trackRequest.getQueryString());
	 		   logger.error(errorMessage,"");
	        }
	        
	        	        
	        if(hasOrderDetailsSaved)
	        {
	        	logger.info("Magento order item processing started");
		        ArrayList<Map<String,Object>> orderItems = (ArrayList<Map<String,Object>>)input.get(ITEMS);
		        
		        String visitorId = (String)input.get(VISITOR_ID);
		        
		        if(orderItems != null && orderItems.size() > 0)
		        {	        
			        for(Map<String,Object> orderItem : orderItems)
			        {
			        	String productId = (String)orderItem.get(PRODUCT_ID);
			        	Map<String, Object> orderItemInput = new HashMap<String,Object>();
			 	        orderItemInput.put(CLIENT_ID, clientId);
			 	        orderItemInput.put(ORDER_ID, clientOrderId);
			 	        orderItemInput.put(VISITOR_ID, visitorId);
			 	        orderItemInput.put(PRODUCT_ID, orderItem.get(PRODUCT_ID));
			 	        orderItemInput.put(PRODUCT_PRICE, orderItem.get(PRODUCT_PRICE));
			 	        orderItemInput.put(PRODUCT_SKU, orderItem.get(PRODUCT_SKU));
			 	        orderItemInput.put(QUANTITY, orderItem.get(QUANTITY));
			 	        
			 	        logger.info(LOG_APPLICATION_FLOW + "Order item data processing has started.");
			 	        SaveOrderItemDetails saveOrderItemDetails =new SaveOrderItemDetails();
		      		    Boolean hasOrderItemSaved = saveOrderItemDetails.runService(orderItemInput);
		      		 
		      		    if(!hasOrderItemSaved)
		      		    {
		      			  String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processMagentoTrackedOrderData" , "Issue occured while inserting order item details for the client id -" + clientId + " client order id - "+ clientOrderId + " product id -" + productId, "");
		       			  logger.error(errorMessage,"");	 
		      		    }
		      		 
		      		    saveOrderItemDetails = null;
		      		    logger.info(LOG_APPLICATION_FLOW + "Order item data processing completed.");
			 	       
			        }
		        }
	        }	       
	        
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processMagentoTrackedOrderData" , "Issue occured while tracking magento order" , "");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("processMagentoTrackedOrderData.java runService()", "Issue occured while tracking magento order.", ex.getMessage());
		}
	}
	
	public void processMultipleAddToCartTracking(EventDataParameters eventDataParams,ImportDataParameters importData)
	{
		logger.info(LOG_APPLICATION_FLOW + "Multiple Product Add to cart tracking has started.");
		Map<String,Object> input = new HashMap<String,Object>();
			
		if(eventDataParams.getTrackedData().get(PRODUCT_IDS) != null)
		{
		    input.put(PRODUCT_IDS, eventDataParams.getTrackedData().get(PRODUCT_IDS));
		    input.put(VISITOR_ID, importData.getVid());
			input.put(VISIT_TIME,importData.getTime());
			input.put(REFERRAL_URL, importData.getUri());		
			input.put(USER_AGENT, importData.getUserAgent());
			input.put(USER_IP, importData.getUserIpAddress());
			input.put(CLIENT_ID, eventDataParams.getClientId());
			
			InsertMultipleAddToCartTrackingImpl insertMultipleAddToCartTracking = new InsertMultipleAddToCartTrackingImpl();
			insertMultipleAddToCartTracking.runService(input);
		}
		
		logger.info(LOG_APPLICATION_FLOW + "Multiple Product Add to cart tracking has completed.");
		
	}
}