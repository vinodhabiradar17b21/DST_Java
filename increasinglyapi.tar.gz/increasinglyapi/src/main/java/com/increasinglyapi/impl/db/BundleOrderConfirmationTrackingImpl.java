package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class BundleOrderConfirmationTrackingImpl implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BundleOrderConfirmationTrackingImpl.class.getClass());
		
	private static BundleOrderConfirmationTrackingImpl instance = null;
	
	private BundleOrderConfirmationTrackingImpl()
	{
				
	}

	public static BundleOrderConfirmationTrackingImpl getInstance()
	{
		if (instance == null)
		{
			instance = new BundleOrderConfirmationTrackingImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String clientOrderId = (String)input.get(ORDER_ID);
		String increasinglyVisitorId = (String)input.get(INCREASINGLY_VISITOR_ID);
			
		Integer result = 0;
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Insert_Bundle_Order_Confirmation_Tracking(?, ?, ?,?)}");
					
			cStmt.registerOutParameter(4, java.sql.Types.INTEGER);
			
			cStmt.setInt(1, clientId);						
			cStmt.setNString(2, clientOrderId);
			cStmt.setString(3, increasinglyVisitorId);
			
			cStmt.execute();
			result = cStmt.getInt(4);
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BundleOrderConfirmationTrackingImpl" , "Error Occured while inserting bundle order tracking details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("BundleOrderConfirmationTrackingImpl", " Error Occured while tracking bundle order data for the client id -"+ clientId + " client order id -" + clientOrderId + " visitor id -" +increasinglyVisitorId,  ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("BundleOrderConfirmationTrackingImpl","Error Occured while closing connection.",  e.getMessage());
			}
		}
		
			
		return result;
	}
}