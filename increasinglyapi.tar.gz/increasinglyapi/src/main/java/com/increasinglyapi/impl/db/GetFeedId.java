package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;

public class GetFeedId extends StoredProcedure implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final String SPROC_NAME = "Get_Feed_Id";

	private static GetFeedId instance = null;
	private static final Logger logger = LoggerFactory.getLogger(GetFeedId.class.getName());

	private GetFeedId()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ClientId", Types.VARCHAR));
		declareParameter(new SqlOutParameter("FeedId", Types.INTEGER));
		compile();		
	}

	public static GetFeedId getInstance()
	{
		if (instance == null)
		{
			instance = new GetFeedId();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		Map<String, Object> results = execute(clientId);
		
		if (results.get("FeedId") == null)
		{
			return 0;
		}
		else
		{
			Integer feedId = (Integer) results.get("FeedId");
			return feedId;			
		}		
	}
	
}