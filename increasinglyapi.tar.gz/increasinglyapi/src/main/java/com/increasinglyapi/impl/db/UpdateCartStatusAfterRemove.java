package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class UpdateCartStatusAfterRemove implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateCartStatusAfterRemove.class.getClass());
	
	private static UpdateCartStatusAfterRemove instance = null;
	
	private UpdateCartStatusAfterRemove()
	{
		
	}

	public static UpdateCartStatusAfterRemove getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateCartStatusAfterRemove();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{
		Boolean isLoggedIn = (Boolean) input.get(IS_LOGGED_IN);
		String productId = (String) input.get(PRODUCT_ID);
		String visitorId = (String) input.get(VISITOR_ID);
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String visitTime = (String) input.get(VISIT_TIME);
		
		/*if((Boolean) input.get(IS_LOGGED_IN))
		{
		  isLoggedIn = 1;
		}*/
	   
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Cart_Product_Status_On_Remove(?, ?, ?, ?, ?)}");
		
			cStmt.setBytes(1, productId.getBytes());
			
			if(isLoggedIn != null)
			{
			  cStmt.setBoolean(2, isLoggedIn);
			}
			else
			{
				cStmt.setBoolean(2, false);
			}
			
			if(visitorId != null && !visitorId.isEmpty())
			{
			  cStmt.setString(3, visitorId);
			}
			else
			{
				cStmt.setNull(3, Types.VARCHAR);
			}
			
			cStmt.setInt(4, clientId);
			
			if(visitTime != null && !visitTime.isEmpty())
			{
		      cStmt.setString(5, visitTime);
			}
			else
			{
				cStmt.setNull(5, Types.VARCHAR);
			}
			
			cStmt.execute();
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateCartStatusAfterRemove" , "Error Occured while updating cart status after removing a product from cart." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("UpdateCartStatusAfterRemove.java runService()", "Error occured while updating cart status after removing a product from cart.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateCartStatusAfterRemove.java runService()", "Error occured while closing connection", e.getMessage());
			}
		}
		
		return true;
	}
	
}