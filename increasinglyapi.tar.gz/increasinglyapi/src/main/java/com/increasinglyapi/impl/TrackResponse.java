package com.increasinglyapi.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Cookie;

public class TrackResponse
{
	/**
	 *  Cookies
	 */
	private List<Cookie> cookieData = new ArrayList<Cookie>();

    public List<Cookie> getCookies()
    {
       return cookieData; 
    }
     
    public void setCookies(List<Cookie> cookieData)
    {
        this.cookieData = cookieData;
    }
     
    public void setCookie(String cookieName,String value)
    {
    	 Cookie cookie = new Cookie(cookieName,value);
    	 this.cookieData.add(cookie);
    }
}