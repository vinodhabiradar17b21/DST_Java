package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class InsertProductOptionDetailsImpl implements ServiceInterface<Integer>
{
	private static InsertProductOptionDetailsImpl instance = null;	
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertProductOptionDetailsImpl.class.getClass());

	private InsertProductOptionDetailsImpl()
	{
			
	}

	public static InsertProductOptionDetailsImpl getInstance()
	{
		if (instance == null)
		{
			instance = new InsertProductOptionDetailsImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Connection conn = null;
		int feedId= (Integer)input.get(FEED_ID);
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Insert_OR_Update_Product_Options_Data(?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			
			String productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			cStmt.registerOutParameter(3, Types.INTEGER);
			
			cStmt.execute();
			
			Integer result = cStmt.getInt("result");
			
			return result;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertProductOptionDetailsImpl" , "Error Occured while updating product option details." ,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryProductOptionDetails(input);
			ErrorLog.saveErrorLogToDB("UpdateProductCategoryDataImpl.java", "Feed Id - " + feedId  +" Error Occured while updating product option details to main table.",  ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateProductCategoryDataImpl.java", "Error Occured while closing connection.",  e.getMessage());

			}
		}
		
		return 0;
	}
}