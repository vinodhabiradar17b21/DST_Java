package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.LOG_ERROR;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class ErrorLog
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(ErrorLog.class.getClass());
		
	public static void saveErrorLogToDB(String source,String message, String stackTrace)
    {
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call AddErrorLog(?, ?, ?)}");
			
			cStmt.setString(1, source);	
			cStmt.setString(2, message);	
			cStmt.setString(3, stackTrace);	
			
			cStmt.execute();
			
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "saveErrorLogToDB" , "Error Occured while inserting error log" ,"");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    }
}