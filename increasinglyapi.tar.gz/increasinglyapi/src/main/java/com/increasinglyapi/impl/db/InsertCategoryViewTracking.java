package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertCategoryViewTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertCategoryViewTracking.class.getClass());
			
	public Boolean runService(final Map<String, Object> input) 
	{
	   JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
		        
	   String queryTmpl = "INSERT INTO category_view_tracking"
				+ "(category_id,visitor_id,visit_time,referral_url,user_agent,platform_id,client_id)"
				+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
	
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){
	
				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {
						
					    ps.setNString(1, (String)input.get(CATEGORY_ID));
						ps.setString(2, (String)input.get(VISITOR_ID));
						ps.setString(3, (String)input.get(VISIT_TIME));								
						ps.setNString(4, (String)input.get(REFERRAL_URL));
						ps.setNString(5, (String)input.get(USER_AGENT));
						//ps.setString(6, (String)input.get(USER_IP));					
						ps.setInt(6, (Integer)input.get(PLATFORM_ID));
						ps.setInt(7, (Integer)input.get(CLIENT_ID));
										
						ps.execute();
						return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertCategoryViewTracking" , "Error Occured while inserting category view tracking data.." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertCategoryViewTracking.java runService()", "Error occured while inserting category view tracking data.", ex.getMessage());
			return false;
		}
	}
	
}