package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class UpdateApiEnableStatus implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateApiEnableStatus.class.getClass());
	
	private static UpdateApiEnableStatus instance = null;
	
	private UpdateApiEnableStatus()
	{
		
	}

	public static UpdateApiEnableStatus getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateApiEnableStatus();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_API_Enable_Status(?, ?, ?, ?, ?, ?)}");
			
			cStmt.setInt(1, (Integer) input.get(CLIENT_ID));
			cStmt.setInt(2, (Integer) input.get(PLATFORM_ID));
			cStmt.setBoolean(3, (Boolean) input.get(IS_API_ENABLED));
			cStmt.setNString(4, (String) input.get(STORE_NAME));
			cStmt.setNString(5, (String) input.get(STORE_URL));
			cStmt.registerOutParameter(6, Types.INTEGER);
						
			cStmt.execute();
			
			Integer result = cStmt.getInt("Result");
			
			return result;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateApiEnableStatus" , "Error Occured while updating API enable status." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("UpdateApiEnableStatus.java runService()", "Error occured while updating API enable status.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateApiEnableStatus.java runService()", "Error occured while updating API enable status.", e.getMessage());
			}
		}
		
		return 0;
	}
}