package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertBundleProductClickTracking implements ServiceInterface<Boolean>
{
	
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertBundleProductClickTracking.class.getClass());
	
	private static InsertBundleProductClickTracking instance = null;
	
	private InsertBundleProductClickTracking()
	{
				
	}

	public static InsertBundleProductClickTracking getInstance()
	{
		if (instance == null)
		{
			instance = new InsertBundleProductClickTracking();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{			 
		String productId = (String) input.get(PRODUCT_ID);
		String coreProductId = (String) input.get(CORE_PRODUCT_ID);
		Integer clientId = (Integer) input.get(CLIENT_ID);		
		String visitorId = (String) input.get(VISITOR_ID);
		String referralUrl = (String) input.get(REFERRAL_URL);
		String userAgent = (String) input.get(USER_AGENT);
		//String userIp = (String)input.get(USER_IP);
		Integer isLoggedInUser = (Integer) input.get(IS_LOGGED_IN_USER);
		
		Integer pageTypeId = 0;
											
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Insert_Bundle_Product_Click_Tracking(?, ?, ?, ?, ?, ?, ?, ?)}");
					
			cStmt.setBytes(1, productId.getBytes());
			

			if(coreProductId != null && !coreProductId.isEmpty())
			{
				cStmt.setBytes(2, coreProductId.getBytes());
			}
			else
			{
				cStmt.setNull(2, Types.BINARY);
			}
			
			cStmt.setInt(3, clientId);	
			
			if(visitorId != null && !visitorId.isEmpty())
			{
				cStmt.setString(4, visitorId);
			}
			else
			{
				cStmt.setNull(4, Types.NVARCHAR);
			}
			
						
			if(referralUrl != null && !referralUrl.isEmpty())
			{
				cStmt.setNString(5, referralUrl);
			}
			else
			{
				cStmt.setNull(5, Types.NVARCHAR);
			}
		
			if(userAgent != null && !userAgent.isEmpty())
			{
				cStmt.setNString(6, userAgent);
			}
			else
			{
				cStmt.setNull(6, Types.NVARCHAR);
			}
			
			/*if(userIp != null && !userIp.isEmpty())
			{
				cStmt.setString(7, userIp);
			}
			else
			{
				cStmt.setNull(7, Types.VARCHAR);
			}*/
						
			if(input.get(PAGE_TYPE_ID) != null && !input.get(PAGE_TYPE_ID).toString().isEmpty())				
			{
				pageTypeId = (Integer) input.get(PAGE_TYPE_ID);
				
				if(pageTypeId > 0)
				{
				   cStmt.setInt(7, pageTypeId);	
				}
				else
				{
				  cStmt.setNull(7, Types.INTEGER);	
				}
			}
			else
			{
				cStmt.setNull(7, Types.INTEGER);	
			}
			
			if(isLoggedInUser != null)
			{
				cStmt.setInt(8, isLoggedInUser);
			}			
			else
			{
				cStmt.setNull(8, Types.INTEGER);	
			}
									
			cStmt.execute();
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertBundleProductClickTracking" , "Error Occured while inserting bundle product click tracking details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertBundleProductClickTracking.java runService()", "Error occured while inserting bundle product click tracking details..", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("InsertBundleProductClickTracking.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
				
		return true;
	}
	
}