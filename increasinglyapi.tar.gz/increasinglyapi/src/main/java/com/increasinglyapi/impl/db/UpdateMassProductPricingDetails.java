package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class UpdateMassProductPricingDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateMassProductPricingDetails.class.getClass());
	
	private static UpdateMassProductPricingDetails instance = null;
	
	private UpdateMassProductPricingDetails()
	{
		
	}

	public static UpdateMassProductPricingDetails getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateMassProductPricingDetails();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId = 0;
		String productIdList = "";
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Magento_Mass_Product_Attribute_Details(?, ?, ?, ?,?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			feedId = (Integer)input.get(FEED_ID);
			
			productIdList = (String) input.get(PRODUCT_IDS);
			cStmt.setNString(2, productIdList);
									
			if(input.get(PRICE) != null && !input.get(PRICE).toString().isEmpty())
			{   
				double price = Double.parseDouble((String) input.get(PRICE));
				if(feedId == 18 || feedId == 19 || feedId == 20 || feedId == 21 || feedId == 22)
				{
					price = price + (price * 0.20);
				}
				
				cStmt.setDouble(3, price);
			}
			else
			{
				cStmt.setNull(3,Types.DOUBLE);
			}			
			
			if(input.get(SPECIAL_PRICE) != null && !input.get(SPECIAL_PRICE).toString().isEmpty())
			{   
				double specialPrice = Double.parseDouble((String) input.get(SPECIAL_PRICE));
				
				if(feedId == 18 || feedId == 19 || feedId == 20 || feedId == 21 || feedId == 22)
				{
					specialPrice = specialPrice + (specialPrice * 0.20);
				}

				cStmt.setDouble(4, specialPrice);
			}
			else
			{
				cStmt.setNull(4,Types.DOUBLE);
			}
						
			if(input.get(CLIENT_PRODUCT_STATUS) != null && !input.get(CLIENT_PRODUCT_STATUS).toString().isEmpty())
			{ 
				cStmt.setInt(5, (Integer) input.get(CLIENT_PRODUCT_STATUS));
			}
			else
			{
				cStmt.setNull(5,Types.INTEGER);
			}			
			
			cStmt.execute();
			
		} 
		catch (Exception ex) 
		{
			ErrorLog.saveErrorLogToDB("UpdateMassProductPricingDetails", "Feed Id - " + feedId + " Product Id List -" + productIdList +" Error Occured while updating product attribute data.",  ex.getMessage());
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateMassProductPricingDetails" , "Error Occured while updating product attribute data.." ,"");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateMassProductPricingDetails","Error Occured while closing connection.",  e.getMessage());
			}
		}
		
		return true;
	}
}