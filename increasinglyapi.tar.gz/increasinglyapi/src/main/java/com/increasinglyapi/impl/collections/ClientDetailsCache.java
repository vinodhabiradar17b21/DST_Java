package com.increasinglyapi.impl.collections;

import static com.increasinglyapi.utils.Constants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import jersey.repackaged.com.google.common.cache.Cache;
import jersey.repackaged.com.google.common.cache.CacheBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.impl.ClientDetailsParameters;
import com.increasinglyapi.impl.db.ClientDetails;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class ClientDetailsCache
{
	private static final Logger logger = LoggerFactory.getLogger(ClientDetailsCache.class.getClass());
	private static final ClientDetailsCache instance = new ClientDetailsCache();

	private static Object lock1 = new Object();
	
	// Cache object
	private Cache<String, ClientDetailsParameters> cacheClientDetails = CacheBuilder.newBuilder().maximumSize(500)
																	.expireAfterWrite(20, TimeUnit.MINUTES).build();
	
	public static ClientDetailsCache getCache()
	{
		return instance;
	}

	/**
	 * Uses Guava cache for caching the client details
	 * 
	 * @param clientId,ApiSecret
	 * @return cleint details
	 * @throws ExecutionException
	 */
	public ClientDetailsParameters get(final String apiKey)
	{			
		try
		{
			synchronized(lock1)
			{
				ClientDetailsParameters clientDetailsParams = cacheClientDetails.get(new String(apiKey), new Callable<ClientDetailsParameters>()
				{
					public ClientDetailsParameters call() throws Exception
					{
						return getClientDetailsFromDb(apiKey);
					}
				});
				
				return clientDetailsParams;
			}
			
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ClientDetailsParameters-get method" , "Error Occured" ,"");
			logger.error(errorMessage,ex);
			return null;
		}
		
	}
	
	public ClientDetailsParameters getClientDetailsFromDb(String apiKey)
	{
		ClientDetailsParameters clientDetailsParameters = null;
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Retrieving client details for the api key - " + apiKey);
			ClientDetails clientDetails = ClientDetails.getInstance();
			
			Map<String, Object> input = new HashMap<String,Object>();
			input.put(TOKEN, apiKey);		
			ArrayList<Map<String,Object>> clientDetailsFromDb = clientDetails.runService(input);
			clientDetailsParameters = new ClientDetailsParameters(); 
			for (Map<String, Object> field : clientDetailsFromDb)
			{
				clientDetailsParameters.setApiKey(apiKey);
				clientDetailsParameters.setClientId((Integer)field.get("ClientId"));
				clientDetailsParameters.setApiSecret((String)field.get("ApiSecret"));
			}
			
			logger.info(LOG_APPLICATION_FLOW + "Completed fetching client details for the api key - " + apiKey);
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "getClientDetailsFromDb" , "Error Occured while fetching client details." ,"");
			logger.error(errorMessage,ex);
		}
		
		return clientDetailsParameters;
	}

}