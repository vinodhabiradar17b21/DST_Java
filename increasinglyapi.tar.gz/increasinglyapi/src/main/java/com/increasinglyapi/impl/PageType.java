package com.increasinglyapi.impl;

public class PageType
{
	public static final int PRODUCT_PAGE = 100;
	public static final int SEARCH_PAGE = 101;
	public static final int PLP_PAGE = 102;
	public static final int CART_PAGE = 103;
	public static final int MODAL = 107;
	public static final int CHECKOUT_PAGE = 108;
}