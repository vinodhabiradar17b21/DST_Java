package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import java.sql.PreparedStatement;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class BulkInsertOrderItemsAttributeData implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BulkInsertOrderItemsAttributeData.class.getClass());
	List<Map<String,Object>> orderItemAttributeList = new ArrayList<Map<String,Object>>();
	
				
	public Boolean runService(Map<String,Object> input) 
	{
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
			
		String queryTmpl = "INSERT INTO order_item_attribute_details_temporary_storage"
				+ "(client_id,client_order_id,product_id,attribute_code,attribute_id,option_id,option_text,quantity"
				+") VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		final int batchSize = 5000; 
        final Integer clientId = (Integer)input.get(CLIENT_ID);
        final String clientOrderId = (String)input.get(ORDER_ID);
       
		
		try
		{
			orderItemAttributeList = (List<Map<String,Object>>)input.get(ITEM_ATTRIBUTE_LIST);
			 
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for (Map<String,Object> item : orderItemAttributeList)
					{
						String orderId = clientOrderId;						
						String productId = null;
										
						
						productId = (String)item.get(PRODUCT_ID);
																			
					    ps.setInt(1, clientId);						  						    
						ps.setNString(2, orderId);
						ps.setBytes(3, productId.getBytes());
						
						if(item.get(ATTRIBUTE_CODE) != null && !item.get(ATTRIBUTE_CODE).toString().isEmpty())
						{
						   ps.setNString(4, (String)item.get(ATTRIBUTE_CODE));
						}
						else
						{
						   ps.setNull(4,Types.NVARCHAR);
						}
						
						if(item.get(ATTRIBUTE_ID) != null && !item.get(ATTRIBUTE_ID).toString().isEmpty())
						{
							String attributeId = (String)item.get(ATTRIBUTE_ID);
							ps.setBytes(5, attributeId.getBytes());								
						}
						else
						{
							ps.setNull(5,Types.BINARY);
						}
						
						if(item.get(OPTION_ID) != null && !item.get(OPTION_ID).toString().isEmpty())
						{
							String optionId = (String)item.get(OPTION_ID);
							ps.setBytes(6, optionId.getBytes());								
						}
						else
						{
							ps.setNull(6,Types.BINARY);
						}
						
						if(item.get(OPTION_TEXT) != null && !item.get(OPTION_TEXT).toString().isEmpty())
						{
						   ps.setNString(7, (String)item.get(OPTION_TEXT));
						}
						else
						{
						   ps.setNull(7,Types.NVARCHAR);
						}
						
						if(item.get(QUANTITY) != null && !item.get(QUANTITY).toString().isEmpty())
						{
							ps.setInt(8, Integer.parseInt(item.get(QUANTITY).toString()));
						}
						else{
							ps.setNull(8,Types.BINARY);
						}
						
						ps.addBatch();
					}
				
					if (++count % batchSize == 0)
					{
						ps.executeBatch();
					}
				
					
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}		
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BulkInsertOrderItemsAttributesData" , "Error Occured while importing order item attribute details." ,"");
			logger.error(errorMessage,ex);
			
			ErrorLog.saveErrorLogToDB("BulkInsertOrderItemsAttributeData", "Client Id - " + clientId +" Error Occured while importing order item attribute details.",  ex.getMessage());
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryOrderItemAttributeDetails(input);
			return false;
		}
	}
	
	
}