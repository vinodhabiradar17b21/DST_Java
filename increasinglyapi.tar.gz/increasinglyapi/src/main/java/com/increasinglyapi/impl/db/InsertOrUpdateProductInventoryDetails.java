package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertOrUpdateProductInventoryDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertOrUpdateProductInventoryDetails.class.getClass());
	
	private static InsertOrUpdateProductInventoryDetails instance = null;
	
	private InsertOrUpdateProductInventoryDetails()
	{
		
	}

	public static InsertOrUpdateProductInventoryDetails getInstance()
	{
		if (instance == null)
		{
			instance = new InsertOrUpdateProductInventoryDetails();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId = 0;
		String productId = "";
		
		try 
		{        	
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Product_Inventory_Details(?, ?, ?, ?,?, ?, ?, ?,?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			feedId = (Integer)input.get(FEED_ID);
			
			productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			
			if(input.get(QUANTITY) != null)
			{
			   cStmt.setInt(3, (int)(Double.parseDouble((String)input.get(QUANTITY))));	
			}
			else
			{
				cStmt.setNull(3,Types.INTEGER);
			}			
						
			if(input.get(BACKORDERS) != null && !input.get(BACKORDERS).toString().isEmpty())
			{
				Integer isBackOrdersAllowed = Integer.parseInt((String)input.get(BACKORDERS));
							
				cStmt.setInt(4,isBackOrdersAllowed);
			}
			else
			{
				cStmt.setNull(4,Types.INTEGER);
			}						
			
			if(input.get(USE_CONFIG_BACKORDERS) != null && !input.get(USE_CONFIG_BACKORDERS).toString().isEmpty())
			{
				Integer useConfigBackOrders = Integer.parseInt((String)input.get(USE_CONFIG_BACKORDERS));	  
				
				if(useConfigBackOrders == 1)
					cStmt.setBoolean(5, true);	
				else
					cStmt.setBoolean(5, false);					
			}
			else
			{
				cStmt.setNull(5,Types.BIT);
			}
			
			if(input.get(MIN_SALE_QUANTITY) != null)
			{	
				cStmt.setInt(6, (int)(Double.parseDouble((String)input.get(MIN_SALE_QUANTITY))));
			}
			else
			{
				cStmt.setNull(6,Types.INTEGER);
			}
					
			if(input.get(USE_CONFIG_MIN_SALE_QUANTITY) != null && !input.get(USE_CONFIG_MIN_SALE_QUANTITY).toString().isEmpty())
			{   
				Integer useConfigMinSaleQty = Integer.parseInt(((String)input.get(USE_CONFIG_MIN_SALE_QUANTITY)));
				
				if(useConfigMinSaleQty == 1)
					cStmt.setBoolean(7, true);	
				else
					cStmt.setBoolean(7, false);				
			}
			else
			{
				cStmt.setNull(7,Types.BIT);
			}			
												
			if(input.get(MAX_SALE_QUANTITY) != null)
			{
				cStmt.setInt(8, (int)(Double.parseDouble((String)input.get(MAX_SALE_QUANTITY))));
			}
			else
			{
				cStmt.setNull(8,Types.INTEGER);
			}
			        	
			if(input.get(USE_CONFIG_MAX_SALE_QUANTITY) != null && !input.get(USE_CONFIG_MAX_SALE_QUANTITY).toString().isEmpty())
			{
				Integer useConfigMaxSaleQty = Integer.parseInt(((String)input.get(USE_CONFIG_MAX_SALE_QUANTITY)));
				
				if(useConfigMaxSaleQty == 1)
					cStmt.setBoolean(9, true);	
				else
					cStmt.setBoolean(9, false);					
			}
			else
			{
				cStmt.setNull(9,Types.BIT);
			}
			
			if(input.get(IS_IN_STOCK) != null && !input.get(IS_IN_STOCK).toString().isEmpty())
			{
				Integer isInStock = Integer.parseInt(((String)input.get(IS_IN_STOCK)));
				
				if(isInStock == 1)
					cStmt.setBoolean(10, true);	
				else
					cStmt.setBoolean(10, false);					
			}
			else
			{
				cStmt.setNull(10,Types.BIT);
			}		
			
			if(input.get(MIN_QUANTITY) != null)
			{	
				cStmt.setInt(11, (int)(Double.parseDouble((String)input.get(MIN_QUANTITY))));
			}
			else
			{
				cStmt.setNull(11,Types.INTEGER);
			}
			
			cStmt.execute();
			
		} 
		catch (Exception ex) 
		{
			ErrorLog.saveErrorLogToDB("InsertOrUpdateProductInventoryDetails", "Feed Id - " + feedId + " Product Id - " + productId +" Error Occured while updating product inventory data.",  ex.getMessage());
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertOrUpdateProductInventoryDetails" , "Error Occured while updating product data.." ," Feed Id - " + feedId + " Product Id - " + productId);
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("InsertOrUpdateProductInventoryDetails","Error Occured while closing connection.",  e.getMessage());
			}
		}
		
		return true;
	}
}