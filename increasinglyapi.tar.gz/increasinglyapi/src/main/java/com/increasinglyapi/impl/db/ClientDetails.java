package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;


public class ClientDetails extends StoredProcedure implements ServiceInterface<ArrayList<Map<String,Object>>>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(ClientDetails.class.getClass());
	private static final String SPROC_NAME = "Retrieve_Client_Details";
	private static ClientDetails instance = null;
	
	private ClientDetails()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ApiKey", Types.VARCHAR));
		compile();		
	}

	public static ClientDetails getInstance()
	{
		if (instance == null)
		{
			instance = new ClientDetails();
		}
		return instance;
	}

	public ArrayList<Map<String,Object>> runService(Map<String, Object> input) 
	{
		String apiKey = (String) input.get(TOKEN);
		ArrayList<Map<String, Object>> results = (ArrayList<Map<String, Object>>)execute(apiKey).get("#result-set-1");
		return results;
	}
	
}