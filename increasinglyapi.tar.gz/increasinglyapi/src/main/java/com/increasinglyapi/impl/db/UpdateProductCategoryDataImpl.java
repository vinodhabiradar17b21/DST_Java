package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class UpdateProductCategoryDataImpl implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateProductCategoryDataImpl.class.getClass());
	
	private static UpdateProductCategoryDataImpl instance = null;
	
	private UpdateProductCategoryDataImpl()
	{
		
	}

	public static UpdateProductCategoryDataImpl getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateProductCategoryDataImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId= (Integer)input.get(FEED_ID);
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Product_Category_Data(?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			
			String productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			cStmt.registerOutParameter(3, Types.INTEGER);
			
			cStmt.execute();
			
			Integer result = cStmt.getInt("result");
			
			return result;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateProductCategoryDataImpl" , "Error Occured while updating product category details." ,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryProductCategoryDetails(input);
			ErrorLog.saveErrorLogToDB("UpdateProductCategoryDataImpl.java", "Feed Id - " + feedId  +" Error Occured while updating product category details to main table.",  ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return 0;
	}
}