package com.increasinglyapi.impl.db;


import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import static com.increasinglyapi.utils.Constants.*;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class BundleOrderTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BundleOrderTracking.class.getClass());
	
    
	
	public Boolean runService(final Map<String, Object> input) 
	{
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
		
		String queryTmpl = "INSERT INTO bundle_order_tracking"
				+ "(bundle_id,client_order_id,total_price,discount_amount,bundle_price)"
				+" VALUES (?, ?, ?, ?, ?)";

		final int batchSize = 5000; 
        final Map<String, List<Map<String,Object>>> bundleList = (Map<String, List<Map<String,Object>>>)input.get(BUNDLES);      
		
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for (Map.Entry<String, List<Map<String,Object>>> entry : bundleList.entrySet())
					{
						String orderId = entry.getKey();
						List<Map<String,Object>> bundleList = entry.getValue();
												
						Integer bundleId = null;
						
						
						Double bundlePrice = null;
										
						for (Map<String,Object> bundleDetails :bundleList)
						{
							bundleId = Integer.parseInt(bundleDetails.get(ID).toString());							
																				
						    ps.setInt(1, bundleId);							
							ps.setNString(2, orderId);	
							
							String totalPrice = (String)bundleDetails.get(TOTAL_PRICE);
							
							if(totalPrice != null && !totalPrice.isEmpty())
							{   
								ps.setDouble(3, Double.parseDouble(totalPrice));
							}
							else
							{
								ps.setNull(3, Types.NULL);								
							}
							
							
							String discountAmount = (String)bundleDetails.get(BUNDLE_DISCOUNT_AMOUNT);
							
							if(discountAmount != null && !discountAmount.isEmpty())
							{   
								ps.setDouble(4, Double.parseDouble(discountAmount));
							}
							else
							{
								ps.setNull(4, Types.NULL);								
							}
							
							if(totalPrice != null && !totalPrice.isEmpty() && discountAmount != null && !discountAmount.isEmpty())
							{ 
								bundlePrice = (Double.parseDouble(totalPrice) - Double.parseDouble(discountAmount));
								ps.setDouble(5, bundlePrice);		
							}
							else
							{
								ps.setNull(5, Types.NULL);
							}
																								
							ps.addBatch();
						}
					
						if (++count % batchSize == 0)
						{
							ps.executeBatch();
						}
					}
					
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BundleOrderTracking" , "Error Occured while tracking bundle order data." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("BundleOrderTracking", " Error Occured while racking bundle order data.",  ex.getMessage());
			return false;
		}	
		
	}
	
}