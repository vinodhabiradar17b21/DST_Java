package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.CallableStatement;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class UpdateCustomerLoginDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateCustomerLoginDetails.class.getClass());
		
	private static UpdateCustomerLoginDetails instance = null;
	
	private UpdateCustomerLoginDetails()
	{
				
	}

	public static UpdateCustomerLoginDetails getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateCustomerLoginDetails();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{		
		String emailAddress = (String) input.get(CUSTOMER_EMAIL);
		String customerName = (String) input.get(CUSTOMER_NAME);
		String firstName = (String) input.get(CUSTOMER_FIRST_NAME);
		String lastName = (String) input.get(CUSTOMER_LAST_NAME);
		String visitorId = (String) input.get(VISITOR_ID);
		Integer clientId = (Integer) input.get(CLIENT_ID);
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Customer_Login_Data(?, ?, ?, ?, ?, ?)}");
		
			cStmt.setNString(1, emailAddress);
			cStmt.setNString(2, customerName);
			cStmt.setNString(3, firstName);
			cStmt.setNString(4, lastName);
			cStmt.setString(5, visitorId);
			cStmt.setInt(6, clientId);
			
			cStmt.execute();
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateCustomerLoginDetails" , "Error Occured while updating customer details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("UpdateCustomerLoginDetails.java runService()", "Error occured while updating customer details.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateCustomerLoginDetails.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
		//execute(emailAddress,customerName,firstName,lastName,visitorId,clientId);
		
		return true;
	}
	
}