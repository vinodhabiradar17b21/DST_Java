package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertOrderItemAttributesData implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	
	private static InsertOrderItemAttributesData instance = null;
	private static final Logger logger = LoggerFactory.getLogger(InsertOrderItemAttributesData.class.getName());

	private InsertOrderItemAttributesData()
	{
		
	}

	public static InsertOrderItemAttributesData getInstance()
	{
		if (instance == null)
		{
			instance = new InsertOrderItemAttributesData();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String clientOrderId = (String) input.get(ORDER_ID);
				
		Integer result = 0;
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Insert_Order_Item_Attribute_Details(?, ?, ?)}");
					
			cStmt.registerOutParameter(3, java.sql.Types.INTEGER);
			
			cStmt.setInt(1, clientId);						
			cStmt.setNString(2, clientOrderId);
						
			cStmt.execute();
			result = cStmt.getInt(3);
			
		} 
		catch (Exception ex) {
			
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertOrderItemAttributesData" , "Error Occured while inserting order item attribute details." ,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryOrderItemAttributeDetails(input);
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
			
		return result;
	}
}