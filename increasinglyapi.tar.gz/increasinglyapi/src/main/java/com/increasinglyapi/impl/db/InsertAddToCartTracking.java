package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertAddToCartTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertAddToCartTracking.class.getClass());
			
	public Boolean runService(final Map<String, Object> input) 
	{	       
        
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
				
		String queryTmpl = "INSERT INTO add_to_cart_tracking"
				+ "(product_id,product_name,product_url,product_sku,product_type,product_price,quantity,option_product_id,"
				+ "option_product_name,option_product_sku,option_product_price,is_active,is_logged_in,visitor_id,visit_time,referral_url,"
				+ "user_agent,platform_id,client_id)"
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";	
	
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){
	
				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {
				
					String productId = (String)input.get(PRODUCT_ID);
					ps.setBytes(1, productId.getBytes());
					
					String productName = (String)input.get(PRODUCT_NAME);
					if(productName != null && !productName.isEmpty())
					{   
						ps.setNString(2, productName);
					}
					else
					{
						ps.setNull(2,Types.NVARCHAR);
					}
					
					String productURL = (String)input.get(PRODUCT_URL);
					if(productURL != null && !productURL.isEmpty())
					{   
						ps.setNString(3, productURL);
					}
					else
					{
						ps.setNull(3,Types.NVARCHAR);
					}
					
				
					String productSKU = (String)input.get(PRODUCT_SKU);
					if(productSKU != null && !productSKU.isEmpty())
					{   
						ps.setNString(4, productSKU);
					}
					else
					{
						ps.setNull(4,Types.NVARCHAR);
					}
					
					String productType = (String)input.get(PRODUCT_TYPE);
					if(productType != null && !productType.isEmpty())
					{   
						ps.setNString(5, productType);
					}
					else
					{
						ps.setNull(5,Types.NVARCHAR);
					}
									
					String productPrice = (String)input.get(PRODUCT_PRICE);
					if(productPrice != null && !productPrice.isEmpty())
					{   
						ps.setDouble(6, Double.parseDouble(productPrice));
					}
					else
					{
						ps.setNull(6,Types.DOUBLE);
					}
							
					if(input.get(QUANTITY) != null)
					{
						ps.setInt(7, (Integer)input.get(QUANTITY));	
					}
					else
					{
						ps.setInt(7, 1);	
					}
					
					String optionProductId = (String)input.get(OPTION_PRODUCT_ID);
					
					if(optionProductId != null && !optionProductId.isEmpty())
					{
					  ps.setBytes(8, optionProductId.getBytes());
					}
					else
					{
						ps.setNull(8, Types.BINARY);
					}
					
					String optionProductName = (String)input.get(OPTION_PRODUCT_NAME);
					if(optionProductName != null && !optionProductName.isEmpty())
					{
					  ps.setNString(9, optionProductName);
					}
					else
					{
						ps.setNull(9, Types.NVARCHAR);
					}
					
					String optionProductSku = (String)input.get(OPTION_PRODUCT_SKU);
					if(optionProductSku != null && !optionProductSku.isEmpty())
					{
					  ps.setNString(10, optionProductSku);
					}
					else
					{
						ps.setNull(10, Types.NVARCHAR);
					}							
										
					String optionProductPrice = (String)input.get(OPTION_PRODUCT_PRICE);
					if(optionProductPrice != null && !optionProductPrice.isEmpty())
					{   
						ps.setDouble(11, Double.parseDouble(optionProductPrice));
					}
					else
					{
						ps.setNull(11,Types.DOUBLE);
					}
							        
					ps.setBoolean(12, true);	// is_active	
					
					Boolean isLoggedInUser = (Boolean)input.get(IS_LOGGED_IN);
					if(isLoggedInUser != null)
					{
					  ps.setBoolean(13, isLoggedInUser);
					}
					else
					{
						ps.setBoolean(13, false);
					}
										
					String visitorId = (String)input.get(VISITOR_ID);
					if(visitorId != null && !visitorId.isEmpty())
					{
					  ps.setString(14, visitorId);
					}
					else
					{
						ps.setNull(14, Types.VARCHAR);
					}
					
					String visitorTime = (String)input.get(VISIT_TIME);
					if(visitorTime != null && !visitorTime.isEmpty())
					{
					  ps.setString(15, visitorTime);
					}
					else
					{
						ps.setNull(15, Types.VARCHAR);
					}
					
					String referralUrl = (String)input.get(REFERRAL_URL);
					if(referralUrl != null && !referralUrl.isEmpty())
					{
					  ps.setNString(16, referralUrl);
					}
					else
					{
						ps.setNull(16, Types.NVARCHAR);
					}
													
					String userAgent = (String)input.get(USER_AGENT);
					if(userAgent != null && !userAgent.isEmpty())
					{
					  ps.setNString(17, userAgent);
					}
					else
					{
						ps.setNull(17, Types.NVARCHAR);
					}
					
					/*String userIP = (String)input.get(USER_IP);
					if(userIP != null && !userIP.isEmpty())
					{
					  ps.setString(18, userIP.trim());
					}
					else
					{
						ps.setNull(18, Types.VARCHAR);
					}	*/				
									
					ps.setInt(18, (Integer)input.get(PLATFORM_ID));
					ps.setInt(19, (Integer)input.get(CLIENT_ID));
										
					ps.execute();
					return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertAddToCartTracking" , "Error Occured while inserting cart data.." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertAddToCartTracking.java runService()", "Error occured while inserting cart data.", ex.getMessage());
			return false;
		}
	}
}