package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class DeleteProductData implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(DeleteProductData.class.getClass());
	
	private static DeleteProductData instance = null;
	
	private DeleteProductData()
	{
		
	}

	public static DeleteProductData getInstance()
	{
		if (instance == null)
		{
			instance = new DeleteProductData();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Delete_Product_Data(?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			
			String productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
					
			cStmt.execute();
					
			return 1;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "DeleteProductData" , "Error Occured while deleting product." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteProductData.java runService()", "Error occured while while deleting product..", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteProductData.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
		return 0;
	}
}