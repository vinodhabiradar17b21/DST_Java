package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import java.sql.PreparedStatement;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class BulkInsertOrderItemsData implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BulkInsertOrderItemsData.class.getClass());
	Map<String, List<Map<String,Object>>> orderItemList = new HashMap<String, List<Map<String,Object>>>();
	
	public void addItemList(String orderId,List<Map<String,Object>> itemList)
	{
		this.orderItemList.put(orderId,itemList);
	}
			
	public Boolean runService(Map<String,Object> input) 
	{
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
		
		String queryTmpl = "INSERT INTO order_item_details_temporary_storage"
				+ "(client_id,platform_id,client_order_id,product_id,product_name,product_price,product_url,product_sku"
				+",product_type,quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)";

		final int batchSize = 5000; //Integer.parseInt(AirFrameProperties.fetch("batchSize"));
        final Integer clientId = (Integer)input.get(CLIENT_ID);
        final Integer platformId = (Integer)input.get(PLATFORM_ID);
        
        Integer isBulkOrderProcessing = 1;
		
		if(input.get(ORDER_DATA_IS_BULK_PROCESSING) != null)
		{
			isBulkOrderProcessing = (Integer)input.get(ORDER_DATA_IS_BULK_PROCESSING);
		}
		
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for (Map.Entry<String, List<Map<String,Object>>> entry : orderItemList.entrySet())
					{
						String orderId = entry.getKey();
						List<Map<String,Object>> itemList = entry.getValue();
												
						String productId = null;
										
						for (Map<String,Object> item :itemList)
						{
							productId = (String)item.get(PRODUCT_ID);
																				
						    ps.setInt(1, clientId);
						    
						    if(platformId != null)
						    {
						    	ps.setInt(2, platformId);
						    }
						    else
						    {
						    	ps.setInt(2, 1);
						    }
						    
							ps.setNString(3, orderId);
							ps.setBytes(4, productId.getBytes());
							
							if(item.get(PRODUCT_NAME) != null && !item.get(PRODUCT_NAME).toString().isEmpty())
							{
							   ps.setNString(5, (String)item.get(PRODUCT_NAME));
							}
							else
							{
							   ps.setNull(5,Types.NVARCHAR);
							}
							
							if(item.get(PRODUCT_PRICE) != null && !item.get(PRODUCT_PRICE).toString().isEmpty())
							{
								ps.setDouble(6, Double.parseDouble((String)item.get(PRODUCT_PRICE)));
							}
							else
							{
								ps.setNull(6,Types.DECIMAL);
							}
							
							if(item.get(PRODUCT_URL) != null && !item.get(PRODUCT_URL).toString().isEmpty())
							{
								ps.setNString(7, (String)item.get(PRODUCT_URL));
							}
							else
							{
								ps.setNull(7,Types.NVARCHAR);
							}
							
							if(item.get(PRODUCT_SKU) != null && !item.get(PRODUCT_SKU).toString().isEmpty())
							{
								ps.setNString(8, (String)item.get(PRODUCT_SKU));
							}
							else
							{
								ps.setNull(8,Types.NVARCHAR);
							}												
														
							if(item.get(PRODUCT_TYPE) != null && !item.get(PRODUCT_TYPE).toString().isEmpty())
							{
								ps.setNString(9, (String)item.get(PRODUCT_TYPE));
							}
							else
							{
								ps.setNull(9,Types.NVARCHAR);
							}
							
							if(item.get(QUANTITY) != null)
							{
								ps.setInt(10, (Integer)item.get(QUANTITY));
							}
							else
							{
								ps.setInt(10,1);
							}			
																	
							ps.addBatch();
						}
					
						if (++count % batchSize == 0)
						{
							ps.executeBatch();
						}
					}
					
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}		
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BulkInsertOrderItemsData" , "Error Occured while importing order item details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("BulkInsertOrderItemsData.java runService()", "Error occured while importing order item details.", ex.getMessage());
						
			if(isBulkOrderProcessing == 1)
			{
				ErrorLog.saveErrorLogToDB("BulkInsertOrderItems", "Client Id - " + clientId +" Error Occured while importing order item details.",  ex.getMessage());
				DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
				deleteTemporaryStorageData.deleteTemporaryOrderItemDetails(input);
			}
			else
			{
				String clientOrderId = (String)input.get(ORDER_ID);
				ErrorLog.saveErrorLogToDB("BulkInsertOrderItems", "Client Id - " + clientId +" , Client Order Id" + clientOrderId +" Error Occured while importing order item details.",  ex.getMessage());
				DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
				deleteTemporaryStorageData.deleteTemporaryIndividualOrderItemDetails(input);
			}
			return false;
		}
	}
	
	
}