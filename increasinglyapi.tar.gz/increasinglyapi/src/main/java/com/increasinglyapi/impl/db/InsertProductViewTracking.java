package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertProductViewTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertProductViewTracking.class.getClass());
	
	public Boolean runService(final Map<String, Object> input) 
	{
	         
       JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
		        
	   String queryTmpl = "INSERT INTO product_view_tracking"
		 + "(product_id,product_price,product_sku,visitor_id,visit_time,referral_url,user_agent,platform_id,client_id)"
		 + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){
	
				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {
							
					if(input.get(PRODUCT_ID) != null)
					{
					    String productId = (String)input.get(PRODUCT_ID);
					    
					    if(productId.length() > 64 )
					    {
					    	productId = productId.substring(0, 64);
					    }
					    
					    ps.setBytes(1, productId.getBytes());
					  
					    String productPrice = (String)input.get(PRODUCT_PRICE);
						if(productPrice != null && !productPrice.isEmpty())
						{   
							ps.setDouble(2, Double.parseDouble(productPrice));
						}
						else
						{
							ps.setNull(2,Types.DOUBLE);
						}
					    
					    ps.setNString(3, (String)input.get(PRODUCT_SKU));
						ps.setString(4, (String)input.get(VISITOR_ID));
						ps.setString(5, (String)input.get(VISIT_TIME));								
						ps.setNString(6, (String)input.get(REFERRAL_URL));
						ps.setNString(7, (String)input.get(USER_AGENT));
						//ps.setString(8, (String)input.get(USER_IP));					
						ps.setInt(8, (Integer)input.get(PLATFORM_ID));
						ps.setInt(9, (Integer)input.get(CLIENT_ID));
										
						ps.execute();
						return true;
					}
					else
					{
						return false;
					}
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertProductViewTracking" , "Error Occured while inserting product data view tracking data." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertProductViewTracking.java runService()", "Error occured while inserting product data view tracking data.", ex.getMessage());
			return false;
		}
	}
	
}