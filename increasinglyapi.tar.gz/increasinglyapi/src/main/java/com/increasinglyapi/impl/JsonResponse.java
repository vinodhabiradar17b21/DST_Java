package com.increasinglyapi.impl;

public class JsonResponse
{
	/** http status code */
	Integer statusCode;

	/** indicates status - fail or error
	 *
	 * fail - will be used when an validation error or bad request occurs
	 *      - will be used when an server exception occurs
	 */
	String status;

	/** Service response data */
	Object data;

	/** message describing the error */
	String errorMessage;

	/**
	 * @return statusCode
	 */
	public int getStatusCode()
	{
		return statusCode;
	}

	/**
	 * @param statusCode
	 */
	public void setStatusCode(int statusCode)
	{
		this.statusCode = statusCode;
	}

	/**
	 * @return status
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * @return data
	 */
	public Object getData()
	{
		return data;
	}

	/**
	 * @param data
	 */
	public void setData(Object data)
	{
		this.data = data;
	}

	/**
	 * @return errorMessage
	 */
	public String getErrorMessage()
	{
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public JsonResponse()
	{
	}

	/**
	 * 
	 * @param statusCode
	 * @param status
	 * @param data
	 * @param errorMessage
	 */
	public JsonResponse(int statusCode, String status, Object data, String errorMessage)
	{
		this.statusCode = statusCode;
		this.status = status;
		this.data = data;
		this.errorMessage = errorMessage;
	}
}