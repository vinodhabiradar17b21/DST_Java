package com.increasinglyapi.impl;

import static com.increasinglyapi.utils.Constants.*;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.impl.db.BulkInsertOrderItemsAttributeData;
import com.increasinglyapi.impl.db.BundleOrderConfirmationTrackingImpl;
import com.increasinglyapi.impl.db.ErrorLog;
import com.increasinglyapi.impl.db.InsertOrderItemAttributesData;
import com.increasinglyapi.impl.db.SaveOrderData;
import com.increasinglyapi.impl.db.SaveOrderItemDetails;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class OrderPixelImpl
{
	private static final Logger logger = LoggerFactory.getLogger(OrderPixelImpl.class.getClass());
	
	public void processOrderConfirmation(TrackRequest trackRequest)
	{
		
		 Integer clientId = 0;
		 String cookieVisitorId = "";
		 String clientOrderId = ""; 
					 
		 String orderStatus = "";
		 String currencyCode = "";
		 String customerEmail = "";			
		 String couponCode = "";			
		 String paymentMethod = "";
		 String storeCode = "";
		 
		 try
         { 
			 			
			 ArrayList<Map<String,Object>> itemAttributeList = new ArrayList<Map<String,Object>>();
			 
			 if(trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID) != null)
		     {
		       	 cookieVisitorId = trackRequest.getCookieList().get(INCREASINGLY_VISITOR_ID).getValue();
		     }		           	
		       
             if (trackRequest.getQueryStringParameter("ClientID") != null && 
            		 trackRequest.getQueryStringParameter("ClientID").length() != 0)
             {
            	 clientId = Integer.parseInt(trackRequest.getQueryStringParameter("ClientID"));
             }
             else if(trackRequest.getQueryStringParameter("clientId") != null && 
            		 trackRequest.getQueryStringParameter("clientId").length() != 0)
             {
            	 clientId = Integer.parseInt(trackRequest.getQueryStringParameter("clientId"));
             }
            
             if(trackRequest.getQueryStringParameter("OrderID") != null &&
            		 trackRequest.getQueryStringParameter("OrderID").length() != 0)
             {
            	 clientOrderId = trackRequest.getQueryStringParameter("OrderID");
             }	
             else if(trackRequest.getQueryStringParameter("orderId") != null &&
            		 trackRequest.getQueryStringParameter("orderId").length() != 0)
             {
            	 clientOrderId = trackRequest.getQueryStringParameter("orderId");
             }	
             
             // Fixed to solve mismatch with conversion pixel being fired.
             if(clientId == 23)
             {
            	 clientId = 17;
             }
           
             if (clientId <= 0)
             {
            	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processOrderConfirmation" , "ClientId Not Found OR Sent." , "");
     			 logger.error(errorMessage);             
                 return;
             }
             
             if(clientOrderId.isEmpty())
             {
            	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processOrderConfirmation" , "ClientOrderIdNotSent" , "");
     			 logger.error(errorMessage);             
                 return;
             }
             
             if (trackRequest.getQueryStringParameter("storeCode") != null && trackRequest.getQueryStringParameter("storeCode").length() != 0)
             {
              	 storeCode = trackRequest.getQueryStringParameter("storeCode");            	 
             }
                           
             if(clientId==26)
             {
               clientId = setClientIdFor7FAMCountries(storeCode);
             }
             if(clientId==42)
             {
               clientId = setClientIdForWorldSimCountries(storeCode);
             }
             if(clientId==49)
             {
               clientId = setClientIdForReissCountries(storeCode);
             }
             
             Map<String,Object> input = new HashMap<String,Object>();
     		 input.put(CLIENT_ID, clientId);
     		 input.put(ORDER_ID, clientOrderId);     		 
     		 input.put(ORDER_DATA_IS_BULK_PROCESSING, 0);
     		 input.put(VISITOR_ID, cookieVisitorId);
     		 input.put(INCREASINGLY_VISITOR_ID, cookieVisitorId);
     		
     		 if(!cookieVisitorId.isEmpty())
     		 {
	     		 BundleOrderConfirmationTrackingImpl bundleOrderConfirmationTrackingImpl = BundleOrderConfirmationTrackingImpl.getInstance();
	     		 Integer isBundleOrderTrackingSuccessful = bundleOrderConfirmationTrackingImpl.runService(input);
	     		
	     		 if(isBundleOrderTrackingSuccessful == 1)
	     		 {
	     		 	logger.info(LOG_INFO + "Bundle order tracking is completed successfully for client order id - " + clientOrderId + " client id - " + clientId + " Increasingly Visitor Id - "+ cookieVisitorId);
	     		 }
	     		 else
	     		 {
	     			 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "processOrderConfirmation" , "FailedToTrackBundleOrder" , "");
	     			 logger.error(errorMessage + "Bundle order tracking failed for the client order id - " + clientOrderId + " client id - " + clientId + " Increasingly Visitor Id - "+ cookieVisitorId);
	     		 }
     		 }
     		 else
     		 {		     			
   		    	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "processOrderConfirmation" , "Cannot track bundle order - Increasingly Visitor is NULL");
   	 			 logger.error(errorMessage);
     		 }
     		 
             //BulkInsertOrderItemsData insertOrderItemsData = new BulkInsertOrderItemsData();
             SaveOrderItemDetails saveOrderItemDetails =new SaveOrderItemDetails();
	     		     	 
	     // List<Map<String,Object>> orderList = new ArrayList<Map<String,Object>>();
             Map<String,Object> orderDetails = new HashMap<String,Object>();
             		                          
             orderDetails.put(ORDER_TIME,DateTime.now().toString("y-M-d H:m:s"));
             orderDetails.put(USER_AGENT,trackRequest.getUserAgent());
/*             orderDetails.put(USER_IP,trackRequest.getUserIpAddress());
*/                   
             if (trackRequest.getQueryStringParameter("orderAmount") != null && 
            		 trackRequest.getQueryStringParameter("orderAmount").length() != 0)
             {		            
            	 orderDetails.put(ORDER_AMOUNT, trackRequest.getQueryStringParameter("orderAmount"));
             }
            
             if (trackRequest.getQueryStringParameter("orderStatus") != null && 
            		 trackRequest.getQueryStringParameter("orderStatus").length() != 0)
             {
            	 orderStatus = trackRequest.getQueryStringParameter("orderStatus");
            	 orderDetails.put(ORDER_STATUS, orderStatus);
             }
             
             if (trackRequest.getQueryStringParameter("currency") != null && 
            		 trackRequest.getQueryStringParameter("currency").length() != 0)
             {
            	 currencyCode = trackRequest.getQueryStringParameter("currency");
            	 orderDetails.put(CURRENCY_CODE, currencyCode);
             }             
                         
             if (trackRequest.getQueryStringParameter("discountAmount") != null && 
            		 trackRequest.getQueryStringParameter("discountAmount").length() != 0)
             {		            	
            	 orderDetails.put(DISCOUNT_AMOUNT, trackRequest.getQueryStringParameter("discountAmount"));
             }
             
             if (trackRequest.getQueryStringParameter("couponCode") != null && 
            		 trackRequest.getQueryStringParameter("couponCode").length() != 0)
             {
            	 couponCode = trackRequest.getQueryStringParameter("couponCode");
            	 orderDetails.put(COUPON_CODE, couponCode);
             }             
             
             if (trackRequest.getQueryStringParameter("paymentMethod") != null && 
    		 trackRequest.getQueryStringParameter("paymentMethod").length() != 0)
           	 {
            	 paymentMethod = trackRequest.getQueryStringParameter("paymentMethod");
            	 orderDetails.put(PAYMENT_METHOD, paymentMethod);
           	 }
                         
             input.putAll(orderDetails);
             //orderList.add(orderDetails);
                         
             SaveOrderData saveOrder= new SaveOrderData();
             Boolean hasOrderDetailsSaved = false;
     		
	         if(input.size() > 0)
	         {			   
	        	 hasOrderDetailsSaved = saveOrder.runService(input);
	         }
	         else
	         {
	        	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "Issue occured while inserting order details for the client id -" + clientId + " client order id - "+ clientOrderId , trackRequest.getQueryString());
     			 logger.error(errorMessage,"");
	         }
             
             try
             {
            	if(hasOrderDetailsSaved)
    			{
		               if (trackRequest.getQueryStringParameter("productsInfo") != null && 
		            		 trackRequest.getQueryStringParameter("productsInfo").length() != 0)
		               {
		            		            	 
		            	  String productInfo = URLDecoder.decode(trackRequest.getQueryStringParameter("productsInfo"));
		            	 
		            	  if(!productInfo.isEmpty())
		            	  {
			            	 if(clientId == 15)
			            	 {
			            		 productInfo = productInfo.replace("p1", "|p1");
			            		 productInfo = productInfo.substring(1);
			            	 }
			            	 
			            	 String[] productItems = productInfo.split("\\|"); 		            	 
			            	 
			            	 for(String item: productItems)
			            	 { 
			            		 String[] itemDetails = item.split("&");
			            		 String productId = "";
			            		 Map<String,Object> tempItem = new HashMap<String,Object>();
			            		 
			            		 tempItem.put(CLIENT_ID,input.get(CLIENT_ID));
			            		 tempItem.put(ORDER_ID,input.get(ORDER_ID));
			            		 tempItem.put(VISITOR_ID,input.get(VISITOR_ID));
			            		 
			            		 if(itemDetails.length > 0)
			            		 {
				            		 for(String details: itemDetails)
				            		 {
				            			 if(details.split("=").length > 1)
				            			 {
					            			 String parameterName = details.split("=")[0];
					            			 String parameterValue = details.split("=")[1];
					            			 
					            			 if(parameterName.equals("p1"))
					            			 {
					            				 productId = parameterValue;
					            				 tempItem.put(PRODUCT_ID, parameterValue);
					            			 }
					            			 else  if(parameterName.equals("p2"))
					            			 {
					            				 tempItem.put(PRODUCT_PRICE,parameterValue);
					            			 }
					            			 else  if(parameterName.equals("p3"))
					            			 {			
					            				 Double number = Double.parseDouble(parameterValue);
					            				 int paramValue = number.intValue();
					            				 tempItem.put(QUANTITY, paramValue);
					            				 
					            				 //tempItem.put(QUANTITY, Integer.parseInt(parameterValue));
					            			 }
					            			 else  if(parameterName.equals("p4"))
					            			 {
					            				 tempItem.put(PRODUCT_SKU, parameterValue);
					            			 }
					            			 else  if(parameterName.equals("p5"))
					            			 {					            				
					            				 String[] attributeOptionList = URLDecoder.decode(parameterValue).split("\\|");						            				 
					            				 	            				 
					            				 for(String attributeOption: attributeOptionList)
					            				 {
					            					 if(!attributeOption.isEmpty())
					            					 {
					            						 String[] attributeOptionValue = attributeOption.split("&");
					            						 
					            						 Map<String,Object> itemAttributes = new HashMap<String,Object>();
					            						 itemAttributes.put(PRODUCT_ID, productId);
					            						 
					            						 for(String attributeItem : attributeOptionValue)
					            						 {
					            							 if(attributeItem.split("=").length > 1)
					            							 {						            							 
						            							 String paramName = attributeItem.split("=")[0];
										            			 String paramValue = attributeItem.split("=")[1];
										            			 
										            			 if(paramName.equals("a1"))
										            			 {
										            				 itemAttributes.put(ATTRIBUTE_ID, paramValue);
										            			 }
										            			 else if(paramName.equals("a2"))
										            			 {
										            				 itemAttributes.put(ATTRIBUTE_CODE, paramValue);
										            			 }
										            			 else if(paramName.equals("o1"))
										            			 {
										            				 itemAttributes.put(OPTION_ID, paramValue);
										            			 }
										            			 else if(paramName.equals("o2"))
										            			 {
										            				 itemAttributes.put(OPTION_TEXT, paramValue);
										            			 }
					            							 }
									            			 
					            						 }
					            						 itemAttributes.put(QUANTITY, tempItem.get(QUANTITY));
					            						 itemAttributeList.add(itemAttributes);
					            					 }
					            				 }
					            			 }	
				            			 }
				            		 }
				            		
				            		 if(tempItem.size() > 0)
					            	 {
					            		 logger.info(LOG_APPLICATION_FLOW + "Order item data processing has started.");
					            		 Boolean hasOrderItemSaved = saveOrderItemDetails.runService(tempItem);
					            		 
					            		 if(!hasOrderItemSaved)
					            		 {
					            			 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "Issue occured while inserting order item details for the client id -" + clientId + " client order id - "+ clientOrderId + " product id -" + productId, trackRequest.getQueryString());
					             			 logger.error(errorMessage,"");	 
					            		 }
					            		 
					            		 logger.info(LOG_APPLICATION_FLOW + "Order item data processing completed.");
					            	 } 			            	
			            		   
			            		 }
			            	 }
							
		            	 }
		             }
		             else
		             {
		            	 Map<String,Object> tempItem = new HashMap<String,Object>();
		            	 
		            	 tempItem.put(CLIENT_ID,input.get(CLIENT_ID));
	            		 tempItem.put(ORDER_ID,input.get(ORDER_ID));
	            		 tempItem.put(VISITOR_ID,input.get(VISITOR_ID));
	            		 
	            		 String productId = "";
	            	 
		            	 if (trackRequest.getQueryStringParameter("p1") != null && 
		                		 trackRequest.getQueryStringParameter("p1").length() != 0)
		                 {
		            		 productId = trackRequest.getQueryStringParameter("p1");
		            		 tempItem.put(PRODUCT_ID, productId);	                	
		                 }
		            	 
		            	 if (trackRequest.getQueryStringParameter("p2") != null && 
		                		 trackRequest.getQueryStringParameter("p2").length() != 0)
		                 {
		            		 tempItem.put(PRODUCT_PRICE, trackRequest.getQueryStringParameter("p2"));	                	
		                 }
		            	 
		            	 if (trackRequest.getQueryStringParameter("p3") != null && 
		                		 trackRequest.getQueryStringParameter("p3").length() != 0)
		                 {
		            		 tempItem.put(QUANTITY, Integer.parseInt(trackRequest.getQueryStringParameter("p3")));	                	
		                 }
		            	 
		            	 if (trackRequest.getQueryStringParameter("p4") != null && 
		                		 trackRequest.getQueryStringParameter("p4").length() != 0)
		                 {
		            		 tempItem.put(PRODUCT_SKU, trackRequest.getQueryStringParameter("p4"));	                	
		                 }
		            	 
		            	 if(tempItem.size() > 0)
		            	 {
		            		 Boolean hasOrderItemSaved = saveOrderItemDetails.runService(tempItem);
		            		 
		            		 if(!hasOrderItemSaved)
		            		 {
		            			 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "Issue occured while inserting order item details for the client id -" + clientId + " client order id - "+ clientOrderId + " product id -" + productId, trackRequest.getQueryString());
		             			 logger.error(errorMessage,"");	 
		            		 }	            	 	
		            	 }	            	 
		            	
		             }
    			 }
	             
             }
             catch(Exception ex)
             {
            	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "Issue occured while inserting order item details for the client id -" + clientId + " client order id - "+ clientOrderId, trackRequest.getQueryString());
     			 logger.error(errorMessage,ex.getMessage());    
             }
            							
			 BulkInsertOrderItemsAttributeData orderItemAttributeDetails = new BulkInsertOrderItemsAttributeData();
			 input.put(ITEM_ATTRIBUTE_LIST, itemAttributeList);
			 orderItemAttributeDetails.runService(input);
					
			 if(hasOrderDetailsSaved)
			 {				
				InsertOrderItemAttributesData insertOrderItemAttributeData = InsertOrderItemAttributesData.getInstance();
				Integer hasOrderItemAttributeDataSaved = insertOrderItemAttributeData.runService(input);
				
				if(hasOrderItemAttributeDataSaved == 1)
					logger.info(LOG_APPLICATION_FLOW + "Order data processing completed successfully.");
				else
					logger.info(LOG_APPLICATION_FLOW + "Order data processing completed successfully, but failed to insert order item attribute details.");
					
				
			  }
           
         }
         catch (Exception ex)
         {
        	 String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "OrderPixelImpl" , "OrderConfirmationPixelIssue" , "Error occured while tracking order for the client id - " + clientId + " client order id - " + clientOrderId + " visitor id - " + cookieVisitorId);
 			 logger.error(errorMessage,ex.getMessage());  
 			 ErrorLog.saveErrorLogToDB("OrderPixlImpl.java", "Client Id - " + clientId + " Client Order Id - " + clientOrderId + " visitor id - "+ cookieVisitorId +" Error occured while tracking order data.",  ex.getMessage());
         }
	}

	private Integer setClientIdFor7FAMCountries(String storeCode) {
		
		Integer clientId = 0;
		
		if(storeCode.equalsIgnoreCase("en_en"))
		{
			clientId = 26;
		}
		
		if(storeCode.equalsIgnoreCase("be_de"))
		{
			clientId = 30;
		}
		
		if(storeCode.equalsIgnoreCase("be_en"))
		{
			clientId = 31;
		}
		
		if(storeCode.equalsIgnoreCase("be_fr"))
		{
			clientId = 32;
		}
		
		if(storeCode.equalsIgnoreCase("be_nl"))
		{
			clientId = 33;
		}
		
		if(storeCode.equalsIgnoreCase("de_de"))
		{
			clientId = 34;
		}
		
		if(storeCode.equalsIgnoreCase("eu_de"))
		{
			clientId = 35;
		}
		
		if(storeCode.equalsIgnoreCase("eu_en"))
		{
			clientId = 36;
		}
		
		if(storeCode.equalsIgnoreCase("eu_es"))
		{
			clientId = 37;
		}
		
		if(storeCode.equalsIgnoreCase("eu_fr"))
		{
			clientId = 38;
		}
		
		if(storeCode.equalsIgnoreCase("fr_fr"))
		{
			clientId = 39;
		}
		
		if(storeCode.equalsIgnoreCase("it_it"))
		{
			clientId = 40;
		}
		
		if(storeCode.equalsIgnoreCase("nl_nl"))
		{
			clientId = 41;
		}
		
		return clientId;
	}
	
private Integer setClientIdForWorldSimCountries(String storeCode) {
		
		Integer clientId = 0;
		
		if(storeCode.equalsIgnoreCase("gb"))
		{
			clientId = 42;
		}
		
		if(storeCode.equalsIgnoreCase("aus"))
		{
			clientId = 43;
		}
		
		if(storeCode.equalsIgnoreCase("eu"))
		{
			clientId = 44;
		}
		
		if(storeCode.equalsIgnoreCase("india"))
		{
			clientId = 45;
		}
		
		if(storeCode.equalsIgnoreCase("sa"))
		{
			clientId = 46;
		}
		
		if(storeCode.equalsIgnoreCase("usa"))
		{
			clientId = 47;
		}
		return clientId;
	}
/**
 * @client:- REISS
 * @param storeCode
 * @return clientId
 */
private Integer setClientIdForReissCountries(String storeCode) {
	
	Integer clientId = 0;
	
	if(storeCode.equalsIgnoreCase("uk"))
	{
		clientId = 49;
	}
	
	if(storeCode.equalsIgnoreCase("au"))
	{
		clientId = 50;
	}
	
	if(storeCode.equalsIgnoreCase("ca"))
	{
		clientId = 51;
	}
	
	if(storeCode.equalsIgnoreCase("de"))
	{
		clientId = 52;
	}
	
	if(storeCode.equalsIgnoreCase("eu"))
	{
		clientId = 53;
	}
	
	if(storeCode.equalsIgnoreCase("fr"))
	{
		clientId = 54;
	}
	if(storeCode.equalsIgnoreCase("hk"))
	{
		clientId = 55;
	}
	
	if(storeCode.equalsIgnoreCase("ie"))
	{
		clientId = 56;
	}
	
	if(storeCode.equalsIgnoreCase("rw"))
	{
		clientId = 57;
	}
	
	if(storeCode.equalsIgnoreCase("us"))
	{
		clientId = 58;
	}
	return clientId;
  }
}