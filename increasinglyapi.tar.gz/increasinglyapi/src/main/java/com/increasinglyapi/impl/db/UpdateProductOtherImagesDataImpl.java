package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class UpdateProductOtherImagesDataImpl implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateProductOtherImagesDataImpl.class.getClass());
	
	private static UpdateProductOtherImagesDataImpl instance = null;
	
	private UpdateProductOtherImagesDataImpl()
	{
		
	}

	public static UpdateProductOtherImagesDataImpl getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateProductOtherImagesDataImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId = (Integer)input.get(FEED_ID);
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Product_Other_Images_Data(?, ?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			
			String productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			
			Boolean hasOtherImages = (Boolean)input.get(HAS_OTHER_IMAGES);
			cStmt.setBoolean(3, hasOtherImages);
			
			cStmt.registerOutParameter(4, Types.INTEGER);
			
			cStmt.execute();
			
			Integer result = cStmt.getInt("Result");
			
			return result;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateProductOtherImagesDataImpl" , "Error Occured while updating product other image details." ,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryProductOtherImageDetails(input);
			
			ErrorLog.saveErrorLogToDB("UpdateProductOtherImagesDataImpl.java", "Feed Id - " + feedId  +" Error Occured while updating product other image details to main table.",  ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return 0;
	}
}