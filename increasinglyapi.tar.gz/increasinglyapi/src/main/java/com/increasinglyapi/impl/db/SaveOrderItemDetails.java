package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;

public class SaveOrderItemDetails  extends StoredProcedure implements ServiceInterface<Boolean>
{
	
	private final static String dataSourceLookupName = "mysqlserver";	
	private static final String SPROC_NAME = "Save_Order_Item_Details";
	
	private static SaveOrderItemDetails instance = null;
	
	public SaveOrderItemDetails()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ProductId", Types.VARBINARY));		
		declareParameter(new SqlParameter("ProductPrice", Types.DECIMAL));		
		declareParameter(new SqlParameter("ProductSku", Types.VARCHAR));		
		declareParameter(new SqlParameter("Qty", Types.INTEGER));
		declareParameter(new SqlParameter("ClientOrderId", Types.VARCHAR));
		declareParameter(new SqlParameter("ClientId", Types.INTEGER));
		declareParameter(new SqlParameter("VisitorId", Types.VARCHAR));	
		declareParameter(new SqlOutParameter("result", Types.INTEGER));
		compile();		
	}
	
	public static SaveOrderItemDetails getInstance()
	{
		if (instance == null)
		{
			instance = new SaveOrderItemDetails();
		}
		return instance;
	}


	@Override
	public Boolean runService(Map<String, Object> input) throws Exception {
		
		String productId = (String) input.get(PRODUCT_ID);
		
		Double productPrice = null;
		if(input.get(PRODUCT_PRICE) != null && !input.get(PRODUCT_PRICE).toString().isEmpty())
		{
			productPrice =  Double.parseDouble((String)input.get(PRODUCT_PRICE));
		}
		
		
		String productSku = null;
		if(input.get(PRODUCT_SKU) != null && !input.get(PRODUCT_SKU).toString().isEmpty())
		{
			productSku = ((String)input.get(PRODUCT_SKU));
		}
			
	
		Integer quantity = null;
		if(input.get(QUANTITY) != null)
		{
			quantity = ((Integer)input.get(QUANTITY));
		}
		else
		{
			quantity = null;
		}		
		
		String visitorId = null;
		if(input.get(VISITOR_ID) != null && !input.get(VISITOR_ID).toString().isEmpty())
		{
			visitorId = ((String)input.get(VISITOR_ID));	
		}
		
		String clientOrderId = (String) input.get(ORDER_ID);
		Integer clientId = (Integer) input.get(CLIENT_ID);
		
				
		Map<String, Object> results = execute(productId.getBytes(),productPrice,productSku,quantity,clientOrderId,clientId,visitorId);
	
		if (!(results.get("result") == null))
		{
			return true;
		}
		else
		{
			return false;			
		}	
	}
	
	
	
	
}