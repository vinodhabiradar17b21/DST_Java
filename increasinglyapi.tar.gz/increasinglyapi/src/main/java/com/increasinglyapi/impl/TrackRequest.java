package com.increasinglyapi.impl;


import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.core.Cookie;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.base.Strings;
import com.increasinglyapi.utils.FormatLoggerMessage;

import static com.increasinglyapi.utils.Constants.*;

public class TrackRequest
{
	private static final Logger logger = LoggerFactory.getLogger(TrackRequest.class.getClass());
	private Boolean isNewUser = true;
	private Boolean hasVisitorId = false;
	private UUID visitorId = UUID.randomUUID();
	private Map<String, Cookie> cookieList = new HashMap<String,Cookie>();
	
	private Boolean requireDecoding = true;
	private Boolean requireLoadingCookies = false;
	private Boolean isSecure = false;

	private Integer trackType = 0;
	private String queryString = "";
	private String queryStringSeparator = "&";
	private String parameters = "";
	private Map<String, String> parameterCollection;

	private String userIpAddress = "";
	private String userAgent = "";
	private String userHost = "";
	private String referralURL = "";
	
	private String protocol = "";
	private String increasinglyVisitorId = "";

	public TrackRequest()
	{
	}
	
	public String getIncreasinglyVisitorId() {
		return increasinglyVisitorId;
	}

	public void setIncreasinglyVisitorId(String increasinglyVisitorId) {
		this.increasinglyVisitorId = increasinglyVisitorId;
	}
	
	public Boolean getIsNewUser() {
		return isNewUser;
	}
	public void setIsNewUser(Boolean isNewUser) {
		this.isNewUser = isNewUser;
	}
	public Boolean getHasVisitorId() {
		return hasVisitorId;
	}
	public void setHasVisitorId(Boolean hasVisitorId) {
		this.hasVisitorId = hasVisitorId;
	}
	public UUID getVisitorId() {
		return visitorId;
	}
	public void setVisitorId(UUID visitorId) {
		this.visitorId = visitorId;
		this.isNewUser = false;
	}
	public Map<String, Cookie> getCookieList() {
		return cookieList;
	}
	public void setCookieList(Map<String, Cookie> cookieList) {
		this.cookieList = cookieList;
	}
	
	/**
	 * @return trackType
	 */
	public Integer getTrackType()
	{
		return this.trackType;
	}
	
	/**
	 * @param trackType
	 */
	public void setTrackType(Integer trackType)
	{
		this.trackType = trackType;
	}
	
	/**
	 * @return QueryString
	 */
	public String getQueryString()
	{
		return this.queryString;
	}

	/**
	 * @param queryStringWithParams
	 */
	public void setQueryString(String queryStringWithParams)
	{
		this.queryString = queryStringWithParams;
	}

	public String getQueryStringParameter(String name)
	{
		return getQueryStringParameter(name,"");
	}

	public String getQueryStringParameter(String name, String defaultValue)
	{
		String value = parameterCollection.get(name);
		if (Strings.isNullOrEmpty(value))
		{
			value = defaultValue;
		}
		return value;
	}

	/**
	 * @return
	 */
	public String getParameters()
	{
		return this.parameters;
	}

	/**
	 * @param parameters
	 */
	public void setParameters(String parameters)
	{
		this.parameters = parameters;
	}
	
	/**
	 * @return
	 */
	public Boolean getIsSecure()
	{
		return this.isSecure;
	}

	/**
	 * @param isSecure
	 */
	public void setIsSecure(Boolean isSecure)
	{
		this.isSecure = isSecure;
	}

	/**
	 * @return
	 */
	public String getProtocol()
	{
		return this.protocol;
	}

	/**
	 * @param protocol
	 */
	public void setProtocol(String protocol)
	{
		this.protocol = protocol;
	}

	/**
	 * @return the userIPAddress
	 */
	public String getUserIpAddress()
	{
		return userIpAddress;
	}

	/**
	 * @param userIpAddress
	 *            the userIPAddress to set
	 */
	public void setUserIpAddress(String userIpAddress)
	{
		this.userIpAddress = userIpAddress;
	}
	
	public void setUserAgent(String userAgent)
	{
		this.userAgent = userAgent;
	}
	
	public String getUserAgent()
	{
		return this.userAgent;
	}
	
	public void setUserHost(String userHost)
	{
		this.userHost = userHost;
	}
	
	public String getUserHost()
	{
		return this.userHost;
	}
	
	public void setReferralURL(String referralURL)
	{
		this.referralURL = referralURL;
	}
	
	public String getReferralURL()
	{
		return this.referralURL;
	}
	
	/**
	 * @param queryString
	 * @return
	 * @throws Exception
	 */
	public Boolean readAndValidateTrackRequest() 
	{
		try
		{
			if (Strings.isNullOrEmpty(queryString))
			{
				throw new Exception("No Query string");
			}

			// URL Encoded / (as %2F) fix
			if (queryString.indexOf("/") == -1 && (queryString.indexOf("%2F") > 7 || queryString.indexOf("%2f") > 7))
			{
				queryString = queryString.replace("%2F", "/");
				queryString = queryString.replace("%2f", "/");
			}
			if (queryString.indexOf("=") == -1 && (queryString.indexOf("%3D") > 7 || queryString.indexOf("%3d") > 7))
			{
				queryString = queryString.replace("%3D", "=");
				queryString = queryString.replace("%3d", "=");
			}

			if (queryString.indexOf("/") == -1 || queryString.indexOf("/") < 2)
			{
				throw new Exception("No Tracking Type Information");
			}

			switch (queryString.substring(0, queryString.indexOf("/")).toUpperCase())
			{
			case "CONVERSION_PIXEL":
				trackType = RequestType.CONVERSION_PIXEL;
				parameters = queryString.substring(17);			
				break;
			default:
				trackType = RequestType.INVALID;
				System.out.println("Invalid Request URL" + queryString + " -- Invalid Tracking Type");
				throw new Exception("Invalid Tracking Type");
			}

			
			if (Strings.isNullOrEmpty(parameters))
			{
				throw new Exception("Invalid parameters");
			}

		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "ValidateTrackRequest" , "Error validating request" , "");
			logger.error(errorMessage,ex.getMessage());
			return false;
		}
		
		return true;
	}

	public boolean decryptTrackRequest()
	{
		try
		{
			
			String[] params = parameters.split("&");
			parameterCollection = new HashMap<String, String>();

			for (String param : params)
			{
				String[] p = param.split("=");
				if(p.length >= 2)
				{
					parameterCollection.put(p[0], p[1]);
				}
			}
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Decryption error" , "Error decrypting request" , "");
			logger.error(errorMessage,ex);
			return false;			
		}		

		return true;
	}
	
	
	
}