package com.increasinglyapi.impl;

public class ClientDetailsParameters
{
	private String apiSecret = "";
	private int clientId = 0;	
	private String apiKey = "";
	
	public String getApiSecret()
	{
		return this.apiSecret;
	}
	
	public void setApiSecret(String apiSecret)
	{
		this.apiSecret = apiSecret;
	}
	
	public int getClientId()
	{
		return this.clientId;
	}
	
	public void setClientId(int clientId)
	{
		this.clientId = clientId;
	}
	
	public String getApiKey()
	{
		return this.apiKey;
	}
	
	public void setApiKey(String apiKey)
	{
		this.apiKey = apiKey;
	}
}