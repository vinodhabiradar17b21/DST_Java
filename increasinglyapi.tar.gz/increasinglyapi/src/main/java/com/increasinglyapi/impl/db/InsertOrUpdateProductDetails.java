package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertOrUpdateProductDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertOrUpdateProductDetails.class.getClass());
	
	private static InsertOrUpdateProductDetails instance = null;
	
	private InsertOrUpdateProductDetails()
	{
		
	}

	public static InsertOrUpdateProductDetails getInstance()
	{
		if (instance == null)
		{
			instance = new InsertOrUpdateProductDetails();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId = 0;
		String productId = "";
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Add_Or_Update_Product_Details(?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			feedId = (Integer)input.get(FEED_ID);
			
			productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			
			cStmt.setNString(3, (String) input.get(PRODUCT_NAME));		
			
			if(input.get(PRODUCT_SKU) != null && !input.get(PRODUCT_SKU).toString().isEmpty())
			{
				cStmt.setNString(4, (String) input.get(PRODUCT_SKU));
			}
			else
			{
				cStmt.setNull(4,Types.NVARCHAR);
			}
			
			cStmt.setNString(5, (String) input.get(PRODUCT_URL));
			
			if(input.get(IMAGE_URL) != null && !input.get(IMAGE_URL).toString().isEmpty())
			{
				cStmt.setNString(6, (String) input.get(IMAGE_URL));
			}
			else
			{
				cStmt.setNull(6,Types.NVARCHAR);
			}
			
			if(input.get(DESCRIPTION) != null && !input.get(DESCRIPTION).toString().isEmpty())
			{
				String description = "";
				
				if(input.get(DESCRIPTION).toString().length() >= 8000)
				{
					description = input.get(DESCRIPTION).toString().substring(0, 7995) + "...";								  
				}
				else
				{
					description = input.get(DESCRIPTION).toString();									
				}
				
				cStmt.setNString(7, description);
			}
			else
			{
				cStmt.setNull(7,Types.NVARCHAR);
			}
						
			if(input.get(PRODUCT_PRICE) != null && !input.get(PRODUCT_PRICE).toString().isEmpty())
			{   
				double price = Double.parseDouble((String) input.get(PRODUCT_PRICE));
				if(feedId == 18 || feedId == 19 || feedId == 20 || feedId == 21 || feedId == 22)
				{
					price = price + (price * 0.20);
				}
				
				cStmt.setDouble(8, price);
			}
			else
			{
				cStmt.setNull(8,Types.DOUBLE);
			}			
			
			if(input.get(SPECIAL_PRICE) != null && !input.get(SPECIAL_PRICE).toString().isEmpty())
			{   
				double specialPrice = Double.parseDouble((String) input.get(SPECIAL_PRICE));
				
				if(feedId == 18 || feedId == 19 || feedId == 20 || feedId == 21 || feedId == 22)
				{
					specialPrice = specialPrice + (specialPrice * 0.20);
				}
				
				cStmt.setDouble(9, specialPrice);
			}
			else
			{
				cStmt.setNull(9,Types.DOUBLE);
			}
			
			if(input.get(QUANTITY) != null)
			{
				cStmt.setInt(10, (Integer) input.get(QUANTITY));
			}
			else
			{
				cStmt.setNull(10,Types.INTEGER);
			}
			
			if(input.get(PRODUCT_TYPE) != null && !input.get(PRODUCT_TYPE).toString().isEmpty())
			{
				cStmt.setNString(11, (String)input.get(PRODUCT_TYPE));
			}
			else
			{
				cStmt.setNull(11,Types.NVARCHAR);
			}
						
			if(input.get(MANUFACTURER) != null && !input.get(MANUFACTURER).toString().isEmpty())
			{   
				cStmt.setNString(12, (String) input.get(MANUFACTURER));
			}
			else
			{
				cStmt.setNull(12,Types.NVARCHAR);
			}
						
			if(input.get(COLOR) != null && !input.get(COLOR).toString().isEmpty())
			{   
				cStmt.setNString(13, (String) input.get(COLOR));
			}
			else
			{
				cStmt.setNull(13,Types.NVARCHAR);
			}
			
			if(input.get(SIZE) != null && !input.get(SIZE).toString().isEmpty())
			{   
				cStmt.setNString(14, (String) input.get(SIZE));
			}
			else
			{
				cStmt.setNull(14,Types.NVARCHAR);
			}
						
			if(input.get(WEIGHT) != null && !input.get(WEIGHT).toString().isEmpty())
			{   
				cStmt.setDouble(15, Double.parseDouble((String) input.get(WEIGHT)));
			}
			else
			{
				cStmt.setNull(15,Types.DOUBLE);
			}
			
			if(input.get(CLIENT_PRODUCT_STATUS) != null && !input.get(CLIENT_PRODUCT_STATUS).toString().isEmpty())
			{ 
				cStmt.setInt(16, (Integer) input.get(CLIENT_PRODUCT_STATUS));
			}
			else
			{
				cStmt.setNull(16,Types.INTEGER);
			}
			
			if(input.get(CREATED_DATE) != null && !input.get(CREATED_DATE).toString().isEmpty())
			{ 
				cStmt.setString(17, (String)input.get(CREATED_DATE));
			}
			else
			{
				cStmt.setNull(17,Types.VARCHAR);
			}
			
			if(input.get(UPDATED_DATE) != null && !input.get(UPDATED_DATE).toString().isEmpty())
			{ 
				cStmt.setString(18, (String)input.get(UPDATED_DATE));
			}
			else
			{
				cStmt.setNull(18,Types.VARCHAR);
			}
			
			if(input.get(SHORT_DESCRIPTION) != null && !input.get(SHORT_DESCRIPTION).toString().isEmpty())
			{ 
				String shortDescription = "";
				if(input.get(SHORT_DESCRIPTION).toString().length() >= 500)
				{
				  shortDescription = input.get(SHORT_DESCRIPTION).toString().substring(0, 495) + "...";								  
				}
				else
				{
					shortDescription = input.get(SHORT_DESCRIPTION).toString();									
				}
				
				cStmt.setNString(19, shortDescription);
			}
			else
			{
				cStmt.setNull(19,Types.NVARCHAR);
			}
			
			if(input.get(VISIBILITY) != null && !input.get(VISIBILITY).toString().isEmpty())
			{ 
				String visibility = (String) input.get(VISIBILITY);
				
				if((feedId == 18 || feedId == 19) && (productId.equalsIgnoreCase("1430") || productId.equalsIgnoreCase("110") || productId.equalsIgnoreCase("108") || productId.equalsIgnoreCase("1527")
					|| productId.equalsIgnoreCase("700") || productId.equalsIgnoreCase("701")))
				{
					visibility =  "Catalog";
				}
				cStmt.setNString(20, visibility);
			}
			else
			{
				cStmt.setNull(20,Types.NVARCHAR);
			}
			
			cStmt.execute();
			
		} 
		catch (Exception ex) 
		{
			ErrorLog.saveErrorLogToDB("InsertOrUpdateProductDetails", "Feed Id - " + feedId + " Product Id - " + productId +" Error Occured while inserting or updating product data.",  ex.getMessage());
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertOrUpdateProductDetails" , "Error Occured while inserting or updating product data.." ,"");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return true;
	}
}