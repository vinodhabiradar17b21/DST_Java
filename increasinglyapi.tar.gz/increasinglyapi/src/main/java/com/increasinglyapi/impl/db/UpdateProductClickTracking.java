package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;

public class UpdateProductClickTracking extends StoredProcedure implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final String SPROC_NAME = "Update_Bundle_Product_Click_Tracking";

	private static UpdateProductClickTracking instance = null;
	private static final Logger logger = LoggerFactory.getLogger(UpdateProductClickTracking.class.getName());

	private UpdateProductClickTracking()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("clientId", Types.INTEGER));
		declareParameter(new SqlParameter("increasinglyVisitorId", Types.VARCHAR));
		declareParameter(new SqlParameter("bundleIdList", Types.VARCHAR));
		compile();		
	}

	public static UpdateProductClickTracking getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateProductClickTracking();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String increasinglyVisitorId = (String) input.get(VISITOR_ID);
		String bundleIdList = (String)input.get(BUNDLE_ID_LIST);
		execute(clientId,increasinglyVisitorId,bundleIdList);	
		return 1;
		
	}
}