package com.increasinglyapi.impl.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import jersey.repackaged.com.google.common.cache.Cache;
import jersey.repackaged.com.google.common.cache.CacheBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.impl.db.PlatformList;
import com.increasinglyapi.utils.FormatLoggerMessage;

import static com.increasinglyapi.utils.Constants.*;


public class PlatformListCache
{
	private static final Logger logger = LoggerFactory.getLogger(PlatformListCache.class.getClass());
	private static final PlatformListCache instance = new PlatformListCache();

	private static Object lock1 = new Object();
	
	// Cache object
	private Cache<String, Integer> cachePlatFormList = CacheBuilder.newBuilder().maximumSize(500)
																	.expireAfterWrite(20, TimeUnit.MINUTES).build();
	
	public static PlatformListCache getCache()
	{
		return instance;
	}

	/**
	 * Uses Guava cache for caching the platform lists
	 * 
	 * @param platformName
	 * @return platform id
	 * @throws ExecutionException
	 */
	public Integer get(final String platformName)
	{		
		Integer platformId = 0;
		try
		{
			synchronized(lock1)
			{
				platformId = cachePlatFormList.get(new String(platformName), new Callable<Integer>()
				{
					public Integer call() throws Exception
					{
						return getORInsertPlatformIdFromDb(platformName);
					}
				});
				
			}
			
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "Platform details - get method" , "Error Occured" ,"");
			logger.error(errorMessage,ex);
		}
		
		return platformId;
	}
	
	public Integer getORInsertPlatformIdFromDb(String platformName)
	{
		Integer platformId = 0;
		try
		{
			logger.info(LOG_APPLICATION_FLOW + "Retrieving platform details for - " + platformName);
			PlatformList platformList = PlatformList.getInstance();
			
			Map<String, Object> input = new HashMap<String,Object>();
			input.put(PLATFORM, platformName);		
			platformId = platformList.runService(input);
			
			logger.info(LOG_APPLICATION_FLOW + "Completed retrieving platform details for - " + platformName);
		}
		catch(Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "getORInsertPlatformIdFromDb" , "Error Occured" ,"");
			logger.error(errorMessage,ex);
		}
		
		return platformId;
	}
	
}