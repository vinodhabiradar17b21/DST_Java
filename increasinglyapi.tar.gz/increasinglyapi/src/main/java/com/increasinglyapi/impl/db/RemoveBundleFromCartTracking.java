package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class RemoveBundleFromCartTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(RemoveBundleFromCartTracking.class.getClass());
		
	private static RemoveBundleFromCartTracking instance = null;
	
	private RemoveBundleFromCartTracking()
	{
				
	}

	public static RemoveBundleFromCartTracking getInstance()
	{
		if (instance == null)
		{
			instance = new RemoveBundleFromCartTracking();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{
		Integer bundleId = (Integer) input.get(BUNDLE_ID);
		String visitorId = (String) input.get(VISITOR_ID);
		String removeTime = (String) input.get(VISIT_TIME);
		Integer clientId = (Integer) input.get(CLIENT_ID);
		
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Remove_Bundle_From_Cart_Tracking(?, ?, ?, ?)}");
					
			cStmt.setInt(1, bundleId);
			
			if(visitorId != null && !visitorId.isEmpty())
			{
				cStmt.setString(2, visitorId);
			}
			else
			{
				cStmt.setNull(2, Types.NVARCHAR);
			}
			
			if(removeTime != null && !removeTime.isEmpty())
			{
				cStmt.setString(3, removeTime);
			}
			else
			{
				cStmt.setNull(3, Types.VARCHAR);
			}
			
			cStmt.setInt(4, clientId);
			
			cStmt.execute();
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertBundleAddToCartTrackingDetails" , "Error Occured while removing bundle add to cart tracking details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("RemoveBundleFromCartTracking.java runService()", "Error occured while removing bundle add to cart tracking details.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("RemoveBundleFromCartTracking.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
		//execute(emailAddress,customerName,firstName,lastName,visitorId,clientId);
		
		return true;
	}
}