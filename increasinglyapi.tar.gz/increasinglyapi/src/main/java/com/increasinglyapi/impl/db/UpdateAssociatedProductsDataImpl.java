package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;


public class UpdateAssociatedProductsDataImpl implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateAssociatedProductsDataImpl.class.getClass());
	
	private static UpdateAssociatedProductsDataImpl instance = null;
	
	private UpdateAssociatedProductsDataImpl()
	{
		
	}

	public static UpdateAssociatedProductsDataImpl getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateAssociatedProductsDataImpl();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		int feedId = (Integer)input.get(FEED_ID);
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Associated_Product_Details(?, ?, ?, ?, ?, ?, ?)}");
					
			cStmt.setInt(1, (Integer)input.get(FEED_ID));
			
			String productId = (String) input.get(PRODUCT_ID);
			cStmt.setBytes(2, productId.getBytes());
			
			Boolean hasAssociatedProducts = (Boolean)input.get(HAS_ASSOCIATED_PRODUCTS);			
			cStmt.setBoolean(3, hasAssociatedProducts);
			
			Boolean hasRelatedProducts = (Boolean)input.get(HAS_RELATED_PRODUCTS);			
			cStmt.setBoolean(4, hasRelatedProducts);
			
			Boolean hasUpSellProducts = (Boolean)input.get(HAS_UP_SELL_PRODUCTS);			
			cStmt.setBoolean(5, hasUpSellProducts);
			
			Boolean hasCrossSellProducts = (Boolean)input.get(HAS_CROSS_SELL_PRODUCTS);			
			cStmt.setBoolean(6, hasCrossSellProducts);
			
			cStmt.registerOutParameter(7, Types.INTEGER);
			
			cStmt.execute();
			
			Integer result = cStmt.getInt("Result");
			
			return result;
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateAssociatedProductsDataImpl" , "Error Occured while updating associated product details." ,"");
			logger.error(errorMessage,ex);
			
			DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
			deleteTemporaryStorageData.deleteTemporaryAssociatedProductDetails(input);
			
			ErrorLog.saveErrorLogToDB("UpdateAssociatedProductsDataImpl.java", "Feed Id - " + feedId  +" Error Occured while updating associated product details.",  ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return 0;
	}
}