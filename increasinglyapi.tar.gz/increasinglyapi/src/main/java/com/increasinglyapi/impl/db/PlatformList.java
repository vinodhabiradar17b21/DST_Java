package com.increasinglyapi.impl.db;

import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import static com.increasinglyapi.utils.Constants.*;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;


public class PlatformList extends StoredProcedure implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final String SPROC_NAME = "GetOrInsert_Platform_Id";

	private static PlatformList instance = null;
	private static final Logger logger = LoggerFactory.getLogger(PlatformList.class.getName());

	private PlatformList()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("PlatformName", Types.VARCHAR));
		declareParameter(new SqlOutParameter("PlatformId", Types.INTEGER));
		compile();		
	}

	public static PlatformList getInstance()
	{
		if (instance == null)
		{
			instance = new PlatformList();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		String platformName = (String) input.get(PLATFORM);
		Map<String, Object> results = execute(platformName);		
		Integer platformId = (Integer) results.get("PlatformId");
		return platformId;	
	}
}