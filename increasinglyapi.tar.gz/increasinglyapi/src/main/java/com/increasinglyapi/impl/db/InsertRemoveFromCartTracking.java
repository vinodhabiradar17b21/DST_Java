package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertRemoveFromCartTracking implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertRemoveFromCartTracking.class.getClass());
	
	public Boolean runService(final Map<String, Object> input) 
	{
	 
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);		
		
		String queryTmpl = "INSERT INTO remove_from_cart_tracking"
				+ "(product_id,is_logged_in,visitor_id,visit_time,referral_url,user_agent,platform_id,client_id)"
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	
	
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){
	
				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {
								
					    String productId = (String)input.get(PRODUCT_ID);
						ps.setBytes(1, productId.getBytes());
						
						Boolean isLoggedIn = (Boolean)input.get(IS_LOGGED_IN);						
						if(isLoggedIn != null)
						{
							ps.setBoolean(2, (Boolean)input.get(IS_LOGGED_IN));	
						}
						else
						{
							ps.setBoolean(2,false);
						}
						
						String visitorId = (String)input.get(VISITOR_ID);
						if(visitorId != null && !visitorId.isEmpty())
						{
						  ps.setString(3, (String)input.get(VISITOR_ID));
						}
						else
						{
							ps.setNull(3, Types.VARCHAR);
						}
						
						String visitTime = (String)input.get(VISIT_TIME);
						if(visitTime != null && !visitTime.isEmpty())
						{
						  ps.setString(4, (String)input.get(VISIT_TIME));
						}
						else
						{
							ps.setNull(4, Types.VARCHAR);
						}
						
						String referralUrl = (String)input.get(REFERRAL_URL);
						if(referralUrl != null && !referralUrl.isEmpty())
						{
						  ps.setNString(5, (String)input.get(REFERRAL_URL));
						}
						else
						{
							ps.setNull(5, Types.NVARCHAR);
						}
						
						String userAgent = (String)input.get(USER_AGENT);
						
						if(userAgent != null && !userAgent.isEmpty())
						{
						  ps.setNString(6, (String)input.get(USER_AGENT));
						}
						else
						{
							ps.setNull(6, Types.NVARCHAR);
						}
						
						/*String userIp = (String)input.get(USER_IP);
						
						if(userIp != null && !userIp.isEmpty())
						{
						   ps.setString(7, (String)input.get(USER_IP));	
						}
						else
						{
						  ps.setNull(7, Types.NVARCHAR);
						}
						*/
						
						ps.setInt(7, (Integer)input.get(PLATFORM_ID));
						ps.setInt(8, (Integer)input.get(CLIENT_ID));
						
						ps.execute();
						return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertRemoveFromCartTracking" , "Error Occured while inserting remove cart tracking data." ,"");
			logger.error(errorMessage,ex);
			return false;
		}
	}
	
}