package com.increasinglyapi.impl;

public class ImportDataParameters
{
	private String signature = "";
	private String eventData = "";
	private String vid = "";
	private String time = null;
	private String uri = "";
	private String userIpAddress = "";
	private String userAgent = "";
	private String productData = "";
	private String imageUrl = "";
	private String description = "";
	private String productId = "";
		
	private String productName = "";
	private String productPrice = "";
	private String productSpecialPrice = "";
	private String availability = "";
				
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProductData() {
		return productData;
	}

	public void setProductData(String productData) {
		this.productData = productData;
	}

	public String getSignature()
	{
		return this.signature;
	}
	
	public void setSignature(String signature)
	{
		this.signature = signature;
	}
	
	public String getEventData()
	{
		return this.eventData;
	}
	
	public void setEventData(String eventData)
	{
		this.eventData = eventData;
	}
	
	public String getVid()
	{
		return this.vid;
	}
	
	public void setVid(String vid)
	{
		this.vid = vid;
	}
	
	public String getTime()
	{
		return this.time;
	}
	
	public void setTime(String time)
	{
		this.time = time;
	}
	
	public String getUri()
	{
		return this.uri;
	}
	
	public void setUri(String uri)
	{
		this.uri = uri;
	}
	
	public String getUserIpAddress()
	{
		return this.userIpAddress;
	}
	
	public void setUserIpAddress(String userIpAddress)
	{
		this.userIpAddress = userIpAddress;
	}
	
	public String getUserAgent()
	{
		return this.userAgent;
	}
	
	public void setUserAgent(String userAgent)
	{
		this.userAgent = userAgent;
	}
	
	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductSpecialPrice() {
		return productSpecialPrice;
	}

	public void setProductSpecialPrice(String productSpecialPrice) {
		this.productSpecialPrice = productSpecialPrice;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
	/*@Override
	public String toString()
	{
		return "ImportDataParameters [";
	}*/
}