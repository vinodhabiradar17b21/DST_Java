package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class UpdateCrawledProductData
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateCrawledProductData.class.getClass());
	
	private static UpdateCrawledProductData instance = null;
	
	private UpdateCrawledProductData()
	{
				
	}

	public static UpdateCrawledProductData getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateCrawledProductData();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{		
		Connection conn = null;
		Integer clientId = 0;
		Double productPrice = null;
		Double specialPrice = null;
		String productId = "";
		String imageUrl = "";
		String productUrl = "";
		String productName = "";
		String availability = "";
		String description = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Crawled_Product_Data(?, ?, ?, ?, ?,?,?,?,?)}");
		
			clientId = (Integer) input.get(CLIENT_ID);
			
			if(input.get(PRODUCT_ID) != null && !input.get(PRODUCT_ID).toString().isEmpty())
			{
				productId = (String) input.get(PRODUCT_ID);
			}
			
			if(input.get(PRODUCT_URL) != null && !input.get(PRODUCT_URL).toString().isEmpty())
			{
				productUrl = input.get(PRODUCT_URL).toString();
			}
			
			if(input.get(PRODUCT_NAME) != null && !input.get(PRODUCT_NAME).toString().isEmpty())
			{
				productName = input.get(PRODUCT_NAME).toString();
			}
			
			if(input.get(PRODUCT_PRICE) != null && !input.get(PRODUCT_PRICE).toString().isEmpty())
			{
				productPrice = Double.parseDouble((String) input.get(PRODUCT_PRICE));
			}			
			
			if(input.get(SPECIAL_PRICE) != null && !input.get(SPECIAL_PRICE).toString().isEmpty())
			{
				specialPrice = Double.parseDouble((String) input.get(SPECIAL_PRICE));
			}
			
			if(input.get(IMAGE_URL) != null && !input.get(IMAGE_URL).toString().isEmpty())
			{
				imageUrl = input.get(IMAGE_URL).toString();
			}
			
			if(input.get(AVAILABILITY) != null && !input.get(AVAILABILITY).toString().isEmpty())
			{
				availability = input.get(AVAILABILITY).toString();
			}
			
			if(input.get(DESCRIPTION) != null && !input.get(DESCRIPTION).toString().isEmpty())
			{
				description =(String) input.get(DESCRIPTION);
				
				if(description.length() >= 8000)
				{
					description = description.substring(0, 7995) + "...";								  
				}
			}
						
			cStmt.setNString(1, productId);
			cStmt.setNString(2, imageUrl);
			cStmt.setNString(3, description);			
			cStmt.setInt(4, clientId);
			cStmt.setNString(5, productUrl);
			cStmt.setNString(6, productName);
			
			if(productPrice != null)
			{
				cStmt.setDouble(7, productPrice);
			}
			else
			{
				cStmt.setNull(7, Types.DOUBLE);
			}
			
			if(specialPrice != null)
			{
				cStmt.setDouble(8, specialPrice);
			}
			else
			{
				cStmt.setNull(8, Types.DOUBLE);
			}
			
			
			cStmt.setNString(9, availability);
			
			
			
			if(clientId == 24 && (productPrice == null || productPrice == 0))
			{
				return false;
			}
				
			if(productId != "")
			{
				cStmt.execute();
			}
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateCrawledProductData" , "Error Occured while updating product details for the client Id -" + clientId ,"");
			logger.error(errorMessage,ex);
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		return true;
	}
}