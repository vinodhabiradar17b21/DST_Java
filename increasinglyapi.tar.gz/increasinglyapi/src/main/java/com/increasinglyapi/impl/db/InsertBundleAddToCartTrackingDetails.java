package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.impl.PageType;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class InsertBundleAddToCartTrackingDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(InsertBundleAddToCartTrackingDetails.class.getClass());
		
	private static InsertBundleAddToCartTrackingDetails instance = null;
	
	private InsertBundleAddToCartTrackingDetails()
	{
				
	}

	public static InsertBundleAddToCartTrackingDetails getInstance()
	{
		if (instance == null)
		{
			instance = new InsertBundleAddToCartTrackingDetails();
		}
		return instance;
	}

	public Boolean runService(Map<String, Object> input) 
	{
		Integer bundleId = (Integer) input.get(BUNDLE_ID);
		String visitorId = (String) input.get(VISITOR_ID);
		String creationTime = (String) input.get(VISIT_TIME);
		String referralUrl = (String) input.get(REFERRAL_URL);
		String userAgent = (String) input.get(USER_AGENT);
		//String userIp = (String)input.get(USER_IP);
		Integer clientId = (Integer) input.get(CLIENT_ID);
		Integer pageTypeId = 0;
		Integer purchaseTypeId = 0;
		Integer isLoggedInUser = (Integer) input.get(IS_LOGGED_IN_USER);
		Integer isAbandonedCartBundle = (Integer) input.get(IS_ABANDONED_CART_BUNDLE);							
		Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Insert_Bundle_Add_To_Cart_Tracking(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
					
			cStmt.setInt(1, bundleId);
			
			if(visitorId != null && !visitorId.isEmpty())
			{
				cStmt.setString(2, visitorId);
			}
			else
			{
				cStmt.setNull(2, Types.NVARCHAR);
			}
			
			if(creationTime != null && !creationTime.isEmpty())
			{
				cStmt.setString(3, creationTime);
			}
			else
			{
				cStmt.setNull(3, Types.VARCHAR);
			}
			
			if(referralUrl != null && !referralUrl.isEmpty())
			{
				cStmt.setNString(4, referralUrl);
			}
			else
			{
				cStmt.setNull(4, Types.NVARCHAR);
			}
		
			if(userAgent != null && !userAgent.isEmpty())
			{
				cStmt.setNString(5, userAgent);
			}
			else
			{
				cStmt.setNull(5, Types.NVARCHAR);
			}
			
			/*if(userIp != null && !userIp.isEmpty())
			{
				cStmt.setString(6, userIp);
			}
			else
			{
				cStmt.setNull(6, Types.VARCHAR);
			}*/
			
			cStmt.setInt(6, clientId);	
			
			if(input.get(PAGE_TYPE_ID) != null && !input.get(PAGE_TYPE_ID).toString().isEmpty())				
			{
				pageTypeId = (Integer) input.get(PAGE_TYPE_ID);
				
				if(pageTypeId > 0)
				{
				   cStmt.setInt(7, pageTypeId);	
				}
				else
				{
				  cStmt.setNull(7, Types.INTEGER);	
				}
			}
			else
			{
				cStmt.setNull(7, Types.INTEGER);	
			}
			
			if((pageTypeId == PageType.PRODUCT_PAGE || pageTypeId == PageType.SEARCH_PAGE || pageTypeId == PageType.PLP_PAGE || pageTypeId == PageType.MODAL) && input.get(PRODUCT_ID) != null && !input.get(PRODUCT_ID).toString().isEmpty())
			{
			   String productId = (String)input.get(PRODUCT_ID);
			   cStmt.setBytes(8, productId.getBytes());
			}
			else
			{
				cStmt.setNull(8, Types.BINARY);
			}
			
			if(pageTypeId == PageType.CART_PAGE && input.get(PRODUCT_ID) != null && !input.get(PRODUCT_ID).toString().isEmpty())
			{
			   String productId = (String)input.get(PRODUCT_ID);
			   cStmt.setBytes(9, productId.getBytes());
			}
			else
			{
				cStmt.setNull(9, Types.BINARY);
			}
			
			if(input.get(PURCHASE_TYPE) != null && !input.get(PURCHASE_TYPE).toString().isEmpty())				
			{
				purchaseTypeId = (Integer) input.get(PURCHASE_TYPE);
				
				if(purchaseTypeId > 0)
				{
				  cStmt.setInt(10, purchaseTypeId);	
				}
				else
				{
					cStmt.setNull(10, Types.INTEGER);	
				}
			}
			else
			{
				cStmt.setNull(10, Types.INTEGER);	
			}
						
			if(isLoggedInUser != null)
			{
				cStmt.setInt(11, isLoggedInUser);
			}			
			else
			{
				cStmt.setNull(11, Types.INTEGER);	
			}
			
			if(isAbandonedCartBundle != null)
			{
				cStmt.setInt(12, isAbandonedCartBundle);
			}			
			else
			{
				cStmt.setNull(12, Types.INTEGER);	
			}			
			cStmt.execute();
			
		} 
		catch (Exception ex) {
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "InsertBundleAddToCartTrackingDetails" , "Error Occured while inserting bundle add to cart tracking details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("InsertAddToCartTracking.java runService()", "Error occured while inserting bundle add to cart tracking details.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("InsertAddToCartTracking.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
		//execute(emailAddress,customerName,firstName,lastName,visitorId,clientId);
		
		return true;
	}
}