package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.Types;
import java.util.Map;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;

public class TrackOrderData extends StoredProcedure implements ServiceInterface<Integer>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final String SPROC_NAME = "Track_Order_Details";

	private static TrackOrderData instance = null;
	
	private TrackOrderData()
	{
		super(BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource(), SPROC_NAME);
		declareParameter(new SqlParameter("ClientId", Types.INTEGER));
		declareParameter(new SqlParameter("ClientOrderId", Types.VARCHAR));
		declareParameter(new SqlParameter("PlatformId", Types.INTEGER));
		declareParameter(new SqlOutParameter("result", Types.INTEGER));
		compile();		
	}

	public static TrackOrderData getInstance()
	{
		if (instance == null)
		{
			instance = new TrackOrderData();
		}
		return instance;
	}

	public Integer runService(Map<String, Object> input) 
	{
		Integer clientId = (Integer) input.get(CLIENT_ID);
		String clientOrderId = (String) input.get(ORDER_ID);
		Integer platformId = (Integer) input.get(PLATFORM_ID);
		Map<String, Object> results = execute(clientId,clientOrderId,platformId);	
		
		if (results.get("result") == null)
		{
			return 0;
		}
		else
		{
			Integer res = (Integer) results.get("result");
			return res;			
		}	
	}
}