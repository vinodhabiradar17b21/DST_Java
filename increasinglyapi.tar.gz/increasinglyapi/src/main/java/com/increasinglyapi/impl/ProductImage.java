package com.increasinglyapi.impl;

public class ProductImage
{
	private String productId;
	private String imageUrl;
	
	public String getProductId() {
	    return productId;
	}
	public void setProductId(String productId) {
	    this.productId = productId;
	}
		
	public String getImageUrl() {
	    return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
	    this.imageUrl = imageUrl;
	}
}