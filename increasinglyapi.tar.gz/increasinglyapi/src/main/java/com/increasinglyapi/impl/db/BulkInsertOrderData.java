package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class BulkInsertOrderData implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(BulkInsertOrderData.class.getClass());
	
	public Boolean runService(Map<String,Object> input) 
	{
		final Integer clientId = (Integer)input.get(CLIENT_ID);
        final Integer platformId = (Integer)input.get(PLATFORM_ID);
        final String version = (String)input.get(VERSION); // Our Application version
        
               
       // logger.info(LOG_APPLICATION_FLOW + " Visitor Id in the begining of Bulk Insert - "+ visitorId);
        
        Integer isBulkOrderProcessing = 1;
		
		if(input.get(ORDER_DATA_IS_BULK_PROCESSING) != null)
		{
			isBulkOrderProcessing = (Integer)input.get(ORDER_DATA_IS_BULK_PROCESSING);
		}
        
		JdbcTemplate jdbcTemplate = BaseDB.getJdbcTemplate(dataSourceLookupName);
				
		String queryTmpl = "INSERT INTO order_details_temporary_storage"
				+ "(client_id,platform_id,client_order_id,order_status,order_amount,order_time,coupon_code,"
				+ "discount_amount,tax_amount,shipping_amount,shipping_method,currency_code,payment_method,"
				+ "user_agent,increasingly_version,visitor_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?, ?, ?, ?)";

		final int batchSize = 100; //Integer.parseInt(AirFrameProperties.fetch("batchSize"));

		final List<Map<String,Object>> finalOrderList =  (List<Map<String,Object>>)input.get(ORDER_LIST);
		try
		{
			return jdbcTemplate.execute(queryTmpl,new PreparedStatementCallback<Boolean>(){

				public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException, DataAccessException {

					int count = 0;
									
					for(Map<String,Object> order : finalOrderList)
					{			
						String orderId = null;
						String orderTime = null;
						
								
						orderId = (String)order.get(ORDER_ID);	
						orderTime = (String)order.get(ORDER_TIME);
					
						ps.setInt(1, clientId);
						
						if(platformId != null)
						{
						  ps.setInt(2, platformId);
						}
						else
						{
							ps.setInt(2, 1);
						}
						
						ps.setNString(3, orderId);
						
						if(order.get(ORDER_STATUS) != null && !order.get(ORDER_STATUS).toString().isEmpty())
						{
							ps.setNString(4, (String)order.get(ORDER_STATUS));
						}
						else
						{
							ps.setNull(4, Types.NVARCHAR);
						}
						
					
						if(order.get(ORDER_AMOUNT) != null && !order.get(ORDER_AMOUNT).toString().isEmpty())
						{   
							ps.setDouble(5, Double.parseDouble((String)order.get(ORDER_AMOUNT)));
						}
						else
						{
							ps.setNull(5,Types.DOUBLE);
						}
											
						ps.setString(6, orderTime);
						
						if(order.get(COUPON_CODE) != null && !order.get(COUPON_CODE).toString().isEmpty())
						{
							ps.setNString(7, (String)order.get(COUPON_CODE));		
						}
						else
						{
							ps.setNull(7, Types.NVARCHAR);
						}
					
						if(order.get(DISCOUNT_AMOUNT) != null && !order.get(DISCOUNT_AMOUNT).toString().isEmpty())
						{   
							ps.setDouble(8, Double.parseDouble((String)order.get(DISCOUNT_AMOUNT)));
						}
						else
						{
							ps.setNull(8,Types.DOUBLE);
						}
						
						if(order.get(TAX_AMOUNT) != null && !order.get(TAX_AMOUNT).toString().isEmpty())
						{   
							ps.setDouble(9, Double.parseDouble((String)order.get(TAX_AMOUNT)));
						}
						else
						{
							ps.setNull(9,Types.DOUBLE);
						}
						
						if(order.get(SHIPPING_AMOUNT) != null && !order.get(SHIPPING_AMOUNT).toString().isEmpty())
						{   
							ps.setDouble(10, Double.parseDouble((String)order.get(SHIPPING_AMOUNT)));
						}
						else
						{
							ps.setNull(10,Types.DOUBLE);
						}
						
						if(order.get(SHIPPING_METHOD) != null && !order.get(SHIPPING_METHOD).toString().isEmpty())
						{
							ps.setNString(11, (String)order.get(SHIPPING_METHOD));	
						}
						else
						{
							ps.setNull(11,Types.NVARCHAR);
						}
						
						if(order.get(CURRENCY_CODE) != null && !order.get(CURRENCY_CODE).toString().isEmpty())
						{
							ps.setNString(12, (String)order.get(CURRENCY_CODE));	
						}
						else
						{
							ps.setNull(12,Types.NVARCHAR);
						}
						
						if(order.get(PAYMENT_METHOD) != null && !order.get(PAYMENT_METHOD).toString().isEmpty())
						{
							ps.setNString(13, (String)order.get(PAYMENT_METHOD));	
						}
						else
						{
							ps.setNull(13,Types.NVARCHAR);
						}
						
						/*if(order.get(USER_IP) != null && !order.get(USER_IP).toString().isEmpty())
						{
							ps.setNString(14, (String)order.get(USER_IP));	
						}
						else
						{
							ps.setNull(14,Types.NVARCHAR);
						}*/													        
						
						if(order.get(USER_AGENT) != null && !order.get(USER_AGENT).toString().isEmpty())
						{
							ps.setString(14, (String)order.get(USER_AGENT));	
						}
						else
						{
							ps.setNull(14,Types.NVARCHAR);
						}
						if(version != null && !version.isEmpty())
						{
							ps.setNString(15, version);	
						}
						else
						{
							ps.setNull(15,Types.NVARCHAR);
						}
						
						//logger.info(LOG_INFO + " Visitor Id in Bulk Insert method - "+ visitorId);
							
					
						if(order.get(VISITOR_ID) != null && !order.get(VISITOR_ID).toString().isEmpty())
						{
							ps.setNString(16, (String)order.get(VISITOR_ID));	
						}
						else
						{
							ps.setNull(16,Types.NVARCHAR);
						}
						
						ps.addBatch();
							
						if (++count % batchSize == 0)
						{
						  ps.executeBatch();
						}							
					}
										
					ps.executeBatch(); // insert remaining records
					return true;
				}
			});
		}
		catch (Exception ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "BulkInsertOrderData" , "Error Occured while importing order data." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("BulkInsertOrderData.java runService()", "Error occured while importing order data..", ex.getMessage());

			if(isBulkOrderProcessing == 1)
			{
				ErrorLog.saveErrorLogToDB("BulkInsertOrderData", "Client Id - " + clientId +" Error Occured while importing order details.",  ex.getMessage());
				DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
				deleteTemporaryStorageData.deleteTemporaryOrderDetails(input);
			}
			else
			{
				String clientOrderId = (String)input.get(ORDER_ID);
				ErrorLog.saveErrorLogToDB("BulkInsertOrderData", "Client Id - " + clientId +" Client Order Id - " + clientOrderId + " Error Occured while importing order details.",  ex.getMessage());
				DeleteTemporaryStorageData deleteTemporaryStorageData = new DeleteTemporaryStorageData();
				deleteTemporaryStorageData.deleteTemporaryIndividualOrderDetails(input);
			}
			
			return false;
		}
	}
}