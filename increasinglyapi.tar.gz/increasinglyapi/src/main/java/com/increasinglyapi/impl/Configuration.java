package com.increasinglyapi.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.utils.FormatLoggerMessage;
import com.increasinglyapi.utils.GetProperties;

import static com.increasinglyapi.utils.Constants.*;



public class Configuration
{
	private static Properties increasinglyProperties = null;
	private static final Logger logger = LoggerFactory.getLogger(Configuration.class.getClass());
	
	// Control
	private static Configuration current;
	
	// Local Path variables	
	private String domain = "increasingly.co";	

	
	private String machineName = "";
	
		
	private Configuration()
	{
	}

	public static void setConfiguration() 
	{		
	   Configuration conf = new Configuration();
	
		try
		{
			conf.machineName = InetAddress.getLocalHost().getHostName();
		}
		catch (UnknownHostException ex)
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "setConfiguration" , "failed to read machine name","");
			logger.error(errorMessage, ex);
		}
		
		GetProperties getProperties = new GetProperties();
		increasinglyProperties = getProperties.readProperties("webapp/WEB-INF/increasinglyapi.properties");			
    	    		
    	conf.domain = increasinglyProperties.getProperty("domain");
    	    
		current = conf;		
		
	}
	
	
	public static String getDomain()
	{
		return current.domain;
	}

}