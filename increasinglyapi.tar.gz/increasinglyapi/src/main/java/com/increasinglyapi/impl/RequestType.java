package com.increasinglyapi.impl;

public class RequestType
{
	public static final int INVALID = 1;
	public static final int CONVERSION_PIXEL = 2;
	
}