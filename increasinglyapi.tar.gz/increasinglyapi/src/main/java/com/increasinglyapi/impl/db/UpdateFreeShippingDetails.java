package com.increasinglyapi.impl.db;

import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.interfaces.ServiceInterface;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class UpdateFreeShippingDetails implements ServiceInterface<Boolean>
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(UpdateFreeShippingDetails.class.getClass());
	
    private static UpdateFreeShippingDetails instance = null;
	
	private UpdateFreeShippingDetails()
	{
		
	}

	public static UpdateFreeShippingDetails getInstance()
	{
		if (instance == null)
		{
			instance = new UpdateFreeShippingDetails();
		}
		return instance;
	}
	
	public Boolean runService(final Map<String, Object> input) 
	{
       Connection conn = null;
		
		try 
		{
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Update_Shipping_Details(?, ?, ?, ?)}");
					
			Boolean isFreeShippingActive = (Boolean)input.get(IS_FREE_SHIPPING_ACTIVE);
			String freeShippingSubTotal = (String)input.get(FREE_SHIPPING_SUB_TOTAL);
			String freeShippingTitle = (String)input.get(FREE_SHIPPING_TITLE);
			
			cStmt.setInt(1, (Integer)input.get(CLIENT_ID));
			
			if(isFreeShippingActive != null)
			{
			  cStmt.setBoolean(2, isFreeShippingActive);
			}
			else
			{
				cStmt.setBoolean(2, false);
			}
			
			if(freeShippingSubTotal != null && !freeShippingSubTotal.isEmpty())
			{
			  cStmt.setDouble(3, Double.parseDouble(freeShippingSubTotal));
			}
			else
			{
				cStmt.setNull(3, Types.DOUBLE);
			}
			
			if(freeShippingTitle != null)
			{
			  cStmt.setNString(4, freeShippingTitle);
			}
			else
			{
				cStmt.setNull(4, Types.NVARCHAR);
			}
			
			cStmt.execute();
						
			return true;
			
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "UpdateFreeShippingDetails" , "Error Occured while updating free shipping details." ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("UpdateFreeShippingDetails.java runService()", "Error occured while updating free shipping details..", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("UpdateFreeShippingDetails.java runService()", "Error occured while closing connection.", e.getMessage());
			}
		}
		
		return false;
	}
}