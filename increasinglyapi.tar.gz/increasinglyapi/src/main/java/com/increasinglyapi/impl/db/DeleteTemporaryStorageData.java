package com.increasinglyapi.impl.db;


import static com.increasinglyapi.utils.Constants.*;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.increasinglyapi.db.BaseDB;
import com.increasinglyapi.utils.FormatLoggerMessage;

public class DeleteTemporaryStorageData
{
	private final static String dataSourceLookupName = "mysqlserver";
	private static final Logger logger = LoggerFactory.getLogger(DeleteTemporaryStorageData.class.getClass());
			
	public void deleteTemporaryOrderItemAttributeDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			String clientOrderId = (String)input.get(ORDER_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from order_item_attribute_details_temporary_storage where client_id=? and client_order_id=?");
					
			cStmt.setInt(1, clientId);		
			cStmt.setNString(2, clientOrderId);		
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderItemAttributeDetails" , "Error Occured while deleting inconsistant order item attributes data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderItemAttributeDetails()", "Error occured while deleting inconsistant order item attributes data.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderItemAttributeDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryOrderItemDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from order_item_details_temporary_storage where client_id=?");
					
			cStmt.setInt(1, clientId);		
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderItemDetails" , "Error Occured while deleting inconsistant order item data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderItemDetails()", "Error occured while deleting inconsistant order item data.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderItemDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryIndividualOrderItemDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			String clientOrderId = (String)input.get(ORDER_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from order_item_details_temporary_storage where client_id=? and client_order_id=?");
					
			cStmt.setInt(1, clientId);		
			cStmt.setNString(2, clientOrderId);
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryIndividualOrderItemDetails" , "Error Occured while deleting inconsistant individual order item data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryIndividualOrderItemDetails()", "Error occured while deleting inconsistant individual order item data.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryIndividualOrderItemDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryIndividualOrderDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			String clientOrderId = (String)input.get(ORDER_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("{call Delete_Temporary_Order_Details(?, ?)}");
			
			cStmt.setInt(1, clientId);	
			cStmt.setNString(2, clientOrderId);
					
			cStmt.executeUpdate();			
			
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderDetails" , "Error Occured while deleting inconsistant individual order data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryIndividualOrderDetails()", "Error occured while deleting inconsistant individual order data.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryIndividualOrderDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	

	}
	
	public void deleteTemporaryOrderDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer clientId = (Integer)input.get(CLIENT_ID);
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from order_details_temporary_storage where client_id=?");
					
			cStmt.setInt(1, clientId);		
					
			cStmt.executeUpdate();
			
			deleteTemporaryOrderItemDetails(input);
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryOrderDetails" , "Error Occured while deleting inconsistant order data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderDetails()", "Error occured while closing connection.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryOrderDetails()", "Error occured while closing connection.", e.getMessage());
			}
			
		}	

	}
	
	public void deleteTemporaryProductDetailsAllData(Map<String,Object> input) 
	{		
		deleteTemporaryProductCategoryDetails(input);
		deleteTemporaryAssociatedProductDetails(input);
		deleteTemporaryProductOtherImageDetails(input);
	}
	
		
	public void deleteTemporaryProductCategoryDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer feedId = (Integer)input.get(FEED_ID);
			String productId = (String) input.get(PRODUCT_ID);			
			
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from client_product_category_temprory_list where feed_id=? AND product_id = ?");
					
			cStmt.setInt(1, feedId);	
			cStmt.setBytes(2, productId.getBytes());
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryProductCategoryDetails" , "Error Occured while deleting inconsistant product category data" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductCategoryDetails()", "Error occured while deleting inconsistant product category data.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductCategoryDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryAssociatedProductDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer feedId = (Integer)input.get(FEED_ID);
			String productId = (String) input.get(PRODUCT_ID);	
			
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from client_associated_product_temprory_list where feed_id=? AND product_id = ?");
					
			cStmt.setInt(1, feedId);	
			cStmt.setBytes(2, productId.getBytes());
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryAssociatedProductDetails" , "Error Occured while deleting inconsistant associated product list" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryAssociatedProductDetails()", "Error occured while deleting inconsistant associated product list.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryAssociatedProductDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryProductOtherImageDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer feedId = (Integer)input.get(FEED_ID);
			String productId = (String) input.get(PRODUCT_ID);	
			
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from client_product_other_images_temprory_list where feed_id=? AND product_id = ?");
					
			cStmt.setInt(1, feedId);
			cStmt.setBytes(2, productId.getBytes());
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryProductOtherImageDetails" , "Error Occured while deleting inconsistant product other image list" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductOtherImageDetails()", "Error occured while deleting inconsistant product other image list.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductOtherImageDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
	
	public void deleteTemporaryProductOptionDetails(Map<String,Object> input) 
	{
    
		Connection conn = null;
		
		try 
		{
			Integer feedId = (Integer)input.get(FEED_ID);
			String productId = (String) input.get(PRODUCT_ID);
			
			conn = BaseDB.getJdbcTemplate(dataSourceLookupName).getDataSource().getConnection();
			CallableStatement cStmt = conn.prepareCall("delete from product_attribute_details_temprory_list where feed_id=? AND parent_product_id = ?");
					
			cStmt.setInt(1, feedId);	
			cStmt.setBytes(2, productId.getBytes());
					
			cStmt.executeUpdate();
			
		} 
		catch (Exception ex) 
		{
			String errorMessage = FormatLoggerMessage.formatError(LOG_ERROR , "deleteTemporaryProductOptionDetails" , "Error Occured while deleting inconsistant product option details" ,"");
			logger.error(errorMessage,ex);
			ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductOptionDetails()", "Error occured while deleting inconsistant product option details.", ex.getMessage());
		}
		finally
		{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ErrorLog.saveErrorLogToDB("DeleteTemporaryStorageData.java deleteTemporaryProductOptionDetails()", "Error occured while closing connection.", e.getMessage());
			}
		}	
	}
}