package com.increasinglyapi.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventDataParameters
{
	private String eventType = ""; // Indicates type of event, like order, page view, product view, category view etc 
	private String platform = "";	
	private int platformId = 0;
	private String apiKey = "";
	private String version = "";
	private int clientId = 0;
	private String eventMethod = ""; // Indicates whether the event data is tracked or imported (historical).
	private int pageTypeId = 0;
	private int purchaseType = 0; 
	private int isLoggedInUser = 0;
		
	
	private List<Map<String,Object>> orderData = new ArrayList<Map<String,Object>>();
	private Map<String,Object> trackedData = new HashMap<String,Object>();
	
	public String getEventType()
	{
		return this.eventType;
	}
	
	public void setEventType(String eventType)
	{
		this.eventType = eventType;
	}
	
	public String getEventMethod()
	{
		return this.eventMethod;
	}
	
	public void setEventMethod(String eventMethod)
	{
		this.eventMethod = eventMethod;
	}
	
	public String getPlatform()
	{
		return this.platform;
	}
	
	public void setPlatform(String platform)
	{
		this.platform = platform;
	}
	
	public int getPlatformId()
	{
		return this.platformId;
	}
	
	public void setPlatformId(int platformId)
	{
		this.platformId = platformId;
	}
	
	public int getClientId()
	{
		return this.clientId;
	}
	
	public void setClientId(int clientId)
	{
		this.clientId = clientId;
	}
	
	public String getApiKey()
	{
		return this.apiKey;
	}
	
	public void setApiKey(String apiKey)
	{
		this.apiKey = apiKey;
	}
		
	public String getVersion()
	{
		return this.version;
	}
	
	public void setVersion(String version)
	{
		this.version = version;
	}
	
	public List<Map<String,Object>> getOrderData()
	{
		return this.orderData;
	}
	
	public void setOrderData(List<Map<String,Object>> orderData)
	{
		this.orderData = orderData;
	}
		
	public Map<String,Object> getTrackedData()
	{
		return this.trackedData;
	}
	
	public void setTrackedData(Map<String,Object> trackedData)
	{
		this.trackedData = trackedData;
	}
	
	public int getPageTypeId()
	{
		return this.pageTypeId;
	}
	
	public void setPageTypeId(int pageTypeId)
	{
		this.pageTypeId = pageTypeId;
	}
	
	public int getPurchaseType()
	{
		return this.purchaseType;
	}
	
	public void setPurchaseType(int purchaseType)
	{
		this.purchaseType = purchaseType;
	}
	
	public int getIsLoggedInUser() {
		return this.isLoggedInUser;
	}

	public void setIsLoggedInUser(int isLoggedInUser) {
		this.isLoggedInUser = isLoggedInUser;
	}
}